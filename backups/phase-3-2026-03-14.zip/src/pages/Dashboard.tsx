﻿import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Activity, Calendar, MapPin, Plus, ShieldAlert, Syringe, DollarSign, TriangleAlert, Settings2, X, Eye, EyeOff, ExternalLink, Users, GripVertical, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence, Reorder, useDragControls } from 'motion/react';
import { Link, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { usePets } from '../contexts/PetContext';
import { useCommunity } from '../contexts/CommunityContext';
import { useExpenses } from '../contexts/ExpenseContext';
import type { Pet } from '../contexts/PetContext';
import { searchServices, type ServiceResult } from '../utils/serviceApi';
import { getActiveLostPets, type LostPetAlert } from '../utils/lostPetsApi';
import { LostPetBanner } from '../components/LostPetBanner';
import { PetFormModal } from '../components/PetFormModal';
import { GettingStartedGuide } from '../components/GettingStartedGuide';
import { RecommendationBanner } from '../components/RecommendationBanner';
import { CalendarModal } from '../components/CalendarModal';
import { useSafetyAlerts, CATEGORY_LABELS, CATEGORY_COLORS } from '../contexts/SafetyAlertsContext';
import { useSocial } from '../contexts/SocialContext';

const GUIDE_COMPLETE_KEY = 'petbase-guide-completed';
const MODULE_VISIBILITY_KEY = 'petbase-dashboard-modules';
const MODULE_ORDER_KEY = 'petbase-dashboard-order';

type ModuleKey = 'safety_alerts' | 'lost_pet' | 'your_pets' | 'services' | 'upcoming' | 'expenses' | 'groups' | 'friends';

const MODULE_LABELS: Record<ModuleKey, string> = {
  safety_alerts: 'Safety Alerts',
  lost_pet: 'Lost Pet Banner',
  your_pets: 'Your Pets',
  services: 'Local Services',
  upcoming: 'Upcoming Events',
  expenses: 'Expenses',
  groups: 'My Groups',
  friends: 'Friends',
};

const DEFAULT_VISIBILITY: Record<ModuleKey, boolean> = {
  safety_alerts: true,
  lost_pet: true,
  your_pets: true,
  services: true,
  upcoming: true,
  expenses: true,
  groups: true,
  friends: true,
};

function loadVisibility(): Record<ModuleKey, boolean> {
  try {
    const raw = localStorage.getItem(MODULE_VISIBILITY_KEY);
    return raw ? { ...DEFAULT_VISIBILITY, ...JSON.parse(raw) } : { ...DEFAULT_VISIBILITY };
  } catch {
    return { ...DEFAULT_VISIBILITY };
  }
}

const DEFAULT_MODULE_ORDER: ModuleKey[] = [
  'safety_alerts', 'lost_pet', 'your_pets', 'services', 'upcoming', 'expenses', 'groups', 'friends',
];

function loadOrder(): ModuleKey[] {
  try {
    const raw = localStorage.getItem(MODULE_ORDER_KEY);
    if (!raw) return [...DEFAULT_MODULE_ORDER];
    const saved: ModuleKey[] = JSON.parse(raw);
    // Merge in any newly-added module keys not in the saved order
    const missing = DEFAULT_MODULE_ORDER.filter(k => !saved.includes(k));
    return [...saved.filter(k => DEFAULT_MODULE_ORDER.includes(k)), ...missing];
  } catch {
    return [...DEFAULT_MODULE_ORDER];
  }
}

function EmergencyModal({ onClose, onFindVet }: { onClose: () => void; onFindVet: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-stone-800 rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
      >
        <div className="bg-rose-600 p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5" /> Emergency Assistance
            </h2>
            <button onClick={onClose} className="text-white/70 hover:text-white p-1 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-rose-100 text-sm mt-1">Tap a service below to get immediate help.</p>
        </div>

        <div className="p-4 space-y-3">
          <button
            onClick={() => { onFindVet(); onClose(); }}
            className="w-full flex items-center gap-4 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/40 border border-rose-200 dark:border-rose-900/50 p-4 rounded-xl transition-colors text-left"
          >
            <div className="w-10 h-10 bg-rose-100 dark:bg-rose-900/50 rounded-xl flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            </div>
            <div>
              <p className="font-bold text-rose-900 dark:text-rose-100 text-sm">Nearest 24/7 ER Vet</p>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">Find emergency veterinary care near you</p>
            </div>
          </button>

          <a
            href="https://www.aspca.org/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-orange-50 dark:bg-orange-950/30 hover:bg-orange-100 dark:hover:bg-orange-900/40 border border-orange-200 dark:border-orange-900/50 p-4 rounded-xl transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="font-bold text-orange-900 dark:text-orange-100 text-sm">ASPCA Poison Control</p>
              <p className="text-xs text-orange-700 dark:text-orange-300 mt-0.5">aspca.org · Available 24/7</p>
            </div>
          </a>

          <a
            href="https://www.petpoisonhelpline.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-amber-50 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-900/40 border border-amber-200 dark:border-amber-900/50 p-4 rounded-xl transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="font-bold text-amber-900 dark:text-amber-100 text-sm">Pet Poison Helpline</p>
              <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">petpoisonhelpline.com · Available 24/7</p>
            </div>
          </a>
        </div>
      </motion.div>
    </div>
  );
}

const ModuleRow = React.memo(function ModuleRow({ moduleKey, isVisible, onChange }: { moduleKey: ModuleKey; isVisible: boolean; onChange: (key: ModuleKey, value: boolean) => void }) {
  const controls = useDragControls();
  return (
    <Reorder.Item
      value={moduleKey}
      dragListener={false}
      dragControls={controls}
      className="flex items-center gap-2 p-2.5 rounded-xl border border-stone-100 dark:border-stone-700 bg-white dark:bg-stone-800 select-none"
    >
      <button
        type="button"
        role="switch"
        aria-checked={isVisible}
        aria-label={`Toggle ${MODULE_LABELS[moduleKey]}`}
        onClick={() => onChange(moduleKey, !isVisible)}
        className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${isVisible ? 'bg-emerald-500' : 'bg-stone-300 dark:bg-stone-600'}`}
      >
        <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${isVisible ? 'translate-x-4' : 'translate-x-0'}`} />
      </button>
      <span className="text-sm font-medium text-stone-700 dark:text-stone-300 flex-1 flex items-center gap-2">
        {isVisible ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <EyeOff className="w-3.5 h-3.5 text-stone-400" />}
        {MODULE_LABELS[moduleKey]}
      </span>
      <button
        type="button"
        onPointerDown={(e) => controls.start(e)}
        aria-label={`Drag to reorder ${MODULE_LABELS[moduleKey]}`}
        className="p-1.5 rounded text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 cursor-grab active:cursor-grabbing touch-none"
      >
        <GripVertical className="w-4 h-4" />
      </button>
    </Reorder.Item>
  );
});

function CustomizeModal({
  visibility,
  onChange,
  order,
  onReorder,
  onClose,
}: {
  visibility: Record<ModuleKey, boolean>;
  onChange: (key: ModuleKey, value: boolean) => void;
  order: ModuleKey[];
  onReorder: (newOrder: ModuleKey[]) => void;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-stone-800 rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 border-b border-stone-100 dark:border-stone-700">
          <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-stone-500" /> Modify Dashboard
          </h2>
          <button onClick={onClose} aria-label="Close" className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 p-1 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5 max-h-[60vh] overflow-y-auto">
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">Show/hide modules · Drag <GripVertical className="w-3 h-3 inline" /> to reorder.</p>
          <Reorder.Group axis="y" values={order} onReorder={onReorder} className="space-y-1.5">
            {order.map(key => (
              <ModuleRow key={key} moduleKey={key} isVisible={visibility[key]} onChange={onChange} />
            ))}
          </Reorder.Group>
        </div>
        <div className="p-5 border-t border-stone-100 dark:border-stone-700 flex justify-between items-center gap-2">
          <button
            onClick={() => {
              (Object.keys(DEFAULT_VISIBILITY) as ModuleKey[]).forEach(k => onChange(k, DEFAULT_VISIBILITY[k]));
            }}
            className="text-xs text-stone-500 hover:text-stone-700 dark:hover:text-stone-300 transition-colors"
          >
            Reset to defaults
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 text-sm font-medium hover:bg-stone-700 dark:hover:bg-stone-200 transition-colors"
          >
            Done
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export function Dashboard() {
  const { user, profile } = useAuth();
  const { pets, addPet } = usePets();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [topService, setTopService] = useState<ServiceResult | null>(null);
  const [lostPet, setLostPet] = useState<LostPetAlert | null>(null);
  const SERVICE_CATS = ['Vets', 'Groomers', 'Sitters', 'Walkers', 'Trainers'] as const;
  const [serviceCatIdx, setServiceCatIdx] = useState(0);
  const [guideCompleted, setGuideCompleted] = useState(
    () => localStorage.getItem(GUIDE_COMPLETE_KEY) === 'true'
  );
  const [moduleVisibility, setModuleVisibility] = useState<Record<ModuleKey, boolean>>(loadVisibility);
  const [moduleOrder, setModuleOrder] = useState<ModuleKey[]>(loadOrder);

  const toggleModule = useCallback((key: ModuleKey, value: boolean) => {
    setModuleVisibility(prev => {
      const next = { ...prev, [key]: value };
      localStorage.setItem(MODULE_VISIBILITY_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const reorderModule = useCallback((newOrder: ModuleKey[]) => {
    setModuleOrder(newOrder);
    localStorage.setItem(MODULE_ORDER_KEY, JSON.stringify(newOrder));
  }, []);


  const { expenses, addExpense, stopRecurring, totalExpenses } = useExpenses();
  const { alerts: safetyAlerts } = useSafetyAlerts();
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [newExpenseLabel, setNewExpenseLabel] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState('');
  const [newExpenseRecurring, setNewExpenseRecurring] = useState(false);
  const [newExpenseFrequency, setNewExpenseFrequency] = useState<'Weekly' | 'Bi-weekly' | 'Monthly' | 'Yearly'>('Monthly');

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseLabel || !newExpenseAmount) return;
    addExpense({
      label: newExpenseLabel,
      amount: parseFloat(newExpenseAmount),
      date: new Date().toISOString(),
      recurring: newExpenseRecurring || undefined,
      frequency: newExpenseRecurring ? newExpenseFrequency : undefined,
    });
    setNewExpenseLabel('');
    setNewExpenseAmount('');
    setNewExpenseRecurring(false);
    setShowExpenseForm(false);
  };


  const { groups } = useCommunity();
  const { directory } = useSocial();

  const myGroups = useMemo(() =>
    groups
      .filter(g => user?.uid && g.members[user.uid])
      .sort((a, b) => {
        const lastA = a.posts[0]?.createdAt ?? a.createdAt ?? '';
        const lastB = b.posts[0]?.createdAt ?? b.createdAt ?? '';
        return String(lastB).localeCompare(String(lastA));
      })
      .slice(0, 3),
    [groups, user?.uid]
  );

  const myFriends = useMemo(() => {
    const friendUids: string[] = (profile as any)?.friends ?? [];
    return friendUids
      .map(uid => directory.find(p => p.uid === uid))
      .filter(Boolean)
      .slice(0, 3) as typeof directory;
  }, [profile, directory]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }, []);

  const upcomingEvents = useMemo(() => {
    if (!user) return [];
    return groups
      .flatMap(g => g.events.map(e => ({ ...e, groupName: g.name })))
      .filter(e => e.attendeeIds.includes(user.uid))
      .map(e => ({
        id: e.id,
        title: e.title,
        pet: e.groupName,
        date: new Date(e.date).toLocaleDateString(),
        icon: Calendar,
        color: 'text-indigo-500',
        bg: 'bg-indigo-50 dark:bg-indigo-950',
      }))
      .slice(0, 5);
  }, [user, groups]);

  const previewPets = pets.slice(0, 2);

  const handleGuideComplete = useCallback(() => {
    setGuideCompleted(true);
  }, []);

  // Stable string key — only changes when the actual set of pet types changes
  const petTypesKey = useMemo(
    () => [...new Set(pets.map(p => p.type ?? 'Dog'))].sort().join(','),
    [pets]
  );

  useEffect(() => {
    if (!profile?.zipCode) return;
    const petTypesQuery = petTypesKey ? petTypesKey.split(',') : ['Dog'];
    searchServices({ query: '', location: profile.zipCode, type: 'Vets', petTypesQuery })
      .then(res => { if (res.length > 0) setTopService(res[0]); });
    getActiveLostPets(profile.zipCode)
      .then(res => { if (res.length > 0) setLostPet(res[0]); });
  }, [profile?.zipCode, petTypesKey]);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">
              {greeting}, {user?.displayName?.split(' ')[0] || 'Pet Parent'}!
            </h1>
            <p className="text-stone-500 dark:text-stone-400 mt-1">
              Here's what's happening with your furry friends today.
            </p>
          </div>
          <button
            onClick={() => setIsCustomizeOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-800 transition-colors text-sm font-medium self-start md:self-auto"
          >
            <Settings2 className="w-4 h-4" /> Modify Dashboard
          </button>
        </header>



        {/* Emergency Assistance */}
        <button
          onClick={() => setIsEmergencyOpen(true)}
          className="w-full flex items-center gap-4 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/30 dark:hover:bg-rose-900/40 border border-rose-200 dark:border-rose-900/50 p-4 rounded-2xl transition-colors text-left"
        >
          <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/50 rounded-xl flex items-center justify-center shrink-0">
            <ShieldAlert className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          </div>
          <div>
            <h3 className="font-bold text-rose-900 dark:text-rose-100">Emergency Assistance</h3>
            <p className="text-sm text-rose-700 dark:text-rose-300">24/7 ER vet · ASPCA poison control · Pet Poison Helpline</p>
          </div>
        </button>

        {/* Community Safety Alerts */}
        {moduleVisibility.safety_alerts && safetyAlerts.length > 0 && (
          <section aria-label="Community safety alerts">
            <div className="flex items-center gap-2 mb-3">
              <TriangleAlert className="w-4 h-4 text-amber-500" aria-hidden="true" />
              <h2 className="text-sm font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider">
                Local Safety Alerts
              </h2>
              <span className="ml-auto text-xs text-stone-400">{safetyAlerts.length} near you</span>
            </div>
            <div className="space-y-2">
              {safetyAlerts.slice(0, 3).map(alert => (
                <div
                  key={alert.id}
                  className="flex items-start gap-3 bg-white dark:bg-stone-800 border border-stone-100 dark:border-stone-700 rounded-2xl p-4 shadow-sm"
                >
                  <div className="mt-0.5 shrink-0">
                    <TriangleAlert className={`w-4 h-4 ${alert.severity === 'high' ? 'text-rose-500' : alert.severity === 'medium' ? 'text-amber-500' : 'text-sky-500'}`} aria-hidden="true" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-stone-900 dark:text-stone-100">{alert.title}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[alert.category]}`}>
                        {CATEGORY_LABELS[alert.category]}
                      </span>
                    </div>
                    <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 line-clamp-2">{alert.description}</p>
                    <p className="text-xs text-stone-400 mt-1">
                      {new Date(alert.createdAt).toLocaleDateString()} · expires {new Date(alert.expiresAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Lost Pet Banner */}
        {moduleVisibility.lost_pet && lostPet && (
          <LostPetBanner lostPet={lostPet} />
        )}

        {/* Getting Started Guide (removed permanently once all steps complete) */}
        {!guideCompleted && (
          <GettingStartedGuide onComplete={handleGuideComplete} />
        )}

        {/* Recommendation Banner — only shown after the guide is gone */}
        {guideCompleted && <RecommendationBanner />}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {moduleOrder.filter(k => k !== 'safety_alerts' && k !== 'lost_pet').map(key => {
            if (!moduleVisibility[key]) return null;
            const wideKeys: ModuleKey[] = ['your_pets', 'services'];
            const colSpanClass = wideKeys.includes(key) ? 'lg:col-span-2' : '';
            switch (key) {
              case 'your_pets': return (
                <motion.div layout key="your_pets" className={colSpanClass}>
                  <section>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100">Your Pets</h2>
                      <Link to="/pets" className="text-emerald-600 font-medium text-sm hover:underline">View All</Link>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {previewPets.map((pet) => (
                        <div key={pet.id} className="bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-sm border border-stone-100 dark:border-stone-700 flex flex-col gap-4">
                          <Link to="/pets" state={{ editPetId: pet.id }} className="flex items-center gap-4 group cursor-pointer">
                            <img src={pet.image} alt={pet.name} className="w-16 h-16 rounded-xl object-cover" referrerPolicy="no-referrer" />
                            <div className="flex-1">
                              <h3 className="font-bold text-lg text-stone-900 dark:text-stone-100 group-hover:text-emerald-600 transition-colors">{pet.name}</h3>
                              <p className="text-sm text-stone-500 dark:text-stone-400">{pet.breed}</p>
                              <div className="flex items-center gap-2 mt-1.5 text-[11px] font-medium text-stone-600 dark:text-stone-400">
                                {pet.age && <span className="bg-stone-100 dark:bg-stone-700 px-2 py-0.5 rounded select-none">{pet.age}</span>}
                                {pet.weight && <span className="bg-stone-100 dark:bg-stone-700 px-2 py-0.5 rounded select-none">{pet.weight}</span>}
                              </div>
                            </div>
                          </Link>
                          <div className="grid grid-cols-3 gap-2 pt-3 border-t border-stone-100 dark:border-stone-700">
                            <Link to="/pets" state={{ editPetId: pet.id }} className="flex flex-col items-center justify-center p-2 rounded-xl bg-stone-50 dark:bg-stone-700/50 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 transition-colors">
                              <Settings2 className="w-4 h-4 mb-1" />
                              <span className="text-[10px] font-semibold uppercase tracking-wide">Edit</span>
                            </Link>
                            <Link to="/pets" state={{ openMedical: true, tab: 'meds', petId: pet.id }} className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 transition-colors">
                              <Syringe className="w-4 h-4 mb-1" />
                              <span className="text-[10px] font-semibold uppercase tracking-wide">Meds</span>
                            </Link>
                            <Link to="/cards" state={{ openCreateModal: true, petId: pet.id }} className="flex flex-col items-center justify-center p-2 rounded-xl bg-rose-50 dark:bg-rose-900/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 transition-colors">
                              <ShieldAlert className="w-4 h-4 mb-1" />
                              <span className="text-[10px] font-semibold uppercase tracking-wide">Card</span>
                            </Link>
                          </div>
                        </div>
                      ))}
                      <button onClick={() => setIsModalOpen(true)} className="bg-stone-50 dark:bg-stone-800 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl p-4 flex flex-col items-center justify-center text-stone-500 dark:text-stone-400 hover:text-emerald-600 hover:border-emerald-200 dark:hover:border-emerald-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 transition-colors min-h-[112px]">
                        <Plus className="w-6 h-6 mb-2" />
                        <span className="font-medium text-sm">Add Pet</span>
                      </button>
                    </div>
                  </section>
                </motion.div>
              );
              case 'services': return (
                <motion.div layout key="services" className={colSpanClass}>
                  <section>
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100">Local Services for You</h2>
                      <Link to="/search" className="text-emerald-600 font-medium text-sm hover:underline">Find more</Link>
                    </div>
                    <div className="flex items-center gap-2 mb-4">
                      <button
                        onClick={() => setServiceCatIdx(i => (i - 1 + SERVICE_CATS.length) % SERVICE_CATS.length)}
                        aria-label="Previous category"
                        className="p-1.5 rounded-full border border-stone-200 dark:border-stone-700 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors shrink-0"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <div className="flex gap-2 flex-1 overflow-hidden">
                        {SERVICE_CATS.map((cat, i) => (
                          <Link
                            key={cat}
                            to={`/search?type=${cat}`}
                            className={`flex-none px-4 py-2 rounded-full text-sm font-medium transition-colors border ${i === serviceCatIdx
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700'
                              } ${Math.abs(i - serviceCatIdx) > 1 ? 'hidden sm:flex' : 'flex'}`}
                          >
                            {cat}
                          </Link>
                        ))}
                      </div>
                      <button
                        onClick={() => setServiceCatIdx(i => (i + 1) % SERVICE_CATS.length)}
                        aria-label="Next category"
                        className="p-1.5 rounded-full border border-stone-200 dark:border-stone-700 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors shrink-0"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                    {topService ? (
                      <div className="bg-white dark:bg-stone-800 rounded-2xl p-6 border border-stone-100 dark:border-stone-700 relative overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                          <img src={topService.image} alt={topService.name} className="w-24 h-24 rounded-xl object-cover shadow-sm" referrerPolicy="no-referrer" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded-md uppercase tracking-wider">Top Rated Near You</span>
                            </div>
                            <h3 className="font-bold text-lg text-stone-900 dark:text-stone-100">{topService.name}</h3>
                            <div className="flex items-center gap-4 mt-2 text-sm font-medium text-stone-600 dark:text-stone-400">
                              <div className="flex items-center gap-1"><MapPin className="w-4 h-4 text-emerald-500" /><span>{topService.distance}</span></div>
                              <div className="flex items-center gap-1"><Activity className="w-4 h-4 text-rose-400" /><span>{topService.type}</span></div>
                            </div>
                          </div>
                          <Link to="/search" className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium text-sm transition-colors text-center w-full sm:w-auto shadow-sm">View Profile</Link>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-stone-50 dark:bg-stone-800/50 rounded-2xl p-6 border border-dashed border-stone-200 dark:border-stone-700 text-center text-stone-500 dark:text-stone-400">
                        <MapPin className="w-8 h-8 mx-auto mb-3 text-stone-400" />
                        <p>Set your Zip Code in the Search page to see top-rated services near you.</p>
                      </div>
                    )}
                  </section>
                </motion.div>
              );
              case 'upcoming': return (
                <motion.div layout key="upcoming">
                  <section className="bg-white dark:bg-stone-800 rounded-2xl p-6 shadow-sm border border-stone-100 dark:border-stone-700">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100">Upcoming</h2>
                      <Calendar className="w-5 h-5 text-stone-400 dark:text-stone-500" />
                    </div>
                    <div className="space-y-4">
                      {upcomingEvents.length > 0 ? upcomingEvents.map((event) => (
                        <div key={event.id} className="flex gap-4 items-start">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${event.bg} ${event.color}`}>
                            <event.icon className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-medium text-stone-900 dark:text-stone-100">{event.title}</h4>
                            <p className="text-sm text-stone-500 dark:text-stone-400">{event.pet} • {event.date}</p>
                          </div>
                        </div>
                      )) : (
                        <p className="text-sm text-stone-400 dark:text-stone-500 text-center py-4">
                          No upcoming events. Join a community group to see RSVPs here.
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => setIsCalendarOpen(true)}
                      className="w-full mt-6 py-2 text-sm font-medium text-stone-600 dark:text-stone-400 bg-stone-50 dark:bg-stone-700/50 hover:bg-stone-100 dark:hover:bg-stone-700 rounded-lg transition-colors"
                    >
                      View Calendar
                    </button>
                  </section>
                </motion.div>
              );
              case 'expenses': return (
                <motion.div layout key="expenses">
                  <section className="bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl p-6 shadow-sm border border-emerald-100 dark:border-emerald-900/30">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" /> Expenses
                      </h2>
                      <span className="text-xl font-bold text-emerald-700 dark:text-emerald-300">${totalExpenses.toFixed(2)}</span>
                    </div>
                    {showExpenseForm ? (
                      <form onSubmit={handleAddExpense} className="space-y-3 mb-4">
                        <input
                          type="text"
                          required
                          placeholder="E.g., Vet bill, food"
                          value={newExpenseLabel}
                          onChange={(e) => setNewExpenseLabel(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                        <input
                          type="number"
                          required
                          step="0.01"
                          min="0"
                          placeholder="Amount ($)"
                          value={newExpenseAmount}
                          onChange={(e) => setNewExpenseAmount(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                        {/* Recurring toggle */}
                        <label className="flex items-center gap-2 cursor-pointer text-sm text-emerald-800 dark:text-emerald-200">
                          <button
                            type="button"
                            role="switch"
                            aria-checked={newExpenseRecurring}
                            onClick={() => setNewExpenseRecurring(v => !v)}
                            className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${newExpenseRecurring ? 'bg-emerald-500' : 'bg-stone-300 dark:bg-stone-600'}`}
                          >
                            <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${newExpenseRecurring ? 'translate-x-4' : 'translate-x-0'}`} />
                          </button>
                          Recurring
                        </label>
                        {newExpenseRecurring && (
                          <select
                            value={newExpenseFrequency}
                            onChange={(e) => setNewExpenseFrequency(e.target.value as typeof newExpenseFrequency)}
                            className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          >
                            <option>Weekly</option>
                            <option>Bi-weekly</option>
                            <option>Monthly</option>
                            <option>Yearly</option>
                          </select>
                        )}
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => { setShowExpenseForm(false); setNewExpenseRecurring(false); }}
                            className="flex-1 py-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 rounded-lg hover:bg-emerald-200/50 dark:hover:bg-emerald-800/50 transition-colors"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="flex-1 py-1.5 text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
                          >
                            Save
                          </button>
                        </div>
                      </form>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setShowExpenseForm(true)}
                        className="w-full py-2 mb-4 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/80 rounded-lg transition-colors flex items-center justify-center gap-2"
                      >
                        <Plus className="w-4 h-4" /> Add Expense
                      </button>
                    )}
                    {/* Recurring expenses sub-list */}
                    {(() => {
                      const recurring = expenses.filter(e => e.recurring);
                      if (!recurring.length) return null;
                      return (
                        <div className="mb-3 p-3 bg-emerald-100/60 dark:bg-emerald-900/20 rounded-xl border border-emerald-200 dark:border-emerald-800/50">
                          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-2 uppercase tracking-wide">Recurring</p>
                          <div className="space-y-1.5">
                            {recurring.map(e => (
                              <div key={e.id} className="flex items-center justify-between text-xs">
                                <div>
                                  <span className="font-medium text-stone-800 dark:text-stone-200">{e.label}</span>
                                  <span className="text-emerald-600 dark:text-emerald-400 ml-1">· {e.frequency}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="font-medium text-stone-700 dark:text-stone-300">${e.amount.toFixed(2)}</span>
                                  <button
                                    type="button"
                                    onClick={() => stopRecurring(e.id)}
                                    className="text-rose-400 hover:text-rose-600 dark:hover:text-rose-300 text-[10px] font-semibold uppercase tracking-wide border border-rose-200 dark:border-rose-800 px-1.5 py-0.5 rounded"
                                  >
                                    Stop
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })()}
                    <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                      {expenses.filter(e => !e.recurring).slice(0, 10).map((expense) => (
                        <div key={expense.id} className="flex items-center justify-between text-sm py-1 border-b border-emerald-100/50 dark:border-emerald-800/50 last:border-0">
                          <div>
                            <p className="font-medium text-stone-900 dark:text-stone-100">{expense.label}</p>
                            <p className="text-xs text-stone-500 dark:text-stone-400">{new Date(expense.date).toLocaleDateString()}</p>
                          </div>
                          <span className="font-medium text-stone-900 dark:text-stone-100">${expense.amount.toFixed(2)}</span>
                        </div>
                      ))}
                      {expenses.length === 0 && !showExpenseForm && (
                        <p className="text-sm text-center text-emerald-600/70 dark:text-emerald-400/70 py-2">No expenses yet</p>
                      )}
                    </div>
                  </section>
                </motion.div>
              );
              case 'groups': return (
                <motion.div layout key="groups">
                  <section className="bg-white dark:bg-stone-800 rounded-2xl p-6 shadow-sm border border-stone-100 dark:border-stone-700">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                        <Users className="w-5 h-5 text-violet-500" /> My Groups
                      </h2>
                      <Link to="/community" className="text-xs text-violet-600 dark:text-violet-400 hover:underline font-medium">View All</Link>
                    </div>
                    {myGroups.length === 0 ? (
                      <div className="text-center py-6">
                        <p className="text-sm text-stone-400 dark:text-stone-500 mb-3">You haven't joined any groups yet.</p>
                        <Link to="/community" className="text-sm text-violet-600 dark:text-violet-400 font-medium hover:underline">Browse groups</Link>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {myGroups.map(g => (
                          <Link key={g.id} to={`/community/groups/${g.id}`} className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50 dark:hover:bg-stone-700/50 transition-colors">
                            <div className="w-9 h-9 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-violet-700 dark:text-violet-300">
                              {g.name.charAt(0).toUpperCase()}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-stone-800 dark:text-stone-200 truncate">{g.name}</p>
                              <p className="text-xs text-stone-400 dark:text-stone-500">{Object.keys(g.members).length} member{Object.keys(g.members).length !== 1 ? 's' : ''}</p>
                            </div>
                            {g.tags?.[0] && <span className="text-xs bg-violet-50 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 px-2 py-0.5 rounded-full shrink-0">{g.tags[0]}</span>}
                          </Link>
                        ))}
                      </div>
                    )}
                  </section>
                </motion.div>
              );
              case 'friends': return (
                <motion.div layout key="friends">
                  <section className="bg-white dark:bg-stone-800 rounded-2xl p-6 shadow-sm border border-stone-100 dark:border-stone-700">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                        <Users className="w-5 h-5 text-pink-500" /> Friends
                      </h2>
                      <Link to="/people" className="text-xs text-pink-600 dark:text-pink-400 hover:underline font-medium">View All</Link>
                    </div>
                    {myFriends.length === 0 ? (
                      <div className="text-center py-6">
                        <p className="text-sm text-stone-400 dark:text-stone-500 mb-3">No friends added yet.</p>
                        <Link to="/people" className="text-sm text-pink-600 dark:text-pink-400 font-medium hover:underline">Find people</Link>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {myFriends.map(f => (
                          <Link key={f.uid} to="/people" className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50 dark:hover:bg-stone-700/50 transition-colors">
                            {f.avatarUrl ? (
                              <img src={f.avatarUrl} alt={f.displayName} className="w-9 h-9 rounded-full object-cover shrink-0" />
                            ) : (
                              <div className="w-9 h-9 rounded-full bg-pink-100 dark:bg-pink-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-pink-700 dark:text-pink-300">
                                {f.displayName?.charAt(0).toUpperCase() ?? '?'}
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-stone-800 dark:text-stone-200 truncate">{f.displayName}</p>
                              {f.pets.length > 0 && <p className="text-xs text-stone-400 dark:text-stone-500">{f.pets.map(p => `${p.count} ${p.type}`).join(', ')}</p>}
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </section>
                </motion.div>
              );
              default: return null;
            }
          })}
        </div>
      </motion.div>

      <PetFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={addPet}
      />
      <CalendarModal
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        events={upcomingEvents}
      />
      <AnimatePresence>
        {isCustomizeOpen && (
          <CustomizeModal
            visibility={moduleVisibility}
            onChange={toggleModule}
            order={moduleOrder}
            onReorder={reorderModule}
            onClose={() => setIsCustomizeOpen(false)}
          />
        )}
        {isEmergencyOpen && (
          <EmergencyModal
            onClose={() => setIsEmergencyOpen(false)}
            onFindVet={() => navigate('/search?tab=services&filters=Emergency,24%2F7')}
          />
        )}
      </AnimatePresence>
    </>
  );
}

/**
 * CommunityContext — Phase 7 Firestore Migration
 *
 * Data model:
 *   groups/{groupId}                 — group metadata (name, description, image, createdAt, ownerId)
 *   groups/{groupId}/members/{uid}   — GroupMember (role, joinedAt, userId)
 *   groups/{groupId}/posts/{postId}  — GroupPost
 *   groups/{groupId}/events/{eventId}— GroupEvent
 *
 * Strategy:
 *   - onSnapshot on the top-level `groups` collection detects group adds/removes in real time.
 *   - On each snapshot, subcollections (members, posts, events) are fetched via getDocs and
 *     assembled into the existing CommunityGroup interface — component code is unchanged.
 *   - All mutations write to Firestore AND update local state optimistically so the UI is
 *     immediately responsive without waiting for the next snapshot cycle.
 *   - userPreferences (isFavorite, lastVisited) are UI-only per-user state; they stay in
 *     localStorage and are never written to Firestore.
 *
 * Cross-device subcollection sync:
 *   The onSnapshot only fires on top-level group document changes (metadata). Post/event/member
 *   changes made on another device will appear after the next group metadata change or on
 *   page reload. Full per-subcollection real-time sync is deferred to Phase 8.
 *
 * Security Rules: see firestoreService.ts JSDoc for the full rules block.
 */

import {
  createContext, useContext, useState, useEffect,
  useCallback, useRef, type ReactNode,
} from 'react';
import {
  collection, doc, setDoc, addDoc, updateDoc, deleteDoc,
  onSnapshot, getDocs, writeBatch, arrayUnion, arrayRemove,
  query, where, limit,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { logActivity } from '../utils/activityLog';

export type CommunityRole = 'Owner' | 'Moderator' | 'Event Coordinator' | 'User';

export interface GroupMember {
  userId: string;
  role: CommunityRole;
  joinedAt: number;
}

export interface GroupEvent {
  id: string;
  title: string;
  date: string; // ISO string
  location: string;
  description: string;
  attendeeIds: string[];
  createdBy: string;
}

export interface GroupPost {
  id: string;
  authorId: string;
  authorName: string;
  authorImage?: string;
  content: string;
  createdAt: number;
  isPinned: boolean;
}

export interface CommunityGroup {
  id: string;
  name: string;
  description: string;
  image: string;
  createdAt: number;
  tags: string[]; // Up to 10 search/filter tags
  members: Record<string, GroupMember>; // userId -> GroupMember
  posts: GroupPost[];
  events: GroupEvent[];
}

export interface UserGroupPreferences {
  isFavorite: boolean;
  lastVisitedAt: number;
}

interface CommunityContextValue {
  groups: CommunityGroup[];
  userPreferences: Record<string, UserGroupPreferences>;
  loading: boolean;
  createGroup: (name: string, description: string, image?: string, tags?: string[]) => Promise<string | void>;
  joinGroup: (groupId: string) => Promise<void>;
  leaveGroup: (groupId: string) => Promise<void>;
  toggleFavorite: (groupId: string) => void;
  createPost: (groupId: string, content: string) => Promise<void>;
  pinPost: (groupId: string, postId: string, isPinned: boolean) => Promise<void>;
  deletePost: (groupId: string, postId: string) => Promise<void>;
  rsvpEvent: (groupId: string, eventId: string, joining: boolean) => Promise<void>;
  createEvent: (groupId: string, event: Omit<GroupEvent, 'id' | 'attendeeIds' | 'createdBy'>) => Promise<void>;
  deleteEvent: (groupId: string, eventId: string) => Promise<void>;
  updateMemberRole: (groupId: string, targetUserId: string, newRole: CommunityRole) => Promise<void>;
}

const CommunityContext = createContext<CommunityContextValue | null>(null);

const STORAGE_KEY_PREFS = 'petbase_community_prefs';

/** Fetch all subcollections for a single group and assemble a CommunityGroup. */
async function fetchGroupFull(groupId: string, gData: Record<string, any>): Promise<CommunityGroup> {
  const [membersSnap, postsSnap, eventsSnap] = await Promise.all([
    getDocs(collection(db, 'groups', groupId, 'members')),
    getDocs(collection(db, 'groups', groupId, 'posts')),
    getDocs(collection(db, 'groups', groupId, 'events')),
  ]);

  const members: Record<string, GroupMember> = {};
  membersSnap.docs.forEach(d => { members[d.id] = d.data() as GroupMember; });

  return {
    id: groupId,
    name: gData.name ?? '',
    description: gData.description ?? '',
    image: gData.image ?? '',
    createdAt: gData.createdAt ?? Date.now(),
    tags: gData.tags ?? [],
    members,
    posts: postsSnap.docs.map(d => ({ id: d.id, ...d.data() } as GroupPost)),
    events: eventsSnap.docs.map(d => ({ id: d.id, ...d.data() } as GroupEvent)),
  };
}

export function CommunityProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [groups, setGroups] = useState<CommunityGroup[]>([]);
  const [userPreferences, setUserPreferences] = useState<Record<string, UserGroupPreferences>>({});
  const [loading, setLoading] = useState(true);

  // Mutable ref so callbacks always see the latest groups without stale closures
  const groupsRef = useRef<CommunityGroup[]>([]);
  useEffect(() => { groupsRef.current = groups; }, [groups]);

  // userPreferences: per-user UI state only — stays in localStorage
  useEffect(() => {
    if (user) {
      try {
        const raw = localStorage.getItem(`${STORAGE_KEY_PREFS}_${user.uid}`);
        setUserPreferences(raw ? JSON.parse(raw) : {});
      } catch { setUserPreferences({}); }
    } else {
      setUserPreferences({});
    }
  }, [user]);

  useEffect(() => {
    if (user && !loading) {
      localStorage.setItem(`${STORAGE_KEY_PREFS}_${user.uid}`, JSON.stringify(userPreferences));
    }
  }, [userPreferences, user, loading]);

  // Subscribe to the top-level groups collection.
  // On each snapshot (group added/removed/metadata changed), fetch subcollections and
  // assemble the full CommunityGroup array.
  useEffect(() => {
    if (!user) { setGroups([]); setLoading(false); return; }
    setLoading(true);

    const unsub = onSnapshot(collection(db, 'groups'), async (snap) => {
      const assembled = await Promise.all(
        snap.docs.map(d => fetchGroupFull(d.id, d.data()))
      );
      setGroups(assembled);
      setLoading(false);
    });

    return unsub;
  }, [user]);

  // --- Mutations (Firestore write + optimistic local state) ----------------

  const createGroup = useCallback(async (
    name: string,
    description: string,
    image = 'https://picsum.photos/seed/group/400/300',
    tags: string[] = [],
  ) => {
    if (!user) return;
    try {
      const ownedCount = groupsRef.current.filter(g => g.members[user.uid]?.role === 'Owner').length;
      if (ownedCount >= 3) return 'You can only own up to 3 groups.';

      // Uniqueness check — query Firestore for existing group with same name (case-insensitive)
      const trimmedName = name.trim();
      const existingSnap = await getDocs(query(collection(db, 'groups'), where('name', '==', trimmedName), limit(1)));
      if (!existingSnap.empty) return `A group named "${trimmedName}" already exists. Please choose a different name.`;

      const groupRef = doc(collection(db, 'groups'));
      const groupId = groupRef.id;

      const batch = writeBatch(db);
      batch.set(groupRef, { name, description, image, createdAt: Date.now(), updatedAt: Date.now(), ownerId: user.uid, tags: tags.slice(0, 10) });
      batch.set(doc(db, 'groups', groupId, 'members', user.uid), {
        userId: user.uid, role: 'Owner', joinedAt: Date.now(),
      });
      batch.set(doc(collection(db, 'groups', groupId, 'events')), {
        title: `Welcome to ${name} Meetup`,
        date: new Date(Date.now() + 86400000 * Math.ceil(Math.random() * 5)).toISOString(),
        location: 'Local Pet Park',
        description: 'A quick meet and greet for our new group members!',
        attendeeIds: [],
        createdBy: 'system',
      });

      await batch.commit();

      setUserPreferences(prev => ({ ...prev, [groupId]: { isFavorite: false, lastVisitedAt: Date.now() } }));
      // onSnapshot will update groups state once Firestore confirms the write
    } catch (err: any) {
      console.error('Failed to create community group:', err);
      return `Failed to create group: ${err.message || 'Unknown error'}`;
    }
  }, [user]);

  const joinGroup = useCallback(async (groupId: string) => {
    if (!user) return;
    // Owners cannot join their own group as a User — they already own it
    const existingRole = groupsRef.current.find(g => g.id === groupId)?.members[user.uid]?.role;
    if (existingRole === 'Owner') return;
    const memberData: GroupMember = { userId: user.uid, role: 'User', joinedAt: Date.now() };

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, members: { ...g.members, [user.uid]: memberData } };
    }));

    const batch = writeBatch(db);
    batch.set(doc(db, 'groups', groupId, 'members', user.uid), memberData);
    batch.update(doc(db, 'groups', groupId), { updatedAt: Date.now() });
    await batch.commit();

    setUserPreferences(prev => ({ ...prev, [groupId]: { isFavorite: false, lastVisitedAt: Date.now() } }));

    const groupName = groupsRef.current.find(g => g.id === groupId)?.name ?? groupId;
    logActivity(user.uid, `Joined group: ${groupName}`);

    if (localStorage.getItem('petbase-step-join-community') !== 'true') {
      localStorage.setItem('petbase-step-join-community', 'true');
      window.dispatchEvent(new Event('petbase-guide-update'));
    }
  }, [user]);

  const leaveGroup = useCallback(async (groupId: string) => {
    if (!user) return;

    const group = groupsRef.current.find(g => g.id === groupId);
    const groupName = group?.name ?? groupId;
    const memberList = Object.values(group?.members ?? {}) as GroupMember[];
    const ownerList = memberList.filter(m => m.role === 'Owner');
    const isLastOwner = ownerList.length === 1 && ownerList[0].userId === user.uid;
    const isLastMember = memberList.length === 1;

    // Rule 2: Last owner must transfer or disband before leaving
    if (isLastOwner && !isLastMember) {
      throw new Error('LAST_OWNER');
    }

    // Rule 1: Last member leaving → hard-delete the entire group
    if (isLastMember) {
      setGroups(prev => prev.filter(g => g.id !== groupId));
      const batch = writeBatch(db);
      // Fetch and queue deletion of all subcollection docs
      const [postsSnap, eventsSnap, membersSnap] = await Promise.all([
        getDocs(collection(db, 'groups', groupId, 'posts')),
        getDocs(collection(db, 'groups', groupId, 'events')),
        getDocs(collection(db, 'groups', groupId, 'members')),
      ]);
      postsSnap.docs.forEach(d => batch.delete(d.ref));
      eventsSnap.docs.forEach(d => batch.delete(d.ref));
      membersSnap.docs.forEach(d => batch.delete(d.ref));
      batch.delete(doc(db, 'groups', groupId));
      await batch.commit();
      logActivity(user.uid, `Disbanded group (last member): ${groupName}`);
      return;
    }

    // Normal leave
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      const newMembers = { ...g.members };
      delete newMembers[user.uid];
      return { ...g, members: newMembers };
    }));

    const batch = writeBatch(db);
    batch.delete(doc(db, 'groups', groupId, 'members', user.uid));
    batch.update(doc(db, 'groups', groupId), { updatedAt: Date.now() });
    await batch.commit();

    logActivity(user.uid, `Left group: ${groupName}`);
  }, [user]);

  const toggleFavorite = useCallback((groupId: string) => {
    if (!user) return;
    setUserPreferences(prev => {
      const current = prev[groupId] || { isFavorite: false, lastVisitedAt: Date.now() };
      return { ...prev, [groupId]: { ...current, isFavorite: !current.isFavorite } };
    });
  }, [user]);

  const createPost = useCallback(async (groupId: string, content: string) => {
    if (!user) return;
    const newPost = {
      authorId: user.uid,
      authorName: user.displayName || 'Anonymous',
      authorImage: user.photoURL || undefined,
      content,
      createdAt: Date.now(),
      isPinned: false,
    };

    // Optimistic with temp ID
    const tempId = crypto.randomUUID();
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, posts: [{ ...newPost, id: tempId }, ...g.posts] };
    }));

    const docRef = await addDoc(collection(db, 'groups', groupId, 'posts'), newPost);

    // Replace temp ID with real Firestore ID
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, posts: g.posts.map(p => p.id === tempId ? { ...p, id: docRef.id } : p) };
    }));
  }, [user]);

  const pinPost = useCallback(async (groupId: string, postId: string, isPinned: boolean) => {
    if (!user) return;
    const group = groupsRef.current.find(g => g.id === groupId);
    if (!group) return;

    const pinnedCount = group.posts.filter(p => p.isPinned && p.id !== postId).length;
    if (isPinned && pinnedCount >= 3) {
      alert('You can only pin up to 3 posts.');
      return;
    }

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, posts: g.posts.map(p => p.id === postId ? { ...p, isPinned } : p) };
    }));

    await updateDoc(doc(db, 'groups', groupId, 'posts', postId), { isPinned });
  }, [user]);

  const deletePost = useCallback(async (groupId: string, postId: string) => {
    if (!user) return;

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, posts: g.posts.filter(p => p.id !== postId) };
    }));

    await deleteDoc(doc(db, 'groups', groupId, 'posts', postId));
  }, [user]);

  const rsvpEvent = useCallback(async (groupId: string, eventId: string, joining: boolean) => {
    if (!user) return;

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        events: g.events.map(e => {
          if (e.id !== eventId) return e;
          const attendeeIds = joining
            ? [...new Set([...e.attendeeIds, user.uid])]
            : e.attendeeIds.filter(id => id !== user.uid);
          return { ...e, attendeeIds };
        }),
      };
    }));

    await updateDoc(doc(db, 'groups', groupId, 'events', eventId), {
      attendeeIds: joining ? arrayUnion(user.uid) : arrayRemove(user.uid),
    });
  }, [user]);

  const createEvent = useCallback(async (
    groupId: string,
    eventData: Omit<GroupEvent, 'id' | 'attendeeIds' | 'createdBy'>,
  ) => {
    if (!user) return;
    const newEventData = { ...eventData, attendeeIds: [user.uid], createdBy: user.uid };
    const tempId = crypto.randomUUID();

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, events: [...g.events, { ...newEventData, id: tempId }] };
    }));

    const docRef = await addDoc(collection(db, 'groups', groupId, 'events'), newEventData);

    // Replace temp ID
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, events: g.events.map(e => e.id === tempId ? { ...e, id: docRef.id } : e) };
    }));
  }, [user]);

  const deleteEvent = useCallback(async (groupId: string, eventId: string) => {
    if (!user) return;

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return { ...g, events: g.events.filter(e => e.id !== eventId) };
    }));

    await deleteDoc(doc(db, 'groups', groupId, 'events', eventId));
  }, [user]);

  const updateMemberRole = useCallback(async (
    groupId: string,
    targetUserId: string,
    newRole: CommunityRole,
  ) => {
    if (!user) return;
    const group = groupsRef.current.find(g => g.id === groupId);
    if (!group || group.members[user.uid]?.role !== 'Owner') return;

    if (newRole !== 'Owner' && group.members[targetUserId]?.role === 'Owner') {
      const ownerCount = (Object.values(group.members) as GroupMember[]).filter(m => m.role === 'Owner').length;
      if (ownerCount <= 1) {
        alert('Cannot change the role of the last owner. Promote someone else first.');
        return;
      }
    }

    // Optimistic
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        members: {
          ...g.members,
          [targetUserId]: {
            ...(g.members[targetUserId] || { userId: targetUserId, joinedAt: Date.now() }),
            role: newRole,
          },
        },
      };
    }));

    await updateDoc(doc(db, 'groups', groupId, 'members', targetUserId), { role: newRole });
  }, [user]);

  return (
    <CommunityContext.Provider value={{
      groups,
      userPreferences,
      loading,
      createGroup,
      joinGroup,
      leaveGroup,
      toggleFavorite,
      createPost,
      pinPost,
      deletePost,
      rsvpEvent,
      createEvent,
      deleteEvent,
      updateMemberRole,
    }}>
      {children}
    </CommunityContext.Provider>
  );
}

export function useCommunity() {
  const context = useContext(CommunityContext);
  if (!context) throw new Error('useCommunity must be used within CommunityProvider');
  return context;
}

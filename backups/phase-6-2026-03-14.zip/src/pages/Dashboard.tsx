import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Activity, Calendar, MapPin, Plus, ShieldAlert, Syringe, DollarSign, TriangleAlert, Settings2, X, Eye, EyeOff, ExternalLink, Users, GripVertical, ChevronLeft, ChevronRight, LayoutDashboard, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence, Reorder, useDragControls, useReducedMotion } from 'motion/react';
import { Link, useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { usePets } from '../contexts/PetContext';
import { useCommunity } from '../contexts/CommunityContext';
import { useExpenses } from '../contexts/ExpenseContext';
import type { Pet } from '../contexts/PetContext';
import { searchServices, type ServiceResult } from '../utils/serviceApi';
import { getActiveLostPets, type LostPetAlert } from '../utils/lostPetsApi';
import { LostPetBanner } from '../components/LostPetBanner';
import { PetFormModal } from '../components/PetFormModal';
import { GettingStartedGuide } from '../components/GettingStartedGuide';
import { RecommendationBanner } from '../components/RecommendationBanner';
import { CalendarModal } from '../components/CalendarModal';
import { useSafetyAlerts, CATEGORY_LABELS, CATEGORY_COLORS } from '../contexts/SafetyAlertsContext';
import { useSocial } from '../contexts/SocialContext';

const GUIDE_COMPLETE_KEY = 'petbase-guide-completed';
const MODULE_VISIBILITY_KEY = 'petbase-dashboard-modules';
const MODULE_ORDER_KEY = 'petbase-dashboard-order';

type GridModuleKey = 'your_pets' | 'services' | 'upcoming' | 'expenses' | 'groups' | 'friends' | 'quick_actions';
type AlertModuleKey = 'safety_alerts' | 'lost_pet';
type ModuleKey = GridModuleKey | AlertModuleKey;

const MODULE_LABELS: Record<ModuleKey, string> = {
  safety_alerts: 'Safety Alerts',
  lost_pet: 'Lost Pet Banner',
  your_pets: 'Your Pets',
  services: 'Local Services',
  upcoming: 'Upcoming Events',
  expenses: 'Expenses',
  groups: 'My Groups',
  friends: 'Friends',
  quick_actions: 'Quick Actions',
};

const DEFAULT_VISIBILITY: Record<ModuleKey, boolean> = {
  safety_alerts: true,
  lost_pet: true,
  your_pets: true,
  services: true,
  upcoming: true,
  expenses: true,
  groups: true,
  friends: true,
  quick_actions: true,
};

function loadVisibility(): Record<ModuleKey, boolean> {
  try {
    const raw = localStorage.getItem(MODULE_VISIBILITY_KEY);
    return raw ? { ...DEFAULT_VISIBILITY, ...JSON.parse(raw) } : { ...DEFAULT_VISIBILITY };
  } catch {
    return { ...DEFAULT_VISIBILITY };
  }
}

const DEFAULT_MODULE_ORDER: GridModuleKey[] = [
  'your_pets', 'services', 'quick_actions', 'upcoming', 'expenses', 'groups', 'friends',
];

function loadOrder(): GridModuleKey[] {
  try {
    const raw = localStorage.getItem(MODULE_ORDER_KEY);
    if (!raw) return [...DEFAULT_MODULE_ORDER];
    const saved: GridModuleKey[] = JSON.parse(raw).filter((k: string) =>
      DEFAULT_MODULE_ORDER.includes(k as GridModuleKey)
    );
    const missing = DEFAULT_MODULE_ORDER.filter(k => !saved.includes(k));
    return [...saved, ...missing];
  } catch {
    return [...DEFAULT_MODULE_ORDER];
  }
}

function EmergencyModal({ onClose, onFindVet }: { onClose: () => void; onFindVet: () => void }) {
  const prefersReduced = useReducedMotion();
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="emergency-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={(e) => { if (e.key === 'Escape') onClose(); }}
    >
      <motion.div
        initial={prefersReduced ? false : { opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={prefersReduced ? undefined : { opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15, ease: 'easeOut' }}
        className="bg-white/75 dark:bg-neutral-900/75 backdrop-blur-xl rounded-t-2xl sm:rounded-2xl shadow-xl shadow-black/10 dark:shadow-black/30 border border-white/20 dark:border-white/10 w-full max-w-sm overflow-hidden"
      >
        <div className="bg-rose-600 p-5">
          <div className="flex items-center justify-between">
            <h2 id="emergency-modal-title" className="text-xl font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5" aria-hidden="true" /> Emergency Assistance
            </h2>
            <button
              onClick={onClose}
              aria-label="Close emergency assistance"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center text-white/70 hover:text-white rounded-lg motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-rose-100 text-sm mt-1">Tap a service below to get immediate help.</p>
        </div>

        <div className="p-4 space-y-3">
          <button
            onClick={() => { onFindVet(); onClose(); }}
            className="w-full flex items-center gap-4 bg-rose-50/80 hover:bg-rose-100/80 dark:bg-rose-950/30 dark:hover:bg-rose-900/40 backdrop-blur-sm border border-rose-200/60 dark:border-rose-900/50 p-4 rounded-2xl transition-colors text-left"
          >
            <div className="w-10 h-10 bg-rose-100 dark:bg-rose-900/50 rounded-xl flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            </div>
            <div>
              <p className="font-bold text-rose-900 dark:text-rose-100 text-sm">Nearest 24/7 ER Vet</p>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">Find emergency veterinary care near you</p>
            </div>
          </button>

          <a
            href="https://www.aspca.org/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-orange-50 dark:bg-orange-950/30 hover:bg-orange-100 dark:hover:bg-orange-900/40 border border-orange-200 dark:border-orange-900/50 p-4 rounded-xl transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="font-bold text-orange-900 dark:text-orange-100 text-sm">ASPCA Poison Control</p>
              <p className="text-xs text-orange-700 dark:text-orange-300 mt-0.5">aspca.org · Available 24/7</p>
            </div>
          </a>

          <a
            href="https://www.petpoisonhelpline.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-amber-50 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-900/40 border border-amber-200 dark:border-amber-900/50 p-4 rounded-xl transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="font-bold text-amber-900 dark:text-amber-100 text-sm">Pet Poison Helpline</p>
              <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">petpoisonhelpline.com · Available 24/7</p>
            </div>
          </a>
        </div>
      </motion.div>
    </div>
  );
}

function DraggableWidget({ moduleKey, editMode, onHide, children }: {
  moduleKey: GridModuleKey;
  editMode: boolean;
  onHide: () => void;
  children: React.ReactNode;
}) {
  const controls = useDragControls();
  return (
    <Reorder.Item value={moduleKey} dragListener={false} dragControls={controls} className="relative">
      {editMode && (
        <div className="absolute inset-x-0 top-0 z-10 flex items-center gap-2 px-4 py-2.5 bg-stone-900/85 dark:bg-stone-950/90 backdrop-blur-sm rounded-t-2xl">
          <button
            onPointerDown={(e) => controls.start(e)}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-stone-400 hover:text-stone-200 cursor-grab active:cursor-grabbing touch-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            aria-label={`Drag to reorder ${MODULE_LABELS[moduleKey]}`}
          >
            <GripVertical className="w-4 h-4" />
          </button>
          <span className="text-xs font-semibold text-stone-300 uppercase tracking-widest flex-1">{MODULE_LABELS[moduleKey]}</span>
          <button
            onClick={onHide}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-stone-400 hover:text-rose-400 motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            aria-label={`Hide ${MODULE_LABELS[moduleKey]}`}
          >
            <EyeOff className="w-4 h-4" />
          </button>
        </div>
      )}
      <div className={editMode ? 'pt-10' : ''}>{children}</div>
    </Reorder.Item>
  );
}

export function Dashboard() {
  const { user, profile } = useAuth();
  const { pets, addPet } = usePets();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [topService, setTopService] = useState<ServiceResult | null>(null);
  const [lostPet, setLostPet] = useState<LostPetAlert | null>(null);
  const SERVICE_CATS = ['Vets', 'Groomers', 'Sitters', 'Walkers', 'Trainers'] as const;
  const [serviceCatIdx, setServiceCatIdx] = useState(0);
  const [guideCompleted, setGuideCompleted] = useState(
    () => localStorage.getItem(GUIDE_COMPLETE_KEY) === 'true'
  );
  const [moduleVisibility, setModuleVisibility] = useState<Record<ModuleKey, boolean>>(loadVisibility);
  const [gridOrder, setGridOrder] = useState<GridModuleKey[]>(loadOrder);

  const toggleModule = useCallback((key: ModuleKey, value: boolean) => {
    setModuleVisibility(prev => {
      const next = { ...prev, [key]: value };
      localStorage.setItem(MODULE_VISIBILITY_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const reorderModule = useCallback((newOrder: GridModuleKey[]) => {
    setGridOrder(newOrder);
    localStorage.setItem(MODULE_ORDER_KEY, JSON.stringify(newOrder));
  }, []);

  const { expenses, addExpense, stopRecurring, totalExpenses } = useExpenses();
  const { alerts: safetyAlerts } = useSafetyAlerts();
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [newExpenseLabel, setNewExpenseLabel] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState('');
  const [newExpenseRecurring, setNewExpenseRecurring] = useState(false);
  const [newExpenseFrequency, setNewExpenseFrequency] = useState<'Weekly' | 'Bi-weekly' | 'Monthly' | 'Yearly'>('Monthly');

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseLabel || !newExpenseAmount) return;
    addExpense({
      label: newExpenseLabel,
      amount: parseFloat(newExpenseAmount),
      date: new Date().toISOString(),
      recurring: newExpenseRecurring || undefined,
      frequency: newExpenseRecurring ? newExpenseFrequency : undefined,
    });
    setNewExpenseLabel('');
    setNewExpenseAmount('');
    setNewExpenseRecurring(false);
    setShowExpenseForm(false);
  };

  const { groups } = useCommunity();
  const { directory } = useSocial();

  const myGroups = useMemo(() =>
    groups
      .filter(g => user?.uid && g.members[user.uid])
      .sort((a, b) => {
        const lastA = a.posts[0]?.createdAt ?? a.createdAt ?? '';
        const lastB = b.posts[0]?.createdAt ?? b.createdAt ?? '';
        return String(lastB).localeCompare(String(lastA));
      })
      .slice(0, 3),
    [groups, user?.uid]
  );

  const myFriends = useMemo(() => {
    const friendUids: string[] = (profile as any)?.friends ?? [];
    return friendUids
      .map(uid => directory.find(p => p.uid === uid))
      .filter(Boolean)
      .slice(0, 3) as typeof directory;
  }, [profile, directory]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }, []);

  const upcomingEvents = useMemo(() => {
    if (!user) return [];
    return groups
      .flatMap(g => g.events.map(e => ({ ...e, groupName: g.name })))
      .filter(e => e.attendeeIds.includes(user.uid))
      .map(e => ({
        id: e.id,
        title: e.title,
        pet: e.groupName,
        date: new Date(e.date).toLocaleDateString(),
        icon: Calendar,
        color: 'text-indigo-500',
        bg: 'bg-indigo-50 dark:bg-indigo-950',
      }))
      .slice(0, 5);
  }, [user, groups]);

  const previewPets = pets.slice(0, 2);

  const handleGuideComplete = useCallback(() => {
    setGuideCompleted(true);
  }, []);

  const petTypesKey = useMemo(
    () => [...new Set(pets.map(p => p.type ?? 'Dog'))].sort().join(','),
    [pets]
  );

  useEffect(() => {
    if (!profile?.zipCode) return;
    const petTypesQuery = petTypesKey ? petTypesKey.split(',') : ['Dog'];
    searchServices({ query: '', location: profile.zipCode, type: 'Vets', petTypesQuery })
      .then(res => { if (res.length > 0) setTopService(res[0]); });
    getActiveLostPets(profile.zipCode)
      .then(res => { if (res.length > 0) setLostPet(res[0]); });
  }, [profile?.zipCode, petTypesKey]);

  const prefersReduced = useReducedMotion();
  const GLASS_CARD = 'bg-white/75 dark:bg-neutral-900/75 backdrop-blur-xl rounded-2xl border border-stone-200/60 dark:border-stone-700/60 shadow-sm shadow-black/5 dark:shadow-black/20';
  const wideKeys: GridModuleKey[] = ['your_pets', 'services'];

  function renderWidget(key: GridModuleKey): React.ReactNode {
    switch (key) {
      case 'your_pets': return (
        <section className={`${GLASS_CARD} p-6`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100">Your Pets</h2>
            <Link to="/pets" className="text-emerald-600 font-medium text-sm hover:underline">View All</Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {previewPets.map((pet: Pet) => (
              <div key={pet.id} className="bg-white/60 dark:bg-neutral-800/60 rounded-xl p-4 border border-stone-200/50 dark:border-stone-700/50 flex flex-col gap-4">
                <Link to="/pets" state={{ editPetId: pet.id }} className="flex items-center gap-4 group cursor-pointer">
                  <img src={pet.image} alt={pet.name} width={64} height={64} className="w-16 h-16 rounded-xl object-cover" referrerPolicy="no-referrer" />
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-stone-900 dark:text-stone-100 group-hover:text-emerald-600 motion-safe:transition-colors">{pet.name}</h3>
                    <p className="text-sm text-stone-500 dark:text-stone-400">{pet.breed}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-xs font-medium text-stone-600 dark:text-stone-400">
                      {pet.age && <span className="bg-stone-100 dark:bg-stone-700 px-2 py-0.5 rounded select-none">{pet.age}</span>}
                      {pet.weight && <span className="bg-stone-100 dark:bg-stone-700 px-2 py-0.5 rounded select-none">{pet.weight}</span>}
                    </div>
                  </div>
                </Link>
                <div className="grid grid-cols-3 gap-2 pt-3 border-t border-stone-100 dark:border-stone-700">
                  <Link to="/pets" state={{ editPetId: pet.id }} aria-label={`Edit ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-stone-50 dark:bg-stone-700/50 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 motion-safe:transition-colors min-h-[44px]">
                    <Settings2 className="w-4 h-4 mb-1" aria-hidden="true" />
                    <span className="text-xs font-semibold uppercase tracking-wide">Edit</span>
                  </Link>
                  <Link to="/pets" state={{ openMedical: true, tab: 'meds', petId: pet.id }} aria-label={`Medications for ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 motion-safe:transition-colors min-h-[44px]">
                    <Syringe className="w-4 h-4 mb-1" aria-hidden="true" />
                    <span className="text-xs font-semibold uppercase tracking-wide">Meds</span>
                  </Link>
                  <Link to="/cards" state={{ openCreateModal: true, petId: pet.id }} aria-label={`Pet card for ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-rose-50 dark:bg-rose-900/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 motion-safe:transition-colors min-h-[44px]">
                    <ShieldAlert className="w-4 h-4 mb-1" aria-hidden="true" />
                    <span className="text-xs font-semibold uppercase tracking-wide">Card</span>
                  </Link>
                </div>
              </div>
            ))}
            <button onClick={() => setIsModalOpen(true)} className="bg-stone-50/80 dark:bg-stone-800/50 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl p-4 flex flex-col items-center justify-center text-stone-500 dark:text-stone-400 hover:text-emerald-600 hover:border-emerald-200 dark:hover:border-emerald-800 hover:bg-emerald-50/80 dark:hover:bg-emerald-950/30 motion-safe:transition-colors min-h-[112px]">
              <Plus className="w-6 h-6 mb-2" />
              <span className="font-medium text-sm">Add Pet</span>
            </button>
          </div>
        </section>
      );
      case 'services': return (
        <section className={`${GLASS_CARD} p-6`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100">Local Services for You</h2>
            <Link to="/search" className="text-emerald-600 font-medium text-sm hover:underline">Find more</Link>
          </div>
          <div className="flex items-center gap-2 mb-4">
            <button
              onClick={() => setServiceCatIdx(i => (i - 1 + SERVICE_CATS.length) % SERVICE_CATS.length)}
              aria-label="Previous category"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full border border-stone-200 dark:border-stone-700 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 motion-safe:transition-colors shrink-0"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex gap-2 flex-1 overflow-hidden">
              {SERVICE_CATS.map((cat, i) => (
                <Link
                  key={cat}
                  to={`/search?type=${cat}`}
                  className={`flex-none px-4 py-2 rounded-full text-sm font-medium motion-safe:transition-colors border ${i === serviceCatIdx
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-white/60 dark:bg-stone-800/60 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-700'
                    } ${Math.abs(i - serviceCatIdx) > 1 ? 'hidden sm:flex' : 'flex'}`}
                >
                  {cat}
                </Link>
              ))}
            </div>
            <button
              onClick={() => setServiceCatIdx(i => (i + 1) % SERVICE_CATS.length)}
              aria-label="Next category"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full border border-stone-200 dark:border-stone-700 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-700 motion-safe:transition-colors shrink-0"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          {topService ? (
            <div className="bg-white/60 dark:bg-neutral-800/60 rounded-2xl p-6 border border-stone-100/60 dark:border-stone-700/60 relative overflow-hidden shadow-sm hover:shadow-md motion-safe:transition-shadow">
              <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                <img src={topService.image} alt={topService.name} width={96} height={96} className="w-24 h-24 rounded-xl object-cover shadow-sm" referrerPolicy="no-referrer" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded-md uppercase tracking-wider">Top Rated Near You</span>
                  </div>
                  <h3 className="font-bold text-lg text-stone-900 dark:text-stone-100">{topService.name}</h3>
                  <div className="flex items-center gap-4 mt-2 text-sm font-medium text-stone-600 dark:text-stone-400">
                    <div className="flex items-center gap-1"><MapPin className="w-4 h-4 text-emerald-500" /><span>{topService.distance}</span></div>
                    <div className="flex items-center gap-1"><Activity className="w-4 h-4 text-rose-400" /><span>{topService.type}</span></div>
                  </div>
                </div>
                <Link to="/search" className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium text-sm motion-safe:transition-colors text-center w-full sm:w-auto shadow-sm">View Profile</Link>
              </div>
            </div>
          ) : (
            <div className="bg-stone-50/80 dark:bg-stone-800/50 rounded-2xl p-6 border border-dashed border-stone-200 dark:border-stone-700 text-center text-stone-500 dark:text-stone-400">
              <MapPin className="w-8 h-8 mx-auto mb-3 text-stone-400" />
              <p>Set your Zip Code in the Search page to see top-rated services near you.</p>
            </div>
          )}
        </section>
      );
      case 'upcoming': return (
        <section className={`${GLASS_CARD} p-6`}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100">Upcoming</h2>
            <Calendar className="w-5 h-5 text-stone-400 dark:text-stone-500" />
          </div>
          <div className="space-y-4">
            {upcomingEvents.length > 0 ? upcomingEvents.map((event) => (
              <div key={event.id} className="flex gap-4 items-start">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${event.bg} ${event.color}`}>
                  <event.icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-medium text-stone-900 dark:text-stone-100">{event.title}</h4>
                  <p className="text-sm text-stone-500 dark:text-stone-400">{event.pet} • {event.date}</p>
                </div>
              </div>
            )) : (
              <p className="text-sm text-stone-400 dark:text-stone-500 text-center py-4">
                No upcoming events. Join a community group to see RSVPs here.
              </p>
            )}
          </div>
          <button
            onClick={() => setIsCalendarOpen(true)}
            className="w-full mt-6 py-2 text-sm font-medium text-stone-600 dark:text-stone-400 bg-stone-50/80 dark:bg-stone-700/50 hover:bg-stone-100 dark:hover:bg-stone-700 rounded-lg motion-safe:transition-colors"
          >
            View Calendar
          </button>
        </section>
      );
      case 'expenses': return (
        <section className="bg-emerald-50/80 dark:bg-emerald-950/30 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-white/10 shadow-sm shadow-black/5 dark:shadow-black/20 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" /> Expenses
            </h2>
            <span className="text-xl font-bold text-emerald-700 dark:text-emerald-300">${totalExpenses.toFixed(2)}</span>
          </div>
          {showExpenseForm ? (
            <form onSubmit={handleAddExpense} className="space-y-3 mb-4">
              <div>
                <label htmlFor="expense-label" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Description</label>
                <input
                  id="expense-label"
                  type="text"
                  required
                  placeholder="E.g., Vet bill, food"
                  value={newExpenseLabel}
                  onChange={(e) => setNewExpenseLabel(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label htmlFor="expense-amount" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Amount ($)</label>
                <input
                  id="expense-amount"
                  type="number"
                  required
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={newExpenseAmount}
                  onChange={(e) => setNewExpenseAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  role="switch"
                  aria-label="Recurring expense"
                  aria-checked={newExpenseRecurring}
                  onClick={() => setNewExpenseRecurring(v => !v)}
                  className={`relative w-9 h-5 rounded-full motion-safe:transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${newExpenseRecurring ? 'bg-emerald-500' : 'bg-stone-300 dark:bg-stone-600'}`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow motion-safe:transition-transform ${newExpenseRecurring ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
                <span className="text-sm text-emerald-800 dark:text-emerald-200 select-none">Recurring</span>
              </div>
              {newExpenseRecurring && (
                <div>
                  <label htmlFor="expense-frequency" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Frequency</label>
                  <select
                    id="expense-frequency"
                    value={newExpenseFrequency}
                    onChange={(e) => setNewExpenseFrequency(e.target.value as typeof newExpenseFrequency)}
                    className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option>Weekly</option>
                    <option>Bi-weekly</option>
                    <option>Monthly</option>
                    <option>Yearly</option>
                  </select>
                </div>
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => { setShowExpenseForm(false); setNewExpenseRecurring(false); }}
                  className="flex-1 py-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 rounded-lg hover:bg-emerald-200/50 dark:hover:bg-emerald-800/50 motion-safe:transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1.5 text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg motion-safe:transition-colors"
                >
                  Save
                </button>
              </div>
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setShowExpenseForm(true)}
              className="w-full py-2 mb-4 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/80 rounded-lg motion-safe:transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Expense
            </button>
          )}
          {(() => {
            const recurring = expenses.filter(e => e.recurring);
            if (!recurring.length) return null;
            return (
              <div className="mb-3 p-3 bg-emerald-100/60 dark:bg-emerald-900/20 rounded-xl border border-emerald-200 dark:border-emerald-800/50">
                <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-2 uppercase tracking-wide">Recurring</p>
                <div className="space-y-1.5">
                  {recurring.map(e => (
                    <div key={e.id} className="flex items-center justify-between text-xs">
                      <div>
                        <span className="font-medium text-stone-800 dark:text-stone-200">{e.label}</span>
                        <span className="text-emerald-600 dark:text-emerald-400 ml-1">· {e.frequency}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-stone-700 dark:text-stone-300">${e.amount.toFixed(2)}</span>
                        <button
                          type="button"
                          onClick={() => { if (window.confirm(`Stop recurring expense "${e.label}"? This cannot be undone.`)) stopRecurring(e.id); }}
                          aria-label={`Stop recurring expense ${e.label}`}
                          className="text-rose-400 hover:text-rose-600 dark:hover:text-rose-300 text-xs font-semibold uppercase tracking-wide border border-rose-200 dark:border-rose-800 px-1.5 py-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                        >
                          Stop
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
          <div className="space-y-3">
            {expenses.filter(e => !e.recurring).slice(0, 5).map((expense) => (
              <div key={expense.id} className="flex items-center justify-between text-sm py-1 border-b border-emerald-100/50 dark:border-emerald-800/50 last:border-0">
                <div>
                  <p className="font-medium text-stone-900 dark:text-stone-100">{expense.label}</p>
                  <p className="text-xs text-stone-500 dark:text-stone-400">{new Date(expense.date).toLocaleDateString()}</p>
                </div>
                <span className="font-medium text-stone-900 dark:text-stone-100">${expense.amount.toFixed(2)}</span>
              </div>
            ))}
            {expenses.filter(e => !e.recurring).length > 5 && (
              <Link to="/settings" className="block text-xs text-emerald-600 dark:text-emerald-400 font-medium hover:underline pt-1">
                View all {expenses.filter(e => !e.recurring).length} expenses
              </Link>
            )}
            {expenses.length === 0 && !showExpenseForm && (
              <p className="text-sm text-center text-emerald-600/70 dark:text-emerald-400/70 py-2">No expenses yet</p>
            )}
          </div>
        </section>
      );
      case 'groups': return (
        <section className={`${GLASS_CARD} p-6`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-violet-500" /> My Groups
            </h2>
            <Link to="/community" className="text-xs text-violet-600 dark:text-violet-400 hover:underline font-medium">View All</Link>
          </div>
          {myGroups.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-sm text-stone-400 dark:text-stone-500 mb-3">You haven't joined any groups yet.</p>
              <Link to="/community" className="text-sm text-violet-600 dark:text-violet-400 font-medium hover:underline">Browse groups</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {myGroups.map(g => (
                <Link key={g.id} to={`/community/groups/${g.id}`} className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50/80 dark:hover:bg-stone-700/50 motion-safe:transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-violet-700 dark:text-violet-300">
                    {g.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-stone-800 dark:text-stone-200 truncate">{g.name}</p>
                    <p className="text-xs text-stone-400 dark:text-stone-500">{Object.keys(g.members).length} member{Object.keys(g.members).length !== 1 ? 's' : ''}</p>
                  </div>
                  {g.tags?.[0] && <span className="text-xs bg-violet-50 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 px-2 py-0.5 rounded-full shrink-0">{g.tags[0]}</span>}
                </Link>
              ))}
            </div>
          )}
        </section>
      );
      case 'friends': return (
        <section className={`${GLASS_CARD} p-6`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-pink-500" /> Friends
            </h2>
            <Link to="/community" className="text-xs text-pink-600 dark:text-pink-400 hover:underline font-medium">View All</Link>
          </div>
          {myFriends.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-sm text-stone-400 dark:text-stone-500 mb-3">No friends added yet.</p>
              <Link to="/community" className="text-sm text-pink-600 dark:text-pink-400 font-medium hover:underline">Find people</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {myFriends.map(f => (
                <Link key={f.uid} to="/community" className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50/80 dark:hover:bg-stone-700/50 motion-safe:transition-colors">
                  {f.avatarUrl ? (
                    <img src={f.avatarUrl} alt={f.displayName} width={36} height={36} className="w-9 h-9 rounded-full object-cover shrink-0" />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-pink-100 dark:bg-pink-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-pink-700 dark:text-pink-300">
                      {f.displayName?.charAt(0).toUpperCase() ?? '?'}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-stone-800 dark:text-stone-200 truncate">{f.displayName}</p>
                    {f.pets.length > 0 && <p className="text-xs text-stone-400 dark:text-stone-500">{f.pets.map(p => `${p.count} ${p.type}`).join(', ')}</p>}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      );
      case 'quick_actions': return (
        <section className={`${GLASS_CARD} p-6`}>
          <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setIsModalOpen(true)} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-100 dark:border-emerald-900/50 text-emerald-700 dark:text-emerald-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
              <Plus className="w-5 h-5" aria-hidden="true" />
              <span className="text-xs font-semibold">Add Pet</span>
            </button>
            <button onClick={() => navigate('/messages')} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-sky-50 dark:bg-sky-950/30 hover:bg-sky-100 dark:hover:bg-sky-900/40 border border-sky-100 dark:border-sky-900/50 text-sky-700 dark:text-sky-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
              <MessageSquare className="w-5 h-5" aria-hidden="true" />
              <span className="text-xs font-semibold">Messages</span>
            </button>
            <button onClick={() => navigate('/search')} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-violet-50 dark:bg-violet-950/30 hover:bg-violet-100 dark:hover:bg-violet-900/40 border border-violet-100 dark:border-violet-900/50 text-violet-700 dark:text-violet-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
              <MapPin className="w-5 h-5" aria-hidden="true" />
              <span className="text-xs font-semibold">Find Services</span>
            </button>
            <button onClick={() => setIsEmergencyOpen(true)} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/40 border border-rose-100 dark:border-rose-900/50 text-rose-700 dark:text-rose-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
              <ShieldAlert className="w-5 h-5" aria-hidden="true" />
              <span className="text-xs font-semibold">Emergency</span>
            </button>
          </div>
        </section>
      );
      default: return null;
    }
  }

  return (
    <>
      <motion.div
        initial={prefersReduced ? false : { opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="space-y-8"
      >
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">
              {greeting}, {user?.displayName?.split(' ')[0] || 'Pet Parent'}!
            </h1>
            <p className="text-stone-500 dark:text-stone-400 mt-1">
              Here's what's happening with your furry friends today.
            </p>
          </div>
          <button
            onClick={() => setEditMode(v => !v)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium motion-safe:transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 self-start md:self-auto ${
              editMode
                ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
                : 'border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-800'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            {editMode ? 'Done' : 'Edit Layout'}
          </button>
        </header>

        {/* Emergency Assistance */}
        <button
          onClick={() => setIsEmergencyOpen(true)}
          className="w-full flex items-center gap-4 bg-rose-50/80 hover:bg-rose-100/80 dark:bg-rose-950/30 dark:hover:bg-rose-900/40 backdrop-blur-sm border border-rose-200/60 dark:border-rose-900/50 p-4 rounded-2xl motion-safe:transition-colors text-left"
        >
          <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/50 rounded-xl flex items-center justify-center shrink-0">
            <ShieldAlert className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          </div>
          <div>
            <h3 className="font-bold text-rose-900 dark:text-rose-100">Emergency Assistance</h3>
            <p className="text-sm text-rose-700 dark:text-rose-300">24/7 ER vet · ASPCA poison control · Pet Poison Helpline</p>
          </div>
        </button>

        {/* Alert modules — non-draggable, visibility-toggleable in edit mode */}
        {editMode && (
          <div className="flex flex-col gap-3">
            {(['safety_alerts', 'lost_pet'] as AlertModuleKey[]).map(key => (
              <div key={key} className="flex items-center justify-between px-4 py-2.5 bg-stone-900/85 dark:bg-stone-950/90 backdrop-blur-sm rounded-2xl">
                <span className="text-xs font-semibold text-stone-300 uppercase tracking-widest">{MODULE_LABELS[key]}</span>
                <button
                  onClick={() => toggleModule(key, !moduleVisibility[key])}
                  className="p-1.5 rounded-lg text-stone-400 hover:text-stone-200 motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                  aria-label={moduleVisibility[key] ? `Hide ${MODULE_LABELS[key]}` : `Show ${MODULE_LABELS[key]}`}
                >
                  {moduleVisibility[key] ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Community Safety Alerts */}
        {moduleVisibility.safety_alerts && safetyAlerts.length > 0 && (
          <section aria-label="Community safety alerts">
            <div className="flex items-center gap-2 mb-3">
              <TriangleAlert className="w-4 h-4 text-amber-500" aria-hidden="true" />
              <h2 className="text-sm font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider">
                Local Safety Alerts
              </h2>
              <span className="ml-auto text-xs text-stone-400">{safetyAlerts.length} near you</span>
            </div>
            <div className="space-y-2">
              {safetyAlerts.slice(0, 3).map(alert => (
                <div
                  key={alert.id}
                  className={`${GLASS_CARD} flex items-start gap-3 p-4`}
                >
                  <div className="mt-0.5 shrink-0">
                    <TriangleAlert className={`w-4 h-4 ${alert.severity === 'high' ? 'text-rose-500' : alert.severity === 'medium' ? 'text-amber-500' : 'text-sky-500'}`} aria-hidden="true" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-stone-900 dark:text-stone-100">{alert.title}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[alert.category]}`}>
                        {CATEGORY_LABELS[alert.category]}
                      </span>
                    </div>
                    <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 line-clamp-2">{alert.description}</p>
                    <p className="text-xs text-stone-400 mt-1">
                      {new Date(alert.createdAt).toLocaleDateString()} · expires {new Date(alert.expiresAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Lost Pet Banner */}
        {moduleVisibility.lost_pet && lostPet && (
          <LostPetBanner lostPet={lostPet} />
        )}

        {/* Getting Started Guide */}
        {!guideCompleted && (
          <GettingStartedGuide onComplete={handleGuideComplete} />
        )}

        {/* Recommendation Banner */}
        {guideCompleted && <RecommendationBanner />}

        {/* Grid widgets — normal vs edit mode */}
        {editMode ? (
          <div>
            <Reorder.Group
              axis="y"
              values={gridOrder.filter(k => moduleVisibility[k])}
              onReorder={reorderModule}
              className="flex flex-col gap-4"
            >
              {gridOrder.filter(k => moduleVisibility[k]).map(key => (
                <DraggableWidget
                  key={key}
                  moduleKey={key}
                  editMode={true}
                  onHide={() => toggleModule(key, false)}
                >
                  {renderWidget(key)}
                </DraggableWidget>
              ))}
            </Reorder.Group>

            {gridOrder.some(k => !moduleVisibility[k]) && (
              <div className="mt-4">
                <p className="text-xs font-semibold text-stone-400 uppercase tracking-widest mb-3">Hidden Widgets</p>
                <div className="flex flex-wrap gap-2">
                  {gridOrder.filter(k => !moduleVisibility[k]).map(key => (
                    <button
                      key={key}
                      onClick={() => toggleModule(key, true)}
                      className="flex items-center gap-2 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-white/50 dark:bg-stone-900/50 text-stone-600 dark:text-stone-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:border-emerald-300 dark:hover:border-emerald-800 hover:text-emerald-700 dark:hover:text-emerald-400 motion-safe:transition-colors text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {MODULE_LABELS[key]}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {gridOrder.filter(k => moduleVisibility[k]).map(key => (
              <div key={key} className={wideKeys.includes(key) ? 'lg:col-span-2' : ''}>
                {renderWidget(key)}
              </div>
            ))}
          </div>
        )}
      </motion.div>

      <PetFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={addPet}
      />
      <CalendarModal
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        events={upcomingEvents}
      />
      <AnimatePresence>
        {isEmergencyOpen && (
          <EmergencyModal
            onClose={() => setIsEmergencyOpen(false)}
            onFindVet={() => navigate('/search?tab=services&filters=Emergency,24%2F7')}
          />
        )}
      </AnimatePresence>
    </>
  );
}

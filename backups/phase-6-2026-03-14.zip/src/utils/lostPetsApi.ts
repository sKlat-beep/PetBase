export interface LostPetAlert {
  id: string;
  petName: string;
  petType: string;
  breed: string;
  image: string;
  ownerName: string;
  ownerPhone: string;
  lastSeenLocation: string;
  reportedAt: number;
  zipCode: string;
}

const GRACE_PERIOD = 15 * 60 * 1000;        // 15 minutes
const EXPIRATION   = 3 * 24 * 60 * 60 * 1000; // 3 days

/**
 * Reads all alerts from localStorage, purges expired entries (older than 3 days),
 * writes the cleaned list back, then returns active alerts for the given zip code.
 *
 * Purging on read ensures stale data doesn't accumulate indefinitely, reducing
 * the localStorage attack surface for sensitive lost-pet information.
 */
export async function getActiveLostPets(zipCode: string): Promise<LostPetAlert[]> {
  try {
    const raw = localStorage.getItem('petbase-lost-pets');
    const all: LostPetAlert[] = raw ? JSON.parse(raw) : [];
    const now = Date.now();

    // Separate expired from live — purge expired entries
    const live = all.filter(a => (now - a.reportedAt) <= EXPIRATION);
    if (live.length < all.length) {
      localStorage.setItem('petbase-lost-pets', JSON.stringify(live));
    }

    return live
      .filter(alert => {
        const matchesZip = !zipCode || alert.zipCode === zipCode;
        const isPastGrace = (now - alert.reportedAt) >= GRACE_PERIOD;
        return matchesZip && isPastGrace;
      })
      .sort((a, b) => b.reportedAt - a.reportedAt);
  } catch {
    return [];
  }
}

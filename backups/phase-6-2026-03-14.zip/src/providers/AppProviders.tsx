import React from 'react';
import { AuthProvider } from '../contexts/AuthContext';
import { ThemeProvider } from '../contexts/ThemeContext';
import { PetProvider } from '../contexts/PetContext';
import { CommunityProvider } from '../contexts/CommunityContext';
import { SocialProvider } from '../contexts/SocialContext';
import { ExpenseProvider } from '../contexts/ExpenseContext';
import { SafetyAlertsProvider } from '../contexts/SafetyAlertsContext';
import { HouseholdProvider } from '../contexts/HouseholdContext';
import { MessagingProvider } from '../contexts/MessagingContext';

interface AppProvidersProps {
    children: React.ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
    return (
        <AuthProvider>
            <ThemeProvider>
                <PetProvider>
                    <ExpenseProvider>
                        <CommunityProvider>
                            <SafetyAlertsProvider>
                                <SocialProvider>
                                    <HouseholdProvider>
                                        <MessagingProvider>
                                            {children}
                                        </MessagingProvider>
                                    </HouseholdProvider>
                                </SocialProvider>
                            </SafetyAlertsProvider>
                        </CommunityProvider>
                    </ExpenseProvider>
                </PetProvider>
            </ThemeProvider>
        </AuthProvider>
    );
}

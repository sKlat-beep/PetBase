import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { useAuth } from './AuthContext';

export interface PublicProfile {
    uid: string;
    displayName: string;
    username?: string;
    avatarUrl: string;
    visibility: 'Public' | 'Friends Only' | 'Private';
    publicStatus: 'None' | 'Open to Playdates' | 'Looking for Walking Buddies';
    pets: { type: string; count: number }[];
}

import { searchPublicProfiles, type PublicProfileInfo } from '../lib/firestoreService';
import { getAvatarUrl } from '../lib/tokenService';

export interface FriendRequest {
    id: string;
    fromUid: string;
    toUid: string;
    status: 'pending' | 'accepted' | 'rejected';
    createdAt: number;
}

export interface Message {
    id: string;
    fromUid: string;
    toUid: string;
    content: string;
    createdAt: number;
    read: boolean;
}

interface SocialContextValue {
    directory: PublicProfile[];
    friendRequests: FriendRequest[];
    messages: Message[];
    searchUsers: (query: string) => Promise<PublicProfile[]>;
    sendMessage: (toUid: string, content: string) => void;
    sendFriendRequest: (toUid: string) => void;
    acceptFriendRequest: (requestId: string) => void;
    removeFriend: (friendUid: string) => void;
    blockUser: (targetUid: string) => void;
    unblockUser: (targetUid: string) => void;
    markMessagesRead: (fromUid: string) => void;
}

const SocialContext = createContext<SocialContextValue | null>(null);

const STORAGE_KEY_FRIENDS = 'petbase_friend_reqs';
const STORAGE_KEY_MESSAGES = 'petbase_messages';


function loadLocal<T>(key: string, fallback: T): T {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : fallback;
    } catch {
        return fallback;
    }
}

function saveLocal<T>(key: string, data: T) {
    localStorage.setItem(key, JSON.stringify(data));
}

export function SocialProvider({ children }: { children: ReactNode }) {
    const { user, profile, updateProfile } = useAuth();
    const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
    const [messages, setMessages] = useState<Message[]>([]);
    const [directory, setDirectory] = useState<PublicProfile[]>([]);

    // Load real public profiles from Firestore for the directory
    useEffect(() => {
        if (!user) return;
        searchPublicProfiles('').then(rawProfiles => {
            const mapped: PublicProfile[] = rawProfiles
                .filter(p => p.uid !== user.uid && p.visibility !== 'Private')
                .map(p => ({
                    uid: p.uid,
                    displayName: p.displayName,
                    username: p.username,
                    avatarUrl: '', // resolved lazily via tokenService.getAvatarUrl(uid)
                    visibility: p.visibility as PublicProfile['visibility'],
                    publicStatus: p.publicStatus as PublicProfile['publicStatus'],
                    pets: [],
                }));
            setDirectory(mapped);
        }).catch(() => { /* silent fail — directory stays empty */ });
    }, [user]);

    useEffect(() => {
        setFriendRequests(loadLocal(STORAGE_KEY_FRIENDS, []));
        setMessages(loadLocal(STORAGE_KEY_MESSAGES, []));
    }, []);

    useEffect(() => {
        saveLocal(STORAGE_KEY_FRIENDS, friendRequests);
    }, [friendRequests]);

    useEffect(() => {
        saveLocal(STORAGE_KEY_MESSAGES, messages);
    }, [messages]);

    const searchUsers = useCallback(async (query: string): Promise<PublicProfile[]> => {
        if (!profile) return [];

        try {
            const rawProfiles = await searchPublicProfiles(query);
            const filtered = rawProfiles.filter(p => {
                // 1. Don't return self
                if (user && p.uid === user.uid) return false;

                // 2. Hide private profiles
                if (p.visibility === 'Private') return false;

                // 3. Hide blocked users
                if (profile.blockedUsers.includes(p.uid)) return false;

                // 4. Friends Only check
                if (p.visibility === 'Friends Only' && !profile.friends.includes(p.uid)) {
                    return false;
                }

                return true;
            });

            // Resolve all avatars concurrently for performance
            return Promise.all(filtered.map(async (p) => ({
                uid: p.uid,
                displayName: p.displayName,
                username: p.username,
                avatarUrl: await getAvatarUrl(p.uid, p.avatarUrl), // Task-20 compliant; fallback handled inside tokenService
                visibility: p.visibility as any,
                publicStatus: p.publicStatus as any,
                pets: [],
            })));
        } catch (err) {
            console.error('Failed to search users', err);
            return [];
        }
    }, [profile, user]);

    const sendMessage = useCallback((toUid: string, content: string) => {
        if (!user) return;
        const newMsg: Message = {
            id: Math.random().toString(36).substr(2, 9),
            fromUid: user.uid,
            toUid,
            content,
            createdAt: Date.now(),
            read: false
        };
        setMessages(prev => [...prev, newMsg]);
    }, [user]);

    const markMessagesRead = useCallback((fromUid: string) => {
        if (!user) return;
        setMessages(prev => prev.map(m =>
            (m.toUid === user.uid && m.fromUid === fromUid) ? { ...m, read: true } : m
        ));
    }, [user]);

    const sendFriendRequest = useCallback((toUid: string) => {
        if (!user) return;
        const newReq: FriendRequest = {
            id: Math.random().toString(36).substr(2, 9),
            fromUid: user.uid,
            toUid,
            status: 'pending',
            createdAt: Date.now()
        };
        setFriendRequests(prev => [...prev, newReq]);
    }, [user]);

    const acceptFriendRequest = useCallback((requestId: string) => {
        if (!user || !profile) return;
        setFriendRequests(prev => {
            const updated = prev.map(req => req.id === requestId ? { ...req, status: 'accepted' as const } : req);
            const req = updated.find(r => r.id === requestId);
            if (req && req.toUid === user.uid) {
                // Add to friends list
                updateProfile({ friends: [...profile.friends, req.fromUid] });
            }
            return updated;
        });
    }, [user, profile, updateProfile]);

    const removeFriend = useCallback((friendUid: string) => {
        if (!profile) return;
        updateProfile({
            friends: profile.friends.filter(id => id !== friendUid)
        });
        // Cleanup requests involving this friend
        setFriendRequests(prev => prev.filter(req =>
            !(req.fromUid === friendUid || req.toUid === friendUid)
        ));
    }, [profile, updateProfile]);

    const blockUser = useCallback((targetUid: string) => {
        if (!profile) return;
        if (!profile.blockedUsers.includes(targetUid)) {
            updateProfile({ blockedUsers: [...profile.blockedUsers, targetUid] });
        }
    }, [profile, updateProfile]);

    const unblockUser = useCallback((targetUid: string) => {
        if (!profile) return;
        updateProfile({
            blockedUsers: profile.blockedUsers.filter(id => id !== targetUid)
        });
    }, [profile, updateProfile]);

    return (
        <SocialContext.Provider value={{
            directory,
            friendRequests,
            messages,
            searchUsers,
            sendMessage,
            sendFriendRequest,
            acceptFriendRequest,
            removeFriend,
            blockUser,
            unblockUser,
            markMessagesRead
        }}>
            {children}
        </SocialContext.Provider>
    );
}

export const useSocial = () => useContext(SocialContext)!;

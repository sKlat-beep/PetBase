﻿import { Outlet, NavLink, Link, useNavigate } from 'react-router';
import { Home, PawPrint, Users, Search as SearchIcon, IdCard, Bell, Menu, LogOut, UserSearch, Syringe, MessageCircle, MessageSquare, UserPlus, HelpCircle, X } from 'lucide-react'; // X added for search clear button
import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePets } from '../contexts/PetContext';
import { useSocial, type PublicProfile } from '../contexts/SocialContext';
import { useMessaging } from '../contexts/MessagingContext';
import { getVaccineStatus, type Vaccine } from './MedicalRecordsModal';
import { HelpModal } from './HelpModal';
import { FeedbackModal } from './FeedbackModal';
import { AnimatePresence } from 'motion/react';

interface NotifDropdownProps {
  urgentVaccines: { petName: string; vaccineName: string; status: string }[];
  unreadMessages: { id: string; fromUid: string; content: string }[];
  pendingRequests: { id: string; fromUid: string }[];
  onClose: () => void;
  onNavigate: (path: string) => void;
  /** 'left' anchors the dropdown's left edge to the button (opens rightward — for sidebar).
   *  'right' anchors the dropdown's right edge to the button (opens leftward — for mobile header).
   *  Defaults to 'right'. */
  side?: 'left' | 'right';
}

function NotificationsDropdown({ urgentVaccines, unreadMessages, pendingRequests, onNavigate, side = 'right' }: NotifDropdownProps) {
  const hasAny = urgentVaccines.length > 0 || unreadMessages.length > 0 || pendingRequests.length > 0;
  return (
    <div className={`absolute ${side === 'left' ? 'left-0' : 'right-0'} top-8 w-80 max-w-[calc(100vw-1rem)] bg-white dark:bg-zinc-800 rounded-2xl shadow-2xl border border-stone-200 dark:border-zinc-700 z-50 overflow-hidden`}>
      <div className="p-4 border-b border-stone-100 dark:border-zinc-700 flex items-center justify-between">
        <h3 className="font-bold text-stone-900 dark:text-zinc-100 text-sm">Notifications</h3>
        {hasAny && <span className="text-xs text-stone-400">{urgentVaccines.length + unreadMessages.length + pendingRequests.length} items</span>}
      </div>
      <div className="max-h-80 overflow-y-auto divide-y divide-stone-100 dark:divide-zinc-700">
        {urgentVaccines.map((v, i) => (
          <button
            key={`vax-${i}`}
            onClick={() => onNavigate('/pets')}
            className="w-full flex items-start gap-3 p-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${v.status === 'overdue' ? 'bg-rose-100 dark:bg-rose-900/30' : 'bg-amber-100 dark:bg-amber-900/30'}`}>
              <Syringe className={`w-4 h-4 ${v.status === 'overdue' ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'}`} />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-stone-900 dark:text-zinc-100 truncate">{v.vaccineName}</p>
              <p className="text-xs text-stone-500 dark:text-zinc-400">{v.petName} &middot; {v.status === 'overdue' ? 'Overdue' : 'Due soon'}</p>
            </div>
          </button>
        ))}
        {pendingRequests.map((r) => (
          <button
            key={`req-${r.id}`}
            onClick={() => onNavigate('/people')}
            className="w-full flex items-start gap-3 p-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
              <UserPlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-stone-900 dark:text-zinc-100">New friend request</p>
              <p className="text-xs text-stone-500 dark:text-zinc-400">Tap to view in People</p>
            </div>
          </button>
        ))}
        {unreadMessages.map((m) => (
          <button
            key={`msg-${m.id}`}
            onClick={() => onNavigate('/people')}
            className="w-full flex items-start gap-3 p-3 hover:bg-stone-50 dark:hover:bg-zinc-700/50 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center shrink-0">
              <MessageCircle className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-stone-900 dark:text-zinc-100">New message</p>
              <p className="text-xs text-stone-500 dark:text-zinc-400 truncate">{m.content}</p>
            </div>
          </button>
        ))}
        {!hasAny && (
          <div className="p-6 text-center text-stone-400 dark:text-zinc-500 text-sm">
            No new notifications
          </div>
        )}
      </div>
    </div>
  );
}

export function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const { user, profile, signOut } = useAuth();
  const { pets } = usePets();
  const { friendRequests, searchUsers } = useSocial();
  const { conversations, totalUnread: totalUnreadMessages } = useMessaging();
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<PublicProfile[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Close notification dropdown when clicking anywhere outside
  useEffect(() => {
    if (!notifOpen) return;
    function handleClick() { setNotifOpen(false); }
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, [notifOpen]);

  // Debounced search
  useEffect(() => {
    if (!searchQuery.trim()) { setSearchResults([]); setSearchOpen(false); return; }
    const t = setTimeout(() => {
      searchUsers(searchQuery).then(results => {
        setSearchResults(results.filter(u => u.visibility !== 'Private'));
        setSearchOpen(true);
      });
    }, 300);
    return () => clearTimeout(t);
  }, [searchQuery, searchUsers]);

  // Close search on outside click or Escape
  useEffect(() => {
    if (!searchOpen) return;
    function handleKey(e: KeyboardEvent) { if (e.key === 'Escape') { setSearchOpen(false); setSearchQuery(''); } }
    function handleClick(e: MouseEvent) { if (searchRef.current && !searchRef.current.contains(e.target as Node)) { setSearchOpen(false); } }
    document.addEventListener('keydown', handleKey);
    document.addEventListener('mousedown', handleClick);
    return () => { document.removeEventListener('keydown', handleKey); document.removeEventListener('mousedown', handleClick); };
  }, [searchOpen]);

  const handleSearchSelect = useCallback((uid: string) => {
    navigate(`/people?uid=${uid}`);
    setSearchOpen(false);
    setSearchQuery('');
  }, [navigate]);

  const urgentVaccines = useMemo(() => {
    const items: { petName: string; vaccineName: string; status: string }[] = [];
    for (const pet of pets) {
      const vaccines = (pet as any).vaccines as Vaccine[] | undefined;
      if (!vaccines) continue;
      for (const v of vaccines) {
        const status = getVaccineStatus(v.nextDueDate);
        if (status === 'overdue' || status === 'due-soon') {
          items.push({ petName: pet.name, vaccineName: v.name, status });
        }
      }
    }
    return items.slice(0, 5);
  }, [pets]);

  const unreadMessages = useMemo(
    () => conversations
      .filter(c => c.lastMessage.toUid === user?.uid && !c.lastMessage.read)
      .map(c => ({ id: c.lastMessage.id, fromUid: c.lastMessage.fromUid, content: c.lastMessage.content })),
    [conversations, user?.uid]
  );

  const pendingRequests = useMemo(
    () => friendRequests.filter(r => r.toUid === user?.uid && r.status === 'pending'),
    [friendRequests, user?.uid]
  );

  const totalNotifications = urgentVaccines.length + unreadMessages.length + pendingRequests.length;

  const navItems = [
    { to: '/', icon: Home, label: 'Dashboard' },
    { to: '/pets', icon: PawPrint, label: 'My Pets' },
    { to: '/community', icon: Users, label: 'Community' },
    { to: '/people', icon: UserSearch, label: 'People' },
    { to: '/messages', icon: MessageSquare, label: 'Messages', badge: totalUnreadMessages > 0 ? totalUnreadMessages : undefined },
    { to: '/search', icon: SearchIcon, label: 'Find Services' },
    { to: '/cards', icon: IdCard, label: 'Pet Cards' },
  ];

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-zinc-900 text-stone-900 dark:text-zinc-100 flex flex-col md:flex-row font-sans">
      {/* Skip navigation — visually hidden, shown on keyboard focus for screen readers */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2 focus:bg-emerald-600 focus:text-white focus:rounded-lg focus:font-semibold focus:shadow-lg"
      >
        Skip to main content
      </a>
      {/* Mobile Header */}
      <header className="md:hidden bg-white dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-700 p-4 flex items-center justify-between sticky top-0 z-50">
        <Link to="/" className="flex items-center gap-2 text-emerald-600 font-bold text-xl hover:opacity-80 transition-opacity">
          <PawPrint className="w-6 h-6" />
          <span>PetBase</span>
        </Link>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileSearchOpen(o => !o)}
            className="text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-100"
            aria-label="Search users"
          >
            <SearchIcon className="w-5 h-5" />
          </button>
          <div className="relative">
            <button
              onClick={(e) => { e.stopPropagation(); setNotifOpen(o => !o); }}
              className="text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-100 relative"
              aria-label="Notifications"
            >
              <Bell className="w-6 h-6" />
              {totalNotifications > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[1.1rem] h-[1.1rem] bg-rose-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center px-0.5">
                  {totalNotifications > 9 ? '9+' : totalNotifications}
                </span>
              )}
            </button>
            {notifOpen && <NotificationsDropdown urgentVaccines={urgentVaccines} unreadMessages={unreadMessages} pendingRequests={pendingRequests} onClose={() => setNotifOpen(false)} onNavigate={(path) => { setNotifOpen(false); navigate(path); }} />}
          </div>
          <button
            aria-label="Open menu"
            className="text-stone-500 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-zinc-100"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Mobile Search Panel */}
      {mobileSearchOpen && (
        <div className="md:hidden sticky top-[65px] z-40 bg-white dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-700 px-4 py-3">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400 pointer-events-none" />
            <input
              autoFocus
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search users…"
              className="w-full pl-9 pr-8 py-2 text-sm bg-stone-100 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-stone-900 dark:text-zinc-100 placeholder:text-stone-400"
            />
            {searchQuery && (
              <button onClick={() => { setSearchQuery(''); setSearchResults([]); }} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {searchResults.length > 0 && (
            <div className="mt-2 bg-white dark:bg-zinc-800 rounded-xl shadow-lg border border-stone-200 dark:border-zinc-700 overflow-hidden">
              {searchResults.slice(0, 5).map(u => (
                <button
                  key={u.uid}
                  onClick={() => { handleSearchSelect(u.uid); setMobileSearchOpen(false); }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-stone-50 dark:hover:bg-zinc-700/60 transition-colors text-left"
                >
                  <img src={u.avatarUrl || ''} alt="" className="w-8 h-8 rounded-full bg-stone-200 dark:bg-zinc-700 shrink-0 object-cover" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-stone-900 dark:text-zinc-100 truncate">{u.displayName}</p>
                    {u.username && <p className="text-xs text-stone-400 truncate">@{u.username}</p>}
                  </div>
                </button>
              ))}
            </div>
          )}
          {searchResults.length === 0 && searchQuery.trim() && (
            <p className="mt-2 text-center text-xs text-stone-400 py-2">No users found</p>
          )}
        </div>
      )}

      {/* Sidebar (Desktop) & Mobile Menu */}
      <aside
        className={`
          ${isMobileMenuOpen ? 'block' : 'hidden'}
          md:block fixed md:sticky top-0 left-0 h-screen w-64 bg-white dark:bg-zinc-900
          border-r border-stone-200 dark:border-zinc-700 z-40
          motion-safe:transition-transform motion-safe:duration-300 motion-safe:ease-in-out flex flex-col
          pb-16 md:pb-0
        `}
      >
        <div className="p-6 hidden md:flex items-center justify-between mb-8">
          <Link to="/" className="flex items-center gap-2 text-emerald-600 font-bold text-2xl hover:opacity-80 transition-opacity">
            <PawPrint className="w-8 h-8" />
            <span>PetBase</span>
          </Link>
          <div className="relative">
            <button
              onClick={(e) => { e.stopPropagation(); setNotifOpen(o => !o); }}
              className="text-stone-400 hover:text-stone-700 dark:hover:text-zinc-200 transition-colors relative"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              {totalNotifications > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[1.1rem] h-[1.1rem] bg-rose-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center px-0.5">
                  {totalNotifications > 9 ? '9+' : totalNotifications}
                </span>
              )}
            </button>
            {notifOpen && <NotificationsDropdown side="left" urgentVaccines={urgentVaccines} unreadMessages={unreadMessages} pendingRequests={pendingRequests} onClose={() => setNotifOpen(false)} onNavigate={(path) => { setNotifOpen(false); navigate(path); }} />}
          </div>
        </div>

        {/* Global Search — desktop sidebar */}
        <div ref={searchRef} className="px-4 mb-2 hidden md:block relative">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search users…"
              className="w-full pl-9 pr-8 py-2 text-sm bg-stone-100 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-stone-900 dark:text-zinc-100 placeholder:text-stone-400"
            />
            {searchQuery && (
              <button onClick={() => { setSearchQuery(''); setSearchOpen(false); }} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {searchOpen && searchResults.length > 0 && (
            <div className="absolute left-4 right-4 top-[calc(100%+4px)] bg-white dark:bg-zinc-800 rounded-xl shadow-xl border border-stone-200 dark:border-zinc-700 z-50 overflow-hidden">
              {searchResults.slice(0, 6).map(u => (
                <button
                  key={u.uid}
                  onClick={() => handleSearchSelect(u.uid)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-stone-50 dark:hover:bg-zinc-700/60 transition-colors text-left"
                >
                  <img src={u.avatarUrl || ''} alt="" className="w-8 h-8 rounded-full bg-stone-200 dark:bg-zinc-700 shrink-0 object-cover" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-stone-900 dark:text-zinc-100 truncate">{u.displayName}</p>
                    {u.username && <p className="text-xs text-stone-400 truncate">@{u.username}</p>}
                  </div>
                </button>
              ))}
              {searchResults.length === 0 && (
                <p className="text-xs text-stone-400 text-center py-3">No users found</p>
              )}
            </div>
          )}
          {searchOpen && searchResults.length === 0 && searchQuery.trim() && (
            <div className="absolute left-4 right-4 top-[calc(100%+4px)] bg-white dark:bg-zinc-800 rounded-xl shadow-xl border border-stone-200 dark:border-zinc-700 z-50 p-3 text-center text-xs text-stone-400">
              No users found
            </div>
          )}
        </div>

        <nav className="px-4 space-y-2 mt-4 md:mt-0 flex-1" aria-label="Main navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setIsMobileMenuOpen(false)}
              className={({ isActive }) => `
                flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium
                ${isActive
                  ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400'
                  : 'text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800 hover:text-stone-900 dark:hover:text-zinc-100'
                }
              `}
            >
              <div className="relative">
                <item.icon className="w-5 h-5" />
                {'badge' in item && item.badge != null && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[1rem] h-4 bg-rose-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center px-0.5">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                )}
              </div>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-stone-200 dark:border-zinc-700">
          <div className="flex items-center justify-between px-2 py-2">
            <Link
              to="/settings"
              onClick={() => setIsMobileMenuOpen(false)}
              className="flex items-center gap-3 min-w-0 hover:opacity-80 transition-opacity"
            >
              <div className="w-10 h-10 rounded-full bg-stone-200 dark:bg-zinc-700 overflow-hidden shrink-0">
                {profile?.avatarUrl || user?.photoURL ? (
                  <img
                    src={profile?.avatarUrl || user?.photoURL || ''}
                    alt="User profile"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 font-bold">
                    {user?.displayName?.[0]?.toUpperCase() || user?.email?.[0].toUpperCase() || 'U'}
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-stone-900 dark:text-zinc-100 truncate">
                  {user?.displayName || 'Pet Parent'}
                </p>
                <p className="text-xs text-stone-500 dark:text-zinc-400 truncate">
                  {user?.email}
                </p>
              </div>
            </Link>
            <button
              onClick={signOut}
              className="text-stone-400 hover:text-rose-600 dark:hover:text-rose-400 transition-colors p-2 shrink-0"
              title="Sign Out"
              aria-label="Sign Out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>

          {/* Need Help? */}
          <button
            onClick={() => setHelpOpen(true)}
            className="flex items-center gap-2 text-xs text-stone-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors px-1 py-1 mt-1"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            Need Help?
          </button>
        </div>
      </aside>

      <AnimatePresence>
        {helpOpen && <HelpModal onClose={() => setHelpOpen(false)} onFeedback={() => setFeedbackOpen(true)} />}
        {feedbackOpen && <FeedbackModal onClose={() => setFeedbackOpen(false)} userEmail={user?.email ?? undefined} />}
      </AnimatePresence>

      {/* Mobile Bottom Nav Bar */}
      <nav
        aria-label="Mobile bottom navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-zinc-900 border-t border-stone-200 dark:border-zinc-700 flex items-stretch h-16 safe-area-inset-bottom"
      >
        {[
          { to: '/', icon: Home, label: 'Dashboard' },
          { to: '/pets', icon: PawPrint, label: 'Pets' },
          { to: '/community', icon: Users, label: 'Community' },
          { to: '/people', icon: UserSearch, label: 'People' },
          { to: '/messages', icon: MessageSquare, label: 'Messages', badge: totalUnreadMessages > 0 ? totalUnreadMessages : undefined },
          { to: '/search', icon: SearchIcon, label: 'Services' },
          { to: '/cards', icon: IdCard, label: 'Cards' },
        ].map(({ to, icon: Icon, label, badge }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            onClick={() => setIsMobileMenuOpen(false)}
            className={({ isActive }) =>
              `flex-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${isActive
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-stone-400 dark:text-zinc-500 hover:text-stone-700 dark:hover:text-zinc-300'
              }`
            }
          >
            <div className="relative">
              <Icon className="w-5 h-5" />
              {badge != null && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[1rem] h-4 bg-rose-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center px-0.5">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </div>
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Main Content */}
      <main id="main-content" className="flex-1 p-4 pb-20 md:pb-8 md:p-8 overflow-y-auto w-full max-w-7xl mx-auto">
        <Outlet />
      </main>
    </div>
  );
}

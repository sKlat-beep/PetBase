import React, { useState, useMemo, useEffect, lazy, Suspense } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useCommunity, type GroupPost, type GroupMember, type GroupEvent } from '../contexts/CommunityContext';
import { useSocial, type PublicProfile } from '../contexts/SocialContext';
import type { CommunityRole } from '../contexts/CommunityContext';
import { MessageSquare, Users, Calendar, MapPin, Settings2, Trash2, Pin, ArrowLeft, Mail, Search, ChevronDown, ChevronUp, Plus, CalendarDays, UserCheck, Repeat2 } from 'lucide-react';

const GroupRetentionModal = lazy(() => import('../components/GroupRetentionModal').then(m => ({ default: m.GroupRetentionModal })));

export function GroupHub() {
    const { groupId } = useParams<{ groupId: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const { groups, createPost, pinPost, deletePost, leaveGroup, updateMemberRole, updateGroupRetention, createEvent, rsvpEvent, deleteEvent } = useCommunity();
    const { searchUsers } = useSocial();

    const [newPostContent, setNewPostContent] = useState('');
    const [roleSearchQuery, setRoleSearchQuery] = useState('');
    const [roleSearchResults, setRoleSearchResults] = useState<PublicProfile[]>([]);
    const [showCreateEvent, setShowCreateEvent] = useState(false);
    const [eventForm, setEventForm] = useState({ title: '', date: '', location: '', description: '', recurring: false });
    const [eventSubmitting, setEventSubmitting] = useState(false);
    const [isAboutExpanded, setIsAboutExpanded] = useState(() => {
        return localStorage.getItem(`petbase_group_about_${groupId}`) !== 'false';
    });
    const [showRetentionModal, setShowRetentionModal] = useState(false);

    useEffect(() => {
        if (!roleSearchQuery) { setRoleSearchResults([]); return; }
        searchUsers(roleSearchQuery).then(setRoleSearchResults);
    }, [roleSearchQuery, searchUsers]);

    const group = useMemo(() => groups.find(g => g.id === groupId), [groups, groupId]);

    const userRole = useMemo(() => {
        if (!user || !group) return null;
        return group.members[user.uid]?.role || null;
    }, [user, group]);

    const canPin = userRole === 'Owner' || userRole === 'Moderator';
    const canDeletePost = userRole === 'Owner' || userRole === 'Moderator';
    const canManageEvents = userRole === 'Owner' || userRole === 'Moderator' || userRole === 'Event Coordinator';

    // Filter posts older than the group's configured retention period
    const recentPosts = useMemo(() => {
        if (!group) return [];
        const retentionMs = (group.retentionDays ?? 365) * 24 * 60 * 60 * 1000;
        return group.posts.filter(p => Date.now() - p.createdAt < retentionMs);
    }, [group]);

    const pinnedPosts = useMemo(() => recentPosts.filter(p => p.isPinned), [recentPosts]);
    const regularPosts = useMemo(() => recentPosts.filter(p => !p.isPinned), [recentPosts]);

    const upcomingEvents = useMemo(() => {
        if (!group) return [];
        const now = Date.now();
        return [...group.events]
            .filter(e => new Date(e.date).getTime() >= now - 86400000) // within past 24h or future
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }, [group]);

    if (!group) {
        return (
            <div className="text-center py-20">
                <h2 className="text-2xl font-bold text-stone-900 dark:text-stone-100">Group not found</h2>
                <Link to="/community" className="text-emerald-600 hover:underline mt-4 inline-block">Return to Community</Link>
            </div>
        );
    }

    const handlePost = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newPostContent.trim()) return;
        createPost(group.id, newPostContent.trim());
        setNewPostContent('');
    };

    const handleCreateEvent = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!eventForm.title.trim() || !eventForm.date || eventSubmitting) return;
        setEventSubmitting(true);
        await createEvent(group.id, {
            title: eventForm.title.trim(),
            date: new Date(eventForm.date).toISOString(),
            location: eventForm.location.trim(),
            description: eventForm.description.trim(),
        });
        setEventSubmitting(false);
        setEventForm({ title: '', date: '', location: '', description: '', recurring: false });
        setShowCreateEvent(false);
    };

    const ownersAndMods = (Object.values(group.members) as GroupMember[]).filter(m => m.role === 'Owner' || m.role === 'Moderator');

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8 max-w-5xl mx-auto"
        >
            <header className="flex items-center gap-4">
                <button onClick={() => navigate('/community')} aria-label="Back to Community" className="p-2 bg-white dark:bg-stone-800 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                    <ArrowLeft className="w-5 h-5 text-stone-600 dark:text-stone-300" />
                </button>
                <div className="flex-1">
                    <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">
                        {group.name}
                    </h1>
                    <p className="text-stone-500 dark:text-stone-400 mt-1 flex items-center gap-2">
                        <Users className="w-4 h-4" /> {Object.keys(group.members).length} members
                        {userRole && <span className="ml-2 px-2 py-0.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400 rounded-md text-xs font-semibold">{userRole}</span>}
                    </p>
                </div>
                {userRole === 'Owner' && (
                    <button
                        onClick={() => setShowRetentionModal(true)}
                        aria-label="Group settings"
                        className="p-2 bg-white dark:bg-stone-800 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                    >
                        <Settings2 className="w-5 h-5 text-stone-500 dark:text-stone-400" />
                    </button>
                )}
            </header>

            {/* Minimizable About Section */}
            <div className="bg-white dark:bg-stone-800 rounded-2xl overflow-hidden shadow-sm border border-stone-100 dark:border-stone-700">
                <button
                    onClick={() => {
                        const next = !isAboutExpanded;
                        setIsAboutExpanded(next);
                        localStorage.setItem(`petbase_group_about_${groupId}`, String(next));
                    }}
                    className="w-full p-4 flex items-center justify-between hover:bg-stone-50 dark:hover:bg-stone-900/50 transition-colors"
                >
                    <div className="flex items-center gap-3">
                        <img src={group.image} alt={group.name} className="w-10 h-10 rounded-xl object-cover" />
                        <h3 className="font-bold text-stone-900 dark:text-stone-100">About Group</h3>
                    </div>
                    {isAboutExpanded ? <ChevronUp className="w-5 h-5 text-stone-400" /> : <ChevronDown className="w-5 h-5 text-stone-400" />}
                </button>
                <AnimatePresence>
                    {isAboutExpanded && (
                        <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                        >
                            <div className="p-5 pt-2 border-t border-stone-100 dark:border-stone-700">
                                <p className="text-sm text-stone-600 dark:text-stone-400">{group.description}</p>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Feed Column */}
                <div className="lg:col-span-2 space-y-6">

                    {userRole && (
                        <div className="bg-white dark:bg-stone-800 rounded-2xl p-4 shadow-sm border border-stone-100 dark:border-stone-700">
                            <form onSubmit={handlePost} className="flex gap-3">
                                <img src={user?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.uid}`} alt="You" className="w-10 h-10 rounded-full bg-stone-100" />
                                <div className="flex-1">
                                    <textarea
                                        value={newPostContent}
                                        onChange={(e) => setNewPostContent(e.target.value)}
                                        placeholder="Share something with the group..."
                                        rows={2}
                                        className="w-full px-4 py-3 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-900/50 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors resize-none"
                                    />
                                    <div className="flex justify-end mt-2">
                                        <button
                                            type="submit"
                                            disabled={!newPostContent.trim()}
                                            className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 dark:disabled:bg-stone-600 text-white px-5 py-2 rounded-lg font-medium text-sm transition-colors min-h-[44px]"
                                        >
                                            Post
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    )}

                    {/* Pinned Posts */}
                    {pinnedPosts.length > 0 && (
                        <div className="space-y-4">
                            <h3 className="text-sm font-bold text-stone-500 uppercase tracking-wider flex items-center gap-2">
                                <Pin className="w-4 h-4" /> Pinned
                            </h3>
                            {pinnedPosts.map(post => (
                                <PostCard key={post.id} post={post} groupId={group.id} canPin={canPin} canDelete={canDeletePost} pinPost={pinPost} deletePost={deletePost} isAuthor={post.authorId === user?.uid} />
                            ))}
                        </div>
                    )}

                    {/* Regular Feed */}
                    <div className="space-y-4">
                        {pinnedPosts.length > 0 && regularPosts.length > 0 && (
                            <h3 className="text-sm font-bold text-stone-500 uppercase tracking-wider mt-8">Recent Discussions</h3>
                        )}
                        {regularPosts.length === 0 && pinnedPosts.length === 0 ? (
                            <div className="text-center py-12 bg-white dark:bg-stone-800 rounded-2xl border border-dashed border-stone-200 dark:border-stone-700 text-stone-400">
                                <MessageSquare className="w-8 h-8 mx-auto mb-3 opacity-50" />
                                <p>No recent discussions.</p>
                                <p className="text-sm">Be the first to start a conversation!</p>
                            </div>
                        ) : (
                            regularPosts.map(post => (
                                <PostCard key={post.id} post={post} groupId={group.id} canPin={canPin} canDelete={canDeletePost} pinPost={pinPost} deletePost={deletePost} isAuthor={post.authorId === user?.uid} />
                            ))
                        )}
                    </div>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">

                    {/* Events Panel */}
                    <div className="bg-white dark:bg-stone-800 rounded-2xl overflow-hidden shadow-sm border border-stone-100 dark:border-stone-700">
                        <div className="p-5">
                            <div className="flex items-center justify-between mb-3">
                                <h4 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                                    <CalendarDays className="w-4 h-4 text-stone-400" /> Events
                                </h4>
                                {canManageEvents && (
                                    <button
                                        onClick={() => setShowCreateEvent(v => !v)}
                                        className="flex items-center gap-1 text-xs font-medium text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded"
                                    >
                                        <Plus className="w-3.5 h-3.5" />
                                        {showCreateEvent ? 'Cancel' : 'New Event'}
                                    </button>
                                )}
                            </div>

                            {/* Create Event Form */}
                            <AnimatePresence>
                                {showCreateEvent && (
                                    <motion.form
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        className="overflow-hidden"
                                        onSubmit={handleCreateEvent}
                                    >
                                        <div className="space-y-2 pb-4 border-b border-stone-100 dark:border-stone-700 mb-4">
                                            <input
                                                type="text"
                                                required
                                                placeholder="Event title*"
                                                value={eventForm.title}
                                                onChange={e => setEventForm(f => ({ ...f, title: e.target.value }))}
                                                className="w-full px-3 py-2 rounded-lg border border-stone-200 dark:border-stone-600 bg-stone-50 dark:bg-stone-900/50 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                                            />
                                            <input
                                                type="datetime-local"
                                                required
                                                value={eventForm.date}
                                                onChange={e => setEventForm(f => ({ ...f, date: e.target.value }))}
                                                className="w-full px-3 py-2 rounded-lg border border-stone-200 dark:border-stone-600 bg-stone-50 dark:bg-stone-900/50 text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                                            />
                                            <input
                                                type="text"
                                                placeholder="Location (optional)"
                                                value={eventForm.location}
                                                onChange={e => setEventForm(f => ({ ...f, location: e.target.value }))}
                                                className="w-full px-3 py-2 rounded-lg border border-stone-200 dark:border-stone-600 bg-stone-50 dark:bg-stone-900/50 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                                            />
                                            <textarea
                                                placeholder="Description (optional)"
                                                value={eventForm.description}
                                                onChange={e => setEventForm(f => ({ ...f, description: e.target.value }))}
                                                rows={2}
                                                className="w-full px-3 py-2 rounded-lg border border-stone-200 dark:border-stone-600 bg-stone-50 dark:bg-stone-900/50 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                                            />
                                            <label className="flex items-center gap-2 text-sm text-stone-600 dark:text-stone-400 cursor-pointer select-none">
                                                <input
                                                    type="checkbox"
                                                    checked={eventForm.recurring}
                                                    onChange={e => setEventForm(f => ({ ...f, recurring: e.target.checked }))}
                                                    className="rounded accent-emerald-600"
                                                />
                                                <Repeat2 className="w-3.5 h-3.5" />
                                                Recurring event
                                            </label>
                                            <button
                                                type="submit"
                                                disabled={!eventForm.title.trim() || !eventForm.date || eventSubmitting}
                                                className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 dark:disabled:bg-stone-600 text-white text-sm font-medium py-2 rounded-lg transition-colors"
                                            >
                                                {eventSubmitting ? 'Creating…' : 'Create Event'}
                                            </button>
                                        </div>
                                    </motion.form>
                                )}
                            </AnimatePresence>

                            {/* Events List */}
                            {upcomingEvents.length === 0 ? (
                                <p className="text-sm text-stone-400 text-center py-3">No upcoming events.</p>
                            ) : (
                                <div className="space-y-3">
                                    {upcomingEvents.map(event => {
                                        const isAttending = user ? event.attendeeIds.includes(user.uid) : false;
                                        return (
                                            <div key={event.id} className="rounded-xl border border-stone-100 dark:border-stone-700 p-3 space-y-1.5">
                                                <div className="flex items-start justify-between gap-2">
                                                    <p className="font-medium text-sm text-stone-900 dark:text-stone-100 leading-tight">{event.title}</p>
                                                    {canManageEvents && (
                                                        <button
                                                            onClick={() => confirm('Delete this event?') && deleteEvent(group.id, event.id)}
                                                            className="shrink-0 min-h-[44px] min-w-[44px] flex items-center justify-center rounded hover:bg-rose-50 hover:text-rose-500 dark:hover:bg-rose-900/30 dark:hover:text-rose-400 text-stone-400 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                                                            aria-label="Delete event"
                                                        >
                                                            <Trash2 className="w-3.5 h-3.5" />
                                                        </button>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400">
                                                    <Calendar className="w-3 h-3 shrink-0" />
                                                    <span>{new Date(event.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                                                </div>
                                                {event.location && (
                                                    <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400">
                                                        <MapPin className="w-3 h-3 shrink-0" />
                                                        <span className="truncate">{event.location}</span>
                                                    </div>
                                                )}
                                                {event.description && (
                                                    <p className="text-xs text-stone-500 dark:text-stone-400 line-clamp-2">{event.description}</p>
                                                )}
                                                <div className="flex items-center justify-between pt-1">
                                                    <span className="flex items-center gap-1 text-xs text-stone-500 dark:text-stone-400">
                                                        <UserCheck className="w-3 h-3" /> {event.attendeeIds.length} going
                                                    </span>
                                                    {userRole && (
                                                        <button
                                                            onClick={() => rsvpEvent(group.id, event.id, !isAttending)}
                                                            className={`text-xs font-medium px-2.5 py-1 rounded-lg transition-colors ${isAttending ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 hover:bg-emerald-200 dark:hover:bg-emerald-900/60' : 'bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-600'}`}
                                                        >
                                                            {isAttending ? 'Going ✓' : 'RSVP'}
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="bg-white dark:bg-stone-800 rounded-2xl overflow-hidden shadow-sm border border-stone-100 dark:border-stone-700">
                        <div className="p-5">
                            <h4 className="font-semibold text-stone-900 dark:text-stone-100 mb-3 flex items-center gap-2">
                                <Settings2 className="w-4 h-4 text-stone-400" /> Leadership Team
                            </h4>
                            <div className="space-y-3">
                                {ownersAndMods.map(m => (
                                    <div key={m.userId} className="flex items-center justify-between text-sm">
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 rounded-full bg-stone-200 dark:bg-stone-700 flex items-center justify-center text-[10px] font-bold text-stone-600 dark:text-stone-300">
                                                {m.userId.substring(0, 2).toUpperCase()}
                                            </div>
                                            <span className="text-stone-700 dark:text-stone-300 font-medium">{m.role}</span>
                                        </div>
                                        <button className="text-emerald-600 hover:text-emerald-700 transition-colors p-1" title="Contact">
                                            <Mail className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                            </div>

                            {userRole === 'Owner' && (
                                <div className="mt-6 pt-6 border-t border-stone-100 dark:border-stone-700">
                                    <h4 className="font-semibold text-stone-900 dark:text-stone-100 mb-3 flex items-center gap-2">
                                        <Users className="w-4 h-4 text-stone-400" /> Assign Roles
                                    </h4>
                                    <div className="relative mb-3">
                                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                                        <input
                                            type="text"
                                            placeholder="Search by username..."
                                            value={roleSearchQuery}
                                            onChange={(e) => setRoleSearchQuery(e.target.value)}
                                            className="w-full pl-9 pr-4 py-3 bg-stone-50 dark:bg-stone-900/50 border border-stone-200 dark:border-stone-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 transition-shadow outline-none min-h-[44px]"
                                        />
                                    </div>
                                    {roleSearchQuery.length > 0 && (
                                        <div className="space-y-2">
                                            {roleSearchResults.filter(u => group.members[u.uid]).map(foundUser => (
                                                <div key={foundUser.uid} className="flex items-center justify-between text-sm py-2 px-3 bg-stone-50 dark:bg-stone-800 rounded-lg">
                                                    <div className="flex items-center gap-2">
                                                        <img src={foundUser.avatarUrl} alt={foundUser.displayName} className="w-6 h-6 rounded-full" />
                                                        <span className="font-medium text-stone-700 dark:text-stone-300 truncate w-24">
                                                            {foundUser.displayName}
                                                        </span>
                                                    </div>
                                                    <select
                                                        value={group.members[foundUser.uid]?.role || 'User'}
                                                        onChange={(e) => updateMemberRole(group.id, foundUser.uid, e.target.value as CommunityRole)}
                                                        className="py-1 px-2 border border-stone-200 dark:border-stone-700 rounded-lg bg-white dark:bg-stone-900 text-xs font-semibold focus:ring-emerald-500 cursor-pointer text-stone-700 dark:text-stone-300"
                                                    >
                                                        <option value="User">User</option>
                                                        <option value="Event Coordinator">Coordinator</option>
                                                        <option value="Moderator">Moderator</option>
                                                        <option value="Owner">Owner</option>
                                                    </select>
                                                </div>
                                            ))}
                                            {roleSearchResults.filter(u => group.members[u.uid]).length === 0 && (
                                                <p className="text-xs text-stone-500 text-center py-2">No matching group members found.</p>
                                            )}
                                        </div>
                                    )}
                                </div>
                            )}

                            {userRole && (
                                <div className="mt-6 pt-6 border-t border-stone-100 dark:border-stone-700">
                                    <button
                                        onClick={async () => {
                                            try {
                                                if (!confirm('Are you sure you want to leave this group?')) return;
                                                await leaveGroup(group.id);
                                                navigate('/community');
                                            } catch (err: any) {
                                                if (err?.message === 'LAST_OWNER') {
                                                    const memberCount = Object.keys(group.members).length;
                                                    if (memberCount > 1) {
                                                        alert('You are the last owner. Promote another member to Owner using the "Assign Roles" panel before leaving, or choose "Disband Group" below.');
                                                    } else if (confirm('You are the only member. Permanently disband and delete this group?')) {
                                                        // Single member who is also owner — this path shouldn't normally trigger,
                                                        // but handle gracefully by triggering a second leave which sees isLastMember.
                                                        await leaveGroup(group.id).catch(() => {});
                                                        navigate('/community');
                                                    }
                                                }
                                            }
                                        }}
                                        className="w-full py-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg text-sm font-medium transition-colors border border-rose-200 dark:border-rose-800"
                                    >
                                        Leave Group
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <AnimatePresence>
                {showRetentionModal && (
                    <Suspense fallback={null}>
                        <GroupRetentionModal
                            currentDays={group.retentionDays ?? 365}
                            onSave={(days) => updateGroupRetention(group.id, days)}
                            onClose={() => setShowRetentionModal(false)}
                        />
                    </Suspense>
                )}
            </AnimatePresence>
        </motion.div>
    );
}

function PostCard({ post, groupId, canPin, canDelete, pinPost, deletePost, isAuthor }: { key?: React.Key, post: GroupPost, groupId: string, canPin: boolean, canDelete: boolean, pinPost: any, deletePost: any, isAuthor: boolean }) {
    return (
        <div className={`bg-white dark:bg-stone-800 rounded-2xl p-5 shadow-sm border ${post.isPinned ? 'border-amber-200 dark:border-amber-900/50 outline outline-2 outline-amber-100 dark:outline-amber-900/30' : 'border-stone-100 dark:border-stone-700'}`}>
            <div className="flex items-start justify-between">
                <div className="flex items-center gap-3 mb-3">
                    <img src={post.authorImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.authorId}`} alt={post.authorName} className="w-10 h-10 rounded-full bg-stone-100" />
                    <div>
                        <h4 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                            {post.authorName} {isAuthor && <span className="text-[10px] bg-stone-100 dark:bg-stone-700 px-1.5 py-0.5 rounded text-stone-500 font-normal">You</span>}
                        </h4>
                        <p className="text-xs text-stone-500 dark:text-stone-400">{new Date(post.createdAt).toLocaleString()}</p>
                    </div>
                </div>

                <div className="flex items-center gap-1">
                    {canPin && (
                        <button
                            onClick={() => pinPost(groupId, post.id, !post.isPinned)}
                            className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${post.isPinned ? 'text-amber-500' : 'text-stone-400 hover:text-stone-600 dark:hover:text-stone-200'}`}
                            aria-label={post.isPinned ? "Unpin Post" : "Pin Post"}
                        >
                            <Pin className={`w-4 h-4 ${post.isPinned ? 'fill-current' : ''}`} />
                        </button>
                    )}
                    {(canDelete || isAuthor) && (
                        <button
                            onClick={() => {
                                if (confirm('Delete this post?')) deletePost(groupId, post.id);
                            }}
                            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded hover:bg-rose-50 hover:text-rose-500 dark:hover:bg-rose-900/30 dark:hover:text-rose-400 text-stone-400 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                            aria-label="Delete Post"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                    )}
                </div>
            </div>
            <p className="text-stone-700 dark:text-stone-300 whitespace-pre-wrap">{post.content}</p>
        </div>
    );
}

﻿// Central Pet type definition — imported by both PetContext and firestoreService
// to avoid circular dependencies.
//
// Per petbase-system-instructions.md: the `notes` field is PII and MUST be
// AES-256-GCM encrypted by src/lib/crypto.ts before any Firestore write.
export interface EmergencyContacts {
  ownerPhone?: string;
  vetInfo?: { clinic: string; name: string; address: string; phone: string };
  additionalContacts?: Array<{ name: string; phone: string }>; // Max 3
}

export interface Pet {
  id: string;
  name: string;
  type?: string; // Pet species/type (Dog, Cat, Rabbit, etc.)
  breed: string;
  age: string;
  weight: string;
  notes: string; // PII — encrypted client-side before Firestore writes
  image: string;
  // Extended profile fields
  activity?: string;
  food?: string;
  lastVet?: string;
  likes?: string[];
  dislikes?: string[];
  // New fields
  height?: string;
  length?: string;
  bodyConditionScore?: string;
  favoriteActivities?: string[];
  typeOfPlay?: string;
  dietSchedule?: {
    time: string;
    portion: string;
    brand: string;
  }[];
  medicalVisits?: {
    date: string;
    clinic: string;
    reason: string;
    notes: string;
  }[];
  lostStatus?: {
    isLost: boolean;
    reportedAt: number;
  };
  avatarShape?: 'circle' | 'square' | 'squircle' | 'hexagon';
  pageLayout?: 'full-background' | 'solid-color';
  backgroundColor?: string;
  isPrivate?: boolean;
  gallery?: string[]; // Up to 10 photos
  spayedNeutered?: 'Yes' | 'No' | 'Unknown';
  microchipId?: string; // PII — encrypted client-side before Firestore writes
  // Phase 10 fields
  birthday?: string;           // ISO date YYYY-MM-DD; replaces free-text age
  weightUnit?: 'lbs' | 'kg';
  heightUnit?: 'inches' | 'cm';
  lengthUnit?: 'inches' | 'cm';
  foodBrand?: string;
  foodAmount?: string;
  foodUnit?: 'cups' | 'half cups' | 'oz' | 'grams' | 'lbs';
  emergencyContacts?: EmergencyContacts;
}

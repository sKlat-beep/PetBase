import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { Activity, Calendar, MapPin, Plus, ShieldAlert, Syringe, DollarSign, TriangleAlert, X, Eye, EyeOff, ExternalLink, Users, GripVertical, ChevronLeft, ChevronRight, LayoutDashboard, MessageSquare, Settings2 } from 'lucide-react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { Link, useNavigate } from 'react-router';
import GridLayout, { type Layout } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { useAuth } from '../contexts/AuthContext';
import { usePets } from '../contexts/PetContext';
import { useCommunity } from '../contexts/CommunityContext';
import { useExpenses } from '../contexts/ExpenseContext';
import type { Pet } from '../contexts/PetContext';
import { searchServices, type ServiceResult } from '../utils/serviceApi';
import { getActiveLostPets, type LostPetAlert } from '../utils/lostPetsApi';
import { LostPetBanner } from '../components/LostPetBanner';
import { GettingStartedGuide } from '../components/GettingStartedGuide';
import { RecommendationBanner } from '../components/RecommendationBanner';

const PetFormModal = React.lazy(() =>
  import('../components/PetFormModal').then(m => ({ default: m.PetFormModal }))
);
const CalendarModal = React.lazy(() =>
  import('../components/CalendarModal').then(m => ({ default: m.CalendarModal }))
);
import { useSafetyAlerts, CATEGORY_LABELS, CATEGORY_COLORS } from '../contexts/SafetyAlertsContext';
import { useSocial } from '../contexts/SocialContext';
import { getVaccineStatus } from '../components/MedicalRecordsModal';

// ─── Constants ────────────────────────────────────────────────────────────────

const GUIDE_COMPLETE_KEY = 'petbase-guide-completed';
const LAYOUT_KEY = 'petbase-dashboard-layout-v2';
const HIDDEN_KEY = 'petbase-dashboard-hidden-v2';

type WidgetKey =
  | 'pet_health'
  | 'pet_of_day'
  | 'weather'
  | 'your_pets'
  | 'quick_actions'
  | 'upcoming'
  | 'expenses'
  | 'groups'
  | 'friends'
  | 'services'
  | 'safety_alerts'
  | 'lost_pet';

const WIDGET_LABELS: Record<WidgetKey, string> = {
  pet_health: 'Pet Health Summary',
  pet_of_day: 'Pet of the Day',
  weather: 'Weather',
  your_pets: 'Your Pets',
  quick_actions: 'Quick Actions',
  upcoming: 'Upcoming Events',
  expenses: 'Expenses',
  groups: 'My Groups',
  friends: 'Friends',
  services: 'Local Services',
  safety_alerts: 'Safety Alerts',
  lost_pet: 'Lost Pet Alert',
};

const WIDGET_MIN_SIZES: Record<WidgetKey, { minW: number; minH: number }> = {
  pet_health: { minW: 3, minH: 3 },
  pet_of_day: { minW: 2, minH: 3 },
  weather: { minW: 2, minH: 2 },
  your_pets: { minW: 3, minH: 3 },
  quick_actions: { minW: 2, minH: 2 },
  upcoming: { minW: 2, minH: 3 },
  expenses: { minW: 2, minH: 3 },
  groups: { minW: 2, minH: 3 },
  friends: { minW: 2, minH: 2 },
  services: { minW: 3, minH: 3 },
  safety_alerts: { minW: 4, minH: 2 },
  lost_pet: { minW: 4, minH: 1 },
};

const DEFAULT_LAYOUT: Layout[] = [
  { i: 'safety_alerts', x: 0,  y: 0,  w: 12, h: 2 },
  { i: 'lost_pet',      x: 0,  y: 2,  w: 12, h: 2 },
  { i: 'pet_health',   x: 0,  y: 4,  w: 5,  h: 4 },
  { i: 'pet_of_day',   x: 5,  y: 4,  w: 3,  h: 4 },
  { i: 'weather',      x: 8,  y: 4,  w: 4,  h: 4 },
  { i: 'your_pets',    x: 0,  y: 8,  w: 6,  h: 4 },
  { i: 'quick_actions',x: 6,  y: 8,  w: 3,  h: 4 },
  { i: 'upcoming',     x: 9,  y: 8,  w: 3,  h: 4 },
  { i: 'services',     x: 0,  y: 12, w: 8,  h: 4 },
  { i: 'expenses',     x: 8,  y: 12, w: 4,  h: 4 },
  { i: 'groups',       x: 0,  y: 16, w: 4,  h: 4 },
  { i: 'friends',      x: 4,  y: 16, w: 4,  h: 3 },
];

function addMinSizes(l: Layout): Layout {
  const key = l.i as WidgetKey;
  const min = WIDGET_MIN_SIZES[key] ?? { minW: 2, minH: 2 };
  return { ...l, minW: min.minW, minH: min.minH };
}

function loadLayout(): Layout[] {
  try {
    const raw = localStorage.getItem(LAYOUT_KEY);
    if (!raw) return DEFAULT_LAYOUT.map(l => addMinSizes(l));
    const saved: Layout[] = JSON.parse(raw);
    const savedKeys = new Set(saved.map(l => l.i));
    const missing = DEFAULT_LAYOUT.filter(l => !savedKeys.has(l.i));
    return [...saved, ...missing].map(l => addMinSizes(l));
  } catch {
    return DEFAULT_LAYOUT.map(l => addMinSizes(l));
  }
}

function loadHidden(): Set<WidgetKey> {
  try {
    const raw = localStorage.getItem(HIDDEN_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

// ─── EmergencyModal ───────────────────────────────────────────────────────────

function EmergencyModal({ onClose, onFindVet }: { onClose: () => void; onFindVet: () => void }) {
  const prefersReduced = useReducedMotion();
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    dialogRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') { onClose(); return; }
    if (e.key !== 'Tab') return;
    const focusable = dialogRef.current?.querySelectorAll<HTMLElement>(
      'button, a, [tabindex]:not([tabindex="-1"])'
    );
    if (!focusable || focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey) { if (document.activeElement === first) { e.preventDefault(); last.focus(); } }
    else { if (document.activeElement === last) { e.preventDefault(); first.focus(); } }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="emergency-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onKeyDown={handleKeyDown}
      ref={dialogRef}
      tabIndex={-1}
    >
      <motion.div
        initial={prefersReduced ? false : { opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={prefersReduced ? undefined : { opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15, ease: 'easeOut' }}
        className="bg-white/75 dark:bg-neutral-900/75 backdrop-blur-xl rounded-t-2xl sm:rounded-2xl shadow-xl shadow-black/10 dark:shadow-black/30 border border-white/20 dark:border-white/10 w-full max-w-sm overflow-hidden"
      >
        <div className="bg-rose-600 p-5">
          <div className="flex items-center justify-between">
            <h2 id="emergency-modal-title" className="text-xl font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5" aria-hidden="true" /> Emergency Assistance
            </h2>
            <button
              onClick={onClose}
              aria-label="Close emergency assistance"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center text-white/70 hover:text-white rounded-lg motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-rose-100 text-sm mt-1">Tap a service below to get immediate help.</p>
        </div>
        <div className="p-4 space-y-3">
          <button
            onClick={() => { onFindVet(); onClose(); }}
            className="w-full flex items-center gap-4 bg-rose-50/80 hover:bg-rose-100/80 dark:bg-rose-950/30 dark:hover:bg-rose-900/40 backdrop-blur-sm border border-rose-200/60 dark:border-rose-900/50 p-4 rounded-2xl motion-safe:transition-colors text-left"
          >
            <div className="w-10 h-10 bg-rose-100 dark:bg-rose-900/50 rounded-xl flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            </div>
            <div>
              <p className="font-bold text-rose-900 dark:text-rose-100 text-sm">Nearest 24/7 ER Vet</p>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">Find emergency veterinary care near you</p>
            </div>
          </button>
          <a
            href="https://www.aspca.org/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-orange-50 dark:bg-orange-950/30 hover:bg-orange-100 dark:hover:bg-orange-900/40 border border-orange-200 dark:border-orange-900/50 p-4 rounded-xl motion-safe:transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <p className="font-bold text-orange-900 dark:text-orange-100 text-sm">ASPCA Poison Control</p>
              <p className="text-xs text-orange-700 dark:text-orange-300 mt-0.5">aspca.org · Available 24/7</p>
            </div>
          </a>
          <a
            href="https://www.petpoisonhelpline.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-4 bg-amber-50 dark:bg-amber-950/30 hover:bg-amber-100 dark:hover:bg-amber-900/40 border border-amber-200 dark:border-amber-900/50 p-4 rounded-xl motion-safe:transition-colors text-left block"
          >
            <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/50 rounded-xl flex items-center justify-center shrink-0">
              <ExternalLink className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="font-bold text-amber-900 dark:text-amber-100 text-sm">Pet Poison Helpline</p>
              <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">petpoisonhelpline.com · Available 24/7</p>
            </div>
          </a>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

export function Dashboard() {
  const { user, profile } = useAuth();
  const { pets, addPet } = usePets();
  const navigate = useNavigate();

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);

  // Guide
  const [guideCompleted, setGuideCompleted] = useState(
    () => localStorage.getItem(GUIDE_COMPLETE_KEY) === 'true'
  );
  const handleGuideComplete = useCallback(() => setGuideCompleted(true), []);

  // Grid layout
  const [containerWidth, setContainerWidth] = useState(1200);
  const containerRef = useRef<HTMLDivElement>(null);
  const [layout, setLayout] = useState<Layout[]>(loadLayout);
  const [hiddenWidgets, setHiddenWidgets] = useState<Set<WidgetKey>>(loadHidden);
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      setContainerWidth(entries[0].contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const visibleLayout = layout.filter(l => !hiddenWidgets.has(l.i as WidgetKey));

  const handleLayoutChange = useCallback((newLayout: Layout[]) => {
    setLayout(prev => {
      const merged = prev.map(item => {
        const updated = newLayout.find(n => n.i === item.i);
        return updated ? { ...item, ...updated } : item;
      });
      localStorage.setItem(LAYOUT_KEY, JSON.stringify(merged));
      return merged;
    });
  }, []);

  const hideWidget = useCallback((key: WidgetKey) => {
    setHiddenWidgets(prev => {
      const next = new Set(prev);
      next.add(key);
      localStorage.setItem(HIDDEN_KEY, JSON.stringify([...next]));
      return next;
    });
  }, []);

  const showWidget = useCallback((key: WidgetKey) => {
    setHiddenWidgets(prev => {
      const next = new Set(prev);
      next.delete(key);
      localStorage.setItem(HIDDEN_KEY, JSON.stringify([...next]));
      return next;
    });
  }, []);

  const resetLayout = useCallback(() => {
    setLayout(DEFAULT_LAYOUT.map(l => addMinSizes(l)));
    setHiddenWidgets(new Set());
    localStorage.removeItem(LAYOUT_KEY);
    localStorage.removeItem(HIDDEN_KEY);
  }, []);

  // Expenses
  const { expenses, addExpense, stopRecurring, totalExpenses } = useExpenses();
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [newExpenseLabel, setNewExpenseLabel] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState('');
  const [newExpenseRecurring, setNewExpenseRecurring] = useState(false);
  const [newExpenseFrequency, setNewExpenseFrequency] = useState<'Weekly' | 'Bi-weekly' | 'Monthly' | 'Yearly'>('Monthly');
  const [confirmStopId, setConfirmStopId] = useState<string | null>(null);
  const [expenseToast, setExpenseToast] = useState<string | null>(null);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseLabel || !newExpenseAmount) return;
    addExpense({
      label: newExpenseLabel,
      amount: parseFloat(newExpenseAmount),
      date: new Date().toISOString(),
      recurring: newExpenseRecurring || undefined,
      frequency: newExpenseRecurring ? newExpenseFrequency : undefined,
    });
    setNewExpenseLabel('');
    setNewExpenseAmount('');
    setNewExpenseRecurring(false);
    setShowExpenseForm(false);
    setExpenseToast('Expense added');
    setTimeout(() => setExpenseToast(null), 2500);
  };

  // Community / Social
  const { groups } = useCommunity();
  const { directory } = useSocial();
  const { alerts: safetyAlerts } = useSafetyAlerts();

  const myGroups = useMemo(() =>
    groups
      .filter(g => user?.uid && g.members[user.uid])
      .sort((a, b) => {
        const lastA = a.posts[0]?.createdAt ?? a.createdAt ?? '';
        const lastB = b.posts[0]?.createdAt ?? b.createdAt ?? '';
        return String(lastB).localeCompare(String(lastA));
      })
      .slice(0, 3),
    [groups, user?.uid]
  );

  const myFriends = useMemo(() => {
    const friendUids: string[] = (profile as any)?.friends ?? [];
    return friendUids
      .map(uid => directory.find(p => p.uid === uid))
      .filter(Boolean)
      .slice(0, 3) as typeof directory;
  }, [profile, directory]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }, []);

  const upcomingEvents = useMemo(() => {
    if (!user) return [];
    return groups
      .flatMap(g => g.events.map(e => ({ ...e, groupName: g.name })))
      .filter(e => e.attendeeIds.includes(user.uid))
      .map(e => ({
        id: e.id,
        title: e.title,
        pet: e.groupName,
        date: new Date(e.date).toLocaleDateString(),
        icon: Calendar,
        color: 'text-indigo-500',
        bg: 'bg-indigo-50 dark:bg-indigo-950',
      }))
      .slice(0, 5);
  }, [user, groups]);

  // Services
  const SERVICE_CATS = ['Vets', 'Groomers', 'Sitters', 'Walkers', 'Trainers'] as const;
  const [serviceCatIdx, setServiceCatIdx] = useState(0);
  const [topService, setTopService] = useState<ServiceResult | null>(null);
  const [lostPet, setLostPet] = useState<LostPetAlert | null>(null);

  const petTypesKey = useMemo(
    () => [...new Set(pets.map(p => p.type ?? 'Dog'))].sort().join(','),
    [pets]
  );

  useEffect(() => {
    if (!profile?.zipCode) return;
    const petTypesQuery = petTypesKey ? petTypesKey.split(',') : ['Dog'];
    searchServices({ query: '', location: profile.zipCode, type: 'Vets', petTypesQuery })
      .then(res => { if (res.length > 0) setTopService(res[0]); });
    getActiveLostPets(profile.zipCode)
      .then(res => { if (res.length > 0) setLostPet(res[0]); });
  }, [profile?.zipCode, petTypesKey]);

  // Weather
  const [weather, setWeather] = useState<{ temp: string; condition: string; icon: string; location: string } | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);

  useEffect(() => {
    if (!profile?.zipCode) return;
    setWeatherLoading(true);
    fetch(`https://wttr.in/${encodeURIComponent(profile.zipCode)}?format=%l|%C|%t|%f`)
      .then(r => r.text())
      .then(text => {
        const [location, condition, temp] = text.split('|').map(s => s.trim());
        const iconMap: Record<string, string> = {
          'Sunny': '☀️', 'Clear': '🌙', 'Partly cloudy': '⛅', 'Cloudy': '☁️',
          'Overcast': '☁️', 'Mist': '🌫️', 'Rain': '🌧️', 'Light rain': '🌦️',
          'Heavy rain': '🌧️', 'Snow': '❄️', 'Blizzard': '🌨️', 'Thunder': '⛈️',
          'Fog': '🌫️', 'Drizzle': '🌦️', 'Sleet': '🌨️',
        };
        const icon = Object.entries(iconMap).find(([k]) => condition?.includes(k))?.[1] ?? '🌤️';
        setWeather({ temp, condition, icon, location: location || profile.zipCode });
      })
      .catch(() => {})
      .finally(() => setWeatherLoading(false));
  }, [profile?.zipCode]);

  const prefersReduced = useReducedMotion();

  const GLASS_CARD = 'h-full bg-white/75 dark:bg-zinc-800/75 backdrop-blur-xl rounded-2xl border border-stone-200/60 dark:border-zinc-700/60 shadow-sm shadow-black/5 dark:shadow-black/20 overflow-hidden';

  // ─── Widget Renderer ──────────────────────────────────────────────────────

  function renderWidget(key: WidgetKey): React.ReactNode {
    switch (key) {

      case 'pet_health': {
        return (
          <section className={`${GLASS_CARD} p-5`} aria-label="Pet Health Summary">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-2">
                <Syringe className="w-5 h-5 text-emerald-500" aria-hidden="true" /> Pet Health
              </h2>
              <Link to="/pets" className="text-xs text-emerald-600 dark:text-emerald-400 font-medium hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">View all</Link>
            </div>
            {pets.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <p className="text-sm text-stone-400 dark:text-zinc-500 mb-3">No pets added yet.</p>
                <button onClick={() => setIsModalOpen(true)} className="text-sm text-emerald-600 dark:text-emerald-400 font-medium hover:underline min-h-[44px] px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Add your first pet</button>
              </div>
            ) : (
              <div className="space-y-3">
                {pets.slice(0, 4).map(pet => {
                  const vaccines = (pet as any).vaccines as { name: string; nextDueDate: string }[] | undefined;
                  const overdue = vaccines?.filter(v => getVaccineStatus(v.nextDueDate) === 'overdue').length ?? 0;
                  const dueSoon = vaccines?.filter(v => getVaccineStatus(v.nextDueDate) === 'due-soon').length ?? 0;
                  const allGood = overdue === 0 && dueSoon === 0;
                  return (
                    <Link key={pet.id} to="/pets" state={{ editPetId: pet.id }} className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50/80 dark:hover:bg-zinc-700/50 motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                      {/* pet.image is resolved via PetContext token pipeline */}
                      <img src={pet.image} alt={pet.name} width={40} height={40} className="w-10 h-10 rounded-xl object-cover shrink-0" referrerPolicy="no-referrer" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-stone-900 dark:text-zinc-100 truncate">{pet.name}</p>
                        <p className="text-xs text-stone-400 dark:text-zinc-500 truncate">{pet.breed}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {overdue > 0 && <span className="text-xs bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 px-2 py-0.5 rounded-full font-medium">{overdue} overdue</span>}
                        {dueSoon > 0 && <span className="text-xs bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400 px-2 py-0.5 rounded-full font-medium">{dueSoon} due soon</span>}
                        {allGood && <span className="text-xs bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full font-medium">Up to date</span>}
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </section>
        );
      }

      case 'pet_of_day': {
        const dayIndex = pets.length > 0
          ? Math.floor(Date.now() / 86400000) % pets.length
          : -1;
        const featuredPet = dayIndex >= 0 ? pets[dayIndex] : null;
        return (
          <section className={`${GLASS_CARD} p-5 flex flex-col`} aria-label="Pet of the Day">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-2">
                <span aria-hidden="true">🌟</span> Pet of the Day
              </h2>
            </div>
            {!featuredPet ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center py-4">
                <p className="text-sm text-stone-400 dark:text-zinc-500 mb-3">Add pets to see your daily feature.</p>
                <button onClick={() => setIsModalOpen(true)} className="text-sm text-emerald-600 dark:text-emerald-400 font-medium hover:underline min-h-[44px] px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Add a pet</button>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center gap-3">
                <img src={featuredPet.image} alt={featuredPet.name} width={96} height={96} className="w-24 h-24 rounded-2xl object-cover shadow-md shadow-black/10" referrerPolicy="no-referrer" />
                <div className="text-center">
                  <p className="text-xl font-bold text-stone-900 dark:text-zinc-100">{featuredPet.name}</p>
                  <p className="text-sm text-stone-500 dark:text-zinc-400">{featuredPet.breed}</p>
                </div>
                <div className="flex flex-wrap justify-center gap-2 mt-1">
                  {featuredPet.age && <span className="text-xs bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 px-3 py-1 rounded-full font-medium">{featuredPet.age}</span>}
                  {featuredPet.weight && <span className="text-xs bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-400 px-3 py-1 rounded-full font-medium">{featuredPet.weight}</span>}
                  {(featuredPet as any).color && <span className="text-xs bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-400 px-3 py-1 rounded-full font-medium">{(featuredPet as any).color}</span>}
                </div>
                <Link to="/pets" state={{ editPetId: featuredPet.id }} className="mt-auto text-xs text-emerald-600 dark:text-emerald-400 font-medium hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">View full profile →</Link>
              </div>
            )}
          </section>
        );
      }

      case 'weather': {
        return (
          <section className={`${GLASS_CARD} p-5 flex flex-col`} aria-label="Weather">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-500" aria-hidden="true" /> Weather
              </h2>
              {weather && <p className="text-xs text-stone-400 dark:text-zinc-500 truncate max-w-[120px]">{weather.location}</p>}
            </div>
            {!profile?.zipCode ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <p className="text-sm text-stone-400 dark:text-zinc-500 mb-2">Set your location in Settings to see local weather.</p>
                <Link to="/settings" className="text-sm text-emerald-600 dark:text-emerald-400 font-medium hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Go to Settings</Link>
              </div>
            ) : weatherLoading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="w-6 h-6 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin" />
              </div>
            ) : weather ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-2">
                <span className="text-5xl" role="img" aria-label={weather.condition}>{weather.icon}</span>
                <p className="text-3xl font-bold text-stone-900 dark:text-zinc-100">{weather.temp}</p>
                <p className="text-sm text-stone-500 dark:text-zinc-400">{weather.condition}</p>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <p className="text-sm text-stone-400 dark:text-zinc-500">Weather unavailable</p>
              </div>
            )}
          </section>
        );
      }

      case 'your_pets': {
        const previewPets = pets.slice(0, 2);
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="Your Pets">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-stone-900 dark:text-zinc-100">Your Pets</h2>
              <Link to="/pets" className="text-emerald-600 dark:text-emerald-400 font-medium text-sm hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">View All</Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {previewPets.map((pet: Pet) => (
                <div key={pet.id} className="bg-white/60 dark:bg-zinc-700/60 rounded-xl p-4 border border-stone-200/50 dark:border-zinc-600/50 flex flex-col gap-4">
                  <Link to="/pets" state={{ editPetId: pet.id }} className="flex items-center gap-4 group cursor-pointer">
                    <img src={pet.image} alt={pet.name} width={64} height={64} className="w-16 h-16 rounded-xl object-cover" referrerPolicy="no-referrer" />
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-stone-900 dark:text-zinc-100 group-hover:text-emerald-600 motion-safe:transition-colors">{pet.name}</h3>
                      <p className="text-sm text-stone-500 dark:text-zinc-400">{pet.breed}</p>
                      <div className="flex items-center gap-2 mt-1.5 text-xs font-medium text-stone-600 dark:text-zinc-400">
                        {pet.age && <span className="bg-stone-100 dark:bg-zinc-700 px-2 py-0.5 rounded select-none">{pet.age}</span>}
                        {pet.weight && <span className="bg-stone-100 dark:bg-zinc-700 px-2 py-0.5 rounded select-none">{pet.weight}</span>}
                      </div>
                    </div>
                  </Link>
                  <div className="grid grid-cols-3 gap-2 pt-3 border-t border-stone-100 dark:border-zinc-700">
                    <Link to="/pets" state={{ editPetId: pet.id }} aria-label={`Edit ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-stone-50 dark:bg-zinc-700/50 hover:bg-stone-100 dark:hover:bg-zinc-700 text-stone-600 dark:text-zinc-300 motion-safe:transition-colors min-h-[44px]">
                      <Settings2 className="w-4 h-4 mb-1" aria-hidden="true" />
                      <span className="text-xs font-semibold uppercase tracking-wide">Edit</span>
                    </Link>
                    <Link to="/pets" state={{ openMedical: true, tab: 'meds', petId: pet.id }} aria-label={`Medications for ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 motion-safe:transition-colors min-h-[44px]">
                      <Syringe className="w-4 h-4 mb-1" aria-hidden="true" />
                      <span className="text-xs font-semibold uppercase tracking-wide">Meds</span>
                    </Link>
                    <Link to="/cards" state={{ openCreateModal: true, petId: pet.id }} aria-label={`Pet card for ${pet.name}`} className="flex flex-col items-center justify-center p-2 rounded-xl bg-rose-50 dark:bg-rose-900/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 motion-safe:transition-colors min-h-[44px]">
                      <ShieldAlert className="w-4 h-4 mb-1" aria-hidden="true" />
                      <span className="text-xs font-semibold uppercase tracking-wide">Card</span>
                    </Link>
                  </div>
                </div>
              ))}
              <button onClick={() => setIsModalOpen(true)} className="bg-stone-50/80 dark:bg-zinc-700/50 border-2 border-dashed border-stone-200 dark:border-zinc-600 rounded-2xl p-4 flex flex-col items-center justify-center text-stone-500 dark:text-zinc-400 hover:text-emerald-600 hover:border-emerald-200 dark:hover:border-emerald-800 hover:bg-emerald-50/80 dark:hover:bg-emerald-950/30 motion-safe:transition-colors min-h-[112px]">
                <Plus className="w-6 h-6 mb-2" />
                <span className="font-medium text-sm">Add Pet</span>
              </button>
            </div>
          </section>
        );
      }

      case 'quick_actions': {
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="Quick Actions">
            <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => setIsModalOpen(true)} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-100 dark:border-emerald-900/50 text-emerald-700 dark:text-emerald-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                <Plus className="w-5 h-5" aria-hidden="true" />
                <span className="text-xs font-semibold">Add Pet</span>
              </button>
              <button onClick={() => navigate('/messages')} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-sky-50 dark:bg-sky-950/30 hover:bg-sky-100 dark:hover:bg-sky-900/40 border border-sky-100 dark:border-sky-900/50 text-sky-700 dark:text-sky-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                <MessageSquare className="w-5 h-5" aria-hidden="true" />
                <span className="text-xs font-semibold">Messages</span>
              </button>
              <button onClick={() => navigate('/search')} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-violet-50 dark:bg-violet-950/30 hover:bg-violet-100 dark:hover:bg-violet-900/40 border border-violet-100 dark:border-violet-900/50 text-violet-700 dark:text-violet-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                <MapPin className="w-5 h-5" aria-hidden="true" />
                <span className="text-xs font-semibold">Find Services</span>
              </button>
              <button onClick={() => setIsEmergencyOpen(true)} className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/40 border border-rose-100 dark:border-rose-900/50 text-rose-700 dark:text-rose-400 motion-safe:transition-colors min-h-[80px] min-w-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">
                <ShieldAlert className="w-5 h-5" aria-hidden="true" />
                <span className="text-xs font-semibold">Emergency</span>
              </button>
            </div>
          </section>
        );
      }

      case 'upcoming': {
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="Upcoming Events">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100">Upcoming</h2>
              <Calendar className="w-5 h-5 text-stone-400 dark:text-zinc-500" />
            </div>
            <div className="space-y-4">
              {upcomingEvents.length > 0 ? upcomingEvents.map((event) => (
                <div key={event.id} className="flex gap-4 items-start">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${event.bg} ${event.color}`}>
                    <event.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-medium text-stone-900 dark:text-zinc-100">{event.title}</h4>
                    <p className="text-sm text-stone-500 dark:text-zinc-400">{event.pet} • {event.date}</p>
                  </div>
                </div>
              )) : (
                <p className="text-sm text-stone-400 dark:text-zinc-500 text-center py-4">
                  No upcoming events. Join a community group to see RSVPs here.
                </p>
              )}
            </div>
            <button
              onClick={() => setIsCalendarOpen(true)}
              className="w-full mt-6 py-2 text-sm font-medium text-stone-600 dark:text-zinc-400 bg-stone-50/80 dark:bg-zinc-700/50 hover:bg-stone-100 dark:hover:bg-zinc-700 rounded-lg motion-safe:transition-colors min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              View Calendar
            </button>
          </section>
        );
      }

      case 'expenses': {
        return (
          <section className="h-full bg-emerald-50/80 dark:bg-emerald-950/30 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-white/10 shadow-sm shadow-black/5 dark:shadow-black/20 overflow-hidden p-6" aria-label="Expenses">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" /> Expenses
              </h2>
              <span className="text-xl font-bold text-emerald-700 dark:text-emerald-300">${totalExpenses.toFixed(2)}</span>
            </div>
            {showExpenseForm ? (
              <form onSubmit={handleAddExpense} className="space-y-3 mb-4">
                <div>
                  <label htmlFor="expense-label" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Description</label>
                  <input
                    id="expense-label"
                    type="text"
                    required
                    placeholder="E.g., Vet bill, food"
                    value={newExpenseLabel}
                    onChange={(e) => setNewExpenseLabel(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-zinc-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label htmlFor="expense-amount" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Amount ($)</label>
                  <input
                    id="expense-amount"
                    type="number"
                    required
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={newExpenseAmount}
                    onChange={(e) => setNewExpenseAmount(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-zinc-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    role="switch"
                    aria-label="Recurring expense"
                    aria-checked={newExpenseRecurring}
                    onClick={() => setNewExpenseRecurring(v => !v)}
                    className={`relative w-9 h-5 rounded-full motion-safe:transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${newExpenseRecurring ? 'bg-emerald-500' : 'bg-stone-300 dark:bg-zinc-600'}`}
                  >
                    <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow motion-safe:transition-transform ${newExpenseRecurring ? 'translate-x-4' : 'translate-x-0'}`} />
                  </button>
                  <span className="text-sm text-emerald-800 dark:text-emerald-200 select-none">Recurring</span>
                </div>
                {newExpenseRecurring && (
                  <div>
                    <label htmlFor="expense-frequency" className="block text-xs font-medium text-emerald-800 dark:text-emerald-200 mb-1">Frequency</label>
                    <select
                      id="expense-frequency"
                      value={newExpenseFrequency}
                      onChange={(e) => setNewExpenseFrequency(e.target.value as typeof newExpenseFrequency)}
                      className="w-full px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-white dark:bg-zinc-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option>Weekly</option>
                      <option>Bi-weekly</option>
                      <option>Monthly</option>
                      <option>Yearly</option>
                    </select>
                  </div>
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => { setShowExpenseForm(false); setNewExpenseRecurring(false); }}
                    className="flex-1 py-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 rounded-lg hover:bg-emerald-200/50 dark:hover:bg-emerald-800/50 motion-safe:transition-colors min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-1.5 text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg motion-safe:transition-colors min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                  >
                    Save
                  </button>
                </div>
              </form>
            ) : (
              <button
                type="button"
                onClick={() => setShowExpenseForm(true)}
                className="w-full py-2 mb-4 text-sm font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/80 rounded-lg motion-safe:transition-colors flex items-center justify-center gap-2 min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
              >
                <Plus className="w-4 h-4" /> Add Expense
              </button>
            )}
            {(() => {
              const recurring = expenses.filter(e => e.recurring);
              if (!recurring.length) return null;
              return (
                <div className="mb-3 p-3 bg-emerald-100/60 dark:bg-emerald-900/20 rounded-xl border border-emerald-200 dark:border-emerald-800/50">
                  <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-2 uppercase tracking-wide">Recurring</p>
                  <div className="space-y-1.5">
                    {recurring.map(e => (
                      <div key={e.id} className="flex items-center justify-between text-xs">
                        <div>
                          <span className="font-medium text-stone-800 dark:text-zinc-200">{e.label}</span>
                          <span className="text-emerald-600 dark:text-emerald-400 ml-1">· {e.frequency}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-stone-700 dark:text-zinc-300">${e.amount.toFixed(2)}</span>
                          {confirmStopId === e.id ? (
                            <span className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setConfirmStopId(null)}
                                className="text-xs text-stone-500 dark:text-zinc-400 border border-stone-200 dark:border-zinc-600 px-1.5 py-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                              >Cancel</button>
                              <button
                                type="button"
                                onClick={() => { stopRecurring(e.id); setConfirmStopId(null); }}
                                aria-label={`Confirm stop recurring expense ${e.label}`}
                                className="text-xs text-white bg-rose-500 hover:bg-rose-600 px-1.5 py-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                              >Stop</button>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmStopId(e.id)}
                              aria-label={`Stop recurring expense ${e.label}`}
                              className="text-rose-400 hover:text-rose-600 dark:hover:text-rose-300 text-xs font-semibold uppercase tracking-wide border border-rose-200 dark:border-rose-800 px-1.5 py-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                            >Stop</button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}
            <div className="space-y-3">
              {expenses.filter(e => !e.recurring).slice(0, 5).map((expense) => (
                <div key={expense.id} className="flex items-center justify-between text-sm py-1 border-b border-emerald-100/50 dark:border-emerald-800/50 last:border-0">
                  <div>
                    <p className="font-medium text-stone-900 dark:text-zinc-100">{expense.label}</p>
                    <p className="text-xs text-stone-500 dark:text-zinc-400">{new Date(expense.date).toLocaleDateString()}</p>
                  </div>
                  <span className="font-medium text-stone-900 dark:text-zinc-100">${expense.amount.toFixed(2)}</span>
                </div>
              ))}
              {expenses.filter(e => !e.recurring).length > 5 && (
                <Link to="/settings" className="block text-xs text-emerald-600 dark:text-emerald-400 font-medium hover:underline pt-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">
                  View all {expenses.filter(e => !e.recurring).length} expenses
                </Link>
              )}
              {expenses.length === 0 && !showExpenseForm && (
                <p className="text-sm text-center text-emerald-600/70 dark:text-emerald-400/70 py-2">No expenses yet</p>
              )}
            </div>
            {expenseToast && (
              <div
                role="status"
                aria-live="polite"
                className="mt-3 px-3 py-2 bg-emerald-600 text-white text-xs font-medium rounded-lg text-center motion-safe:animate-pulse"
              >
                {expenseToast}
              </div>
            )}
          </section>
        );
      }

      case 'groups': {
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="My Groups">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-2">
                <Users className="w-5 h-5 text-violet-500" aria-hidden="true" /> My Groups
              </h2>
              <Link to="/community" className="text-xs text-violet-600 dark:text-violet-400 hover:underline font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">View All</Link>
            </div>
            {myGroups.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-sm text-stone-400 dark:text-zinc-500 mb-3">You haven't joined any groups yet.</p>
                <Link to="/community" className="text-sm text-violet-600 dark:text-violet-400 font-medium hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Browse groups</Link>
              </div>
            ) : (
              <div className="space-y-2">
                {myGroups.map(g => (
                  <Link key={g.id} to={`/community/groups/${g.id}`} className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50/80 dark:hover:bg-zinc-700/50 motion-safe:transition-colors">
                    <div className="w-9 h-9 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-violet-700 dark:text-violet-300">
                      {g.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-stone-800 dark:text-zinc-200 truncate">{g.name}</p>
                      <p className="text-xs text-stone-400 dark:text-zinc-500">{Object.keys(g.members).length} member{Object.keys(g.members).length !== 1 ? 's' : ''}</p>
                    </div>
                    {g.tags?.[0] && <span className="text-xs bg-violet-50 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 px-2 py-0.5 rounded-full shrink-0">{g.tags[0]}</span>}
                  </Link>
                ))}
              </div>
            )}
          </section>
        );
      }

      case 'friends': {
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="Friends">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-2">
                <Users className="w-5 h-5 text-pink-500" aria-hidden="true" /> Friends
              </h2>
              <Link to="/community" className="text-xs text-pink-600 dark:text-pink-400 hover:underline font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">View All</Link>
            </div>
            {myFriends.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-sm text-stone-400 dark:text-zinc-500 mb-3">No friends added yet.</p>
                <Link to="/community" className="text-sm text-pink-600 dark:text-pink-400 font-medium hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Find people</Link>
              </div>
            ) : (
              <div className="space-y-2">
                {myFriends.map(f => (
                  <Link key={f.uid} to="/community" className="flex items-center gap-3 p-3 rounded-xl hover:bg-stone-50/80 dark:hover:bg-zinc-700/50 motion-safe:transition-colors">
                    {f.avatarUrl ? (
                      // avatarUrl resolved server-side before stored in SocialContext
                      <img src={f.avatarUrl} alt={f.displayName} width={36} height={36} className="w-9 h-9 rounded-full object-cover shrink-0" />
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-pink-100 dark:bg-pink-900/40 flex items-center justify-center shrink-0 text-sm font-bold text-pink-700 dark:text-pink-300">
                        {f.displayName?.charAt(0).toUpperCase() ?? '?'}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-stone-800 dark:text-zinc-200 truncate">{f.displayName}</p>
                      {f.pets.length > 0 && <p className="text-xs text-stone-400 dark:text-zinc-500">{f.pets.map(p => `${p.count} ${p.type}`).join(', ')}</p>}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </section>
        );
      }

      case 'services': {
        return (
          <section className={`${GLASS_CARD} p-6`} aria-label="Local Services">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-stone-900 dark:text-zinc-100">Local Services for You</h2>
              <Link to="/search" className="text-emerald-600 dark:text-emerald-400 font-medium text-sm hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded">Find more</Link>
            </div>
            <div className="flex items-center gap-2 mb-4">
              <button
                onClick={() => setServiceCatIdx(i => (i - 1 + SERVICE_CATS.length) % SERVICE_CATS.length)}
                aria-label="Previous category"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full border border-stone-200 dark:border-zinc-700 text-stone-500 hover:text-stone-900 dark:hover:text-zinc-100 hover:bg-stone-100 dark:hover:bg-zinc-700 motion-safe:transition-colors shrink-0"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="flex gap-2 flex-1 overflow-hidden">
                {SERVICE_CATS.map((cat, i) => (
                  <Link
                    key={cat}
                    to={`/search?type=${cat}`}
                    className={`flex-none px-4 py-2 rounded-full text-sm font-medium motion-safe:transition-colors border ${i === serviceCatIdx
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white/60 dark:bg-zinc-700/60 border-stone-200 dark:border-zinc-600 text-stone-700 dark:text-zinc-300 hover:bg-stone-50 dark:hover:bg-zinc-700'
                      } ${Math.abs(i - serviceCatIdx) > 1 ? 'hidden sm:flex' : 'flex'}`}
                  >
                    {cat}
                  </Link>
                ))}
              </div>
              <button
                onClick={() => setServiceCatIdx(i => (i + 1) % SERVICE_CATS.length)}
                aria-label="Next category"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full border border-stone-200 dark:border-zinc-700 text-stone-500 hover:text-stone-900 dark:hover:text-zinc-100 hover:bg-stone-100 dark:hover:bg-zinc-700 motion-safe:transition-colors shrink-0"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            {topService ? (
              <div className="bg-white/60 dark:bg-zinc-700/60 rounded-2xl p-6 border border-stone-100/60 dark:border-zinc-600/60 relative overflow-hidden shadow-sm hover:shadow-md motion-safe:transition-shadow">
                <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                  <img src={topService.image} alt={topService.name} width={96} height={96} className="w-24 h-24 rounded-xl object-cover shadow-sm" referrerPolicy="no-referrer" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded-md uppercase tracking-wider">Top Rated Near You</span>
                    </div>
                    <h3 className="font-bold text-lg text-stone-900 dark:text-zinc-100">{topService.name}</h3>
                    <div className="flex items-center gap-4 mt-2 text-sm font-medium text-stone-600 dark:text-zinc-400">
                      <div className="flex items-center gap-1"><MapPin className="w-4 h-4 text-emerald-500" /><span>{topService.distance}</span></div>
                      <div className="flex items-center gap-1"><Activity className="w-4 h-4 text-rose-400" /><span>{topService.type}</span></div>
                    </div>
                  </div>
                  <Link to="/search" className="bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-medium text-sm motion-safe:transition-colors text-center w-full sm:w-auto shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500">View Profile</Link>
                </div>
              </div>
            ) : (
              <div className="bg-stone-50/80 dark:bg-zinc-700/50 rounded-2xl p-6 border border-dashed border-stone-200 dark:border-zinc-600 text-center text-stone-500 dark:text-zinc-400">
                <MapPin className="w-8 h-8 mx-auto mb-3 text-stone-400" />
                <p>Set your Zip Code in the Search page to see top-rated services near you.</p>
              </div>
            )}
          </section>
        );
      }

      case 'safety_alerts': {
        return (
          <section className={`${GLASS_CARD} p-5`} aria-label="Community safety alerts">
            <div className="flex items-center gap-2 mb-3">
              <TriangleAlert className="w-4 h-4 text-amber-500" aria-hidden="true" />
              <h2 className="text-sm font-bold text-stone-700 dark:text-zinc-300 uppercase tracking-wider">Local Safety Alerts</h2>
              {safetyAlerts.length > 0 && <span className="ml-auto text-xs text-stone-400">{safetyAlerts.length} near you</span>}
            </div>
            {safetyAlerts.length === 0 ? (
              <p className="text-sm text-stone-400 dark:text-zinc-500 text-center py-4">No safety alerts in your area.</p>
            ) : (
              <div className="space-y-2">
                {safetyAlerts.slice(0, 3).map(alert => (
                  <div key={alert.id} className="flex items-start gap-3 p-3 rounded-xl bg-white/40 dark:bg-zinc-700/40 border border-stone-100 dark:border-zinc-700">
                    <div className="mt-0.5 shrink-0">
                      <TriangleAlert className={`w-4 h-4 ${alert.severity === 'high' ? 'text-rose-500' : alert.severity === 'medium' ? 'text-amber-500' : 'text-sky-500'}`} aria-hidden="true" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm text-stone-900 dark:text-zinc-100">{alert.title}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[alert.category]}`}>
                          {CATEGORY_LABELS[alert.category]}
                        </span>
                      </div>
                      <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1 line-clamp-2">{alert.description}</p>
                      <p className="text-xs text-stone-400 mt-1">
                        {new Date(alert.createdAt).toLocaleDateString()} · expires {new Date(alert.expiresAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        );
      }

      case 'lost_pet': {
        return (
          <section className={`${GLASS_CARD} p-5`} aria-label="Lost Pet Alert">
            {lostPet ? (
              <LostPetBanner lostPet={lostPet} />
            ) : (
              <div className="flex items-center gap-3">
                <ShieldAlert className="w-5 h-5 text-stone-400 dark:text-zinc-500 shrink-0" aria-hidden="true" />
                <p className="text-sm text-stone-400 dark:text-zinc-500">No lost pet alerts in your area.</p>
              </div>
            )}
          </section>
        );
      }

      default:
        return null;
    }
  }

  const isMobile = containerWidth < 640;

  // ─── Render ────────────────────────────────────────────────────────────────

  return (
    <>
      <motion.div
        initial={prefersReduced ? false : { opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="space-y-6"
      >
        {/* Getting Started Guide */}
        {!guideCompleted && <GettingStartedGuide onComplete={handleGuideComplete} />}
        {guideCompleted && <RecommendationBanner />}

        {/* Header */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-stone-900 dark:text-zinc-100 tracking-tight">
              {greeting}, {user?.displayName?.split(' ')[0] || 'Pet Parent'}!
            </h1>
            <p className="text-stone-500 dark:text-zinc-400 mt-1">
              Here's what's happening with your furry friends today.
            </p>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto">
            {editMode && (
              <button
                onClick={resetLayout}
                className="px-3 py-2 rounded-xl text-sm font-medium border border-stone-200 dark:border-zinc-700 text-stone-500 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800 motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
              >
                Reset Layout
              </button>
            )}
            <button
              onClick={() => setEditMode(v => !v)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium motion-safe:transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                editMode
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
                  : 'border border-stone-200 dark:border-zinc-700 text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" aria-hidden="true" />
              {editMode ? 'Done' : 'Edit Layout'}
            </button>
          </div>
        </header>

        {/* Grid container */}
        <div ref={containerRef} className="w-full">
          {isMobile ? (
            <div className="space-y-4">
              {visibleLayout
                .sort((a, b) => a.y - b.y || a.x - b.x)
                .map(l => (
                  <div key={l.i}>{renderWidget(l.i as WidgetKey)}</div>
                ))}
            </div>
          ) : (
            <GridLayout
              layout={visibleLayout}
              cols={12}
              rowHeight={80}
              width={containerWidth}
              margin={[16, 16]}
              containerPadding={[0, 0]}
              isDraggable={editMode}
              isResizable={editMode}
              onLayoutChange={handleLayoutChange}
              resizeHandles={['se', 'sw', 'ne', 'nw']}
              draggableHandle=".widget-drag-handle"
              className="relative"
            >
              {visibleLayout.map(l => (
                <div key={l.i} className="relative group">
                  {renderWidget(l.i as WidgetKey)}
                  {editMode && (
                    <div className="absolute inset-0 z-10 rounded-2xl ring-2 ring-emerald-500/60 ring-offset-2 pointer-events-none">
                      <div className="absolute top-0 inset-x-0 flex items-center gap-2 px-3 py-2 bg-zinc-900/90 dark:bg-zinc-950/90 backdrop-blur-sm rounded-t-2xl pointer-events-auto">
                        <div className="widget-drag-handle cursor-grab active:cursor-grabbing min-h-[44px] min-w-[44px] flex items-center justify-center text-zinc-400 hover:text-zinc-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500" aria-label={`Drag ${WIDGET_LABELS[l.i as WidgetKey]}`}>
                          <GripVertical className="w-4 h-4" />
                        </div>
                        <span className="text-xs font-semibold text-zinc-300 uppercase tracking-widest flex-1 select-none">{WIDGET_LABELS[l.i as WidgetKey]}</span>
                        <button
                          onClick={() => hideWidget(l.i as WidgetKey)}
                          className="min-h-[44px] min-w-[44px] flex items-center justify-center text-zinc-400 hover:text-rose-400 motion-safe:transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                          aria-label={`Hide ${WIDGET_LABELS[l.i as WidgetKey]}`}
                        >
                          <EyeOff className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </GridLayout>
          )}

          {/* Hidden widgets tray — edit mode only */}
          {editMode && hiddenWidgets.size > 0 && (
            <div className="mt-6 p-4 bg-white/50 dark:bg-zinc-800/50 rounded-2xl border border-dashed border-stone-300 dark:border-zinc-600">
              <p className="text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-widest mb-3">Hidden Widgets</p>
              <div className="flex flex-wrap gap-2">
                {[...hiddenWidgets].map(key => (
                  <button
                    key={key}
                    onClick={() => showWidget(key)}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl border border-stone-200 dark:border-zinc-700 bg-white/70 dark:bg-zinc-800/70 text-stone-600 dark:text-zinc-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:border-emerald-300 dark:hover:border-emerald-800 hover:text-emerald-700 dark:hover:text-emerald-400 motion-safe:transition-colors text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
                  >
                    <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                    {WIDGET_LABELS[key]}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      <React.Suspense fallback={<div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" /></div>}>
        <PetFormModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={addPet}
        />
        <CalendarModal
          isOpen={isCalendarOpen}
          onClose={() => setIsCalendarOpen(false)}
          events={upcomingEvents}
        />
      </React.Suspense>
      <AnimatePresence>
        {isEmergencyOpen && (
          <EmergencyModal
            onClose={() => setIsEmergencyOpen(false)}
            onFindVet={() => navigate('/search?tab=services&filters=Emergency,24%2F7')}
          />
        )}
      </AnimatePresence>
    </>
  );
}

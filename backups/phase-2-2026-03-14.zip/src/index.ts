import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { setGlobalOptions } from 'firebase-functions/v2';
import * as admin from 'firebase-admin';
import * as nodemailer from 'nodemailer';
import * as https from 'https';

admin.initializeApp();

setGlobalOptions({ region: 'us-central1', maxInstances: 10 });

// ─── Email configuration ──────────────────────────────────────────────────────
// Destination addresses are stored in Firebase Secret Manager / environment
// config and are never visible in source code or the compiled client bundle.
//
// Set via:
//   firebase functions:secrets:set SMTP_USER
//   firebase functions:secrets:set SMTP_PASS
//   firebase functions:secrets:set EMAIL_CRASH
//   firebase functions:secrets:set EMAIL_BUG
//   firebase functions:secrets:set EMAIL_FEEDBACK
//
// Values:
//   SMTP_USER    → Gmail address used to send
//   SMTP_PASS    → Gmail app password (not account password)
//   EMAIL_CRASH  → sklatdevelopment+reportdump@gmail.com
//   EMAIL_BUG    → sklatdevelopment+userreport@gmail.com
//   EMAIL_FEEDBACK → sklatdevelopment+userfeedback@gmail.com

type ReportType = 'crash' | 'bug' | 'feedback';

interface SendReportPayload {
  type: ReportType;
  message?: string;
  userEmail?: string;
  log?: string;
  errorId?: string;
}

export const sendReport = onCall(
  {
    secrets: ['SMTP_USER', 'SMTP_PASS', 'EMAIL_CRASH', 'EMAIL_BUG', 'EMAIL_FEEDBACK'],
  },
  async (request) => {
    const data = request.data as SendReportPayload;

    if (!data.type || !['crash', 'bug', 'feedback'].includes(data.type)) {
      throw new HttpsError('invalid-argument', 'Invalid report type.');
    }

    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;

    if (!smtpUser || !smtpPass) {
      throw new HttpsError('failed-precondition', 'Email transport not configured.');
    }

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: smtpUser, pass: smtpPass },
    });

    const destination = (() => {
      switch (data.type) {
        case 'crash': return process.env.EMAIL_CRASH;
        case 'bug': return process.env.EMAIL_BUG;
        case 'feedback': return process.env.EMAIL_FEEDBACK;
      }
    })();

    if (!destination) {
      throw new HttpsError('failed-precondition', 'Destination email not configured.');
    }

    const subject = (() => {
      switch (data.type) {
        case 'crash': return `[PetBase] Crash Report — ${data.errorId ?? 'unknown'}`;
        case 'bug': return `[PetBase] Bug Report from ${data.userEmail ?? 'anonymous'}`;
        case 'feedback': return `[PetBase] Feedback from ${data.userEmail ?? 'anonymous'}`;
      }
    })();

    const body = [
      `Type: ${data.type}`,
      `From: ${data.userEmail ?? 'anonymous'}`,
      data.errorId ? `Error ID: ${data.errorId}` : null,
      '',
      data.message ? `Message:\n${data.message}` : null,
      '',
      data.log ? `--- Diagnostic Log (last 7 days) ---\n${data.log}` : null,
    ]
      .filter(Boolean)
      .join('\n');

    await transporter.sendMail({
      from: smtpUser,
      to: destination,
      subject,
      text: body,
    });

    return { success: true };
  },
);

// ─── Find Services (Google Places Proxy) ─────────────────────────────────────
// Set secret via: firebase functions:secrets:set GOOGLE_PLACES_KEY
//
// The frontend MUST call this via httpsCallable so the API key never appears
// in the client bundle.

interface PlacesSearchPayload {
  type: string;    // 'Vets' | 'Groomers' | 'Sitters' | 'Walkers' | 'Trainers' | 'Stores'
  location: string; // ZIP code
  query?: string;
}

const SERVICE_TYPE_MAP: Record<string, string> = {
  Vets: 'veterinary_care',
  Groomers: 'pet_store',
  Sitters: 'pet_store',
  Walkers: 'park',
  Trainers: 'pet_store',
  Stores: 'pet_store',
};

function fetchJson(url: string): Promise<any> {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

export const findServices = onCall(
  { secrets: ['GOOGLE_PLACES_KEY'] },
  async (request) => {
    const { type, location, query } = request.data as PlacesSearchPayload;
    const apiKey = process.env.GOOGLE_PLACES_KEY;
    if (!apiKey) throw new HttpsError('failed-precondition', 'Places API key not configured.');

    const placeType = SERVICE_TYPE_MAP[type] ?? 'pet_store';
    const searchQuery = encodeURIComponent(
      query ? `${query} near ${location}` : `${type} near ${location}`
    );

    const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${searchQuery}&type=${placeType}&key=${apiKey}`;
    const data = await fetchJson(url);

    if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
      throw new HttpsError('internal', `Places API error: ${data.status}`);
    }

    const results = (data.results ?? []).slice(0, 10).map((p: any, idx: number) => {
      const photoRef = p.photos?.[0]?.photo_reference;
      const image = photoRef
        ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photoRef}&key=${apiKey}`
        : `https://picsum.photos/seed/${p.place_id}/400/300`;
      return {
        id: p.place_id ?? String(idx),
        name: p.name,
        type,
        rating: p.rating ?? 0,
        reviews: p.user_ratings_total ?? 0,
        distance: '',
        address: p.formatted_address ?? p.vicinity ?? '',
        image,
        isVerified: true,
        petVerified: false,
        tags: p.types?.slice(0, 3) ?? [],
      };
    });

    return { results };
  },
);

// ─── Avatar Token Resolution ──────────────────────────────────────────────────
// Resolves a user's raw avatar Storage URL server-side so it never flows through
// client-facing search results (task-10 privacy compliance).
// The caller must be authenticated. Admin SDK bypasses Firestore client rules.
//
// Returns a signed Firebase Storage URL with 1-hour TTL (Task-20 compliance).
// Falls back to raw URL for base64 data URLs, external auth photo URLs, or emulator.

export const resolveAvatarToken = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'Login required.');
  }
  const { uid } = request.data as { uid: string };
  if (!uid || typeof uid !== 'string') {
    throw new HttpsError('invalid-argument', 'uid is required.');
  }
  const snap = await admin.firestore()
    .doc(`users/${uid}/profile/data`)
    .get();
  const avatarUrl: string = snap.data()?.avatarUrl ?? '';

  // If the stored URL is a Firebase Storage HTTPS URL, return a signed URL
  // with a 1-hour TTL so the raw permanent URL never leaves the server.
  if (avatarUrl.startsWith('https://firebasestorage.googleapis.com/')) {
    try {
      const parsed = new URL(avatarUrl);
      const pathMatch = parsed.pathname.match(/\/o\/(.+)$/);
      if (pathMatch) {
        const storagePath = decodeURIComponent(pathMatch[1]);
        const [signedUrl] = await admin.storage().bucket().file(storagePath).getSignedUrl({
          action: 'read',
          expires: Date.now() + 3600000,
        });
        return { url: signedUrl };
      }
    } catch {
      // Fall through to return raw URL if signing fails (e.g. local emulator)
    }
  }

  // Base64 data URLs, Google auth photo URLs, or empty strings are returned as-is.
  return { url: avatarUrl };
});

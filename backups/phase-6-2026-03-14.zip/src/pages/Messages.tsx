import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, Trash2, CheckCheck, ArrowLeft, ShieldOff, SquareCheck, Square } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSocial } from '../contexts/SocialContext';
import { useMessaging, type Conversation } from '../contexts/MessagingContext';
import type { DmMessage } from '../lib/firestoreService';
import { searchPublicProfiles } from '../lib/firestoreService';
import { getAvatarUrl } from '../lib/tokenService';

// ─── Avatar cache ─────────────────────────────────────────────────────────────
function useAvatarUrl(uid: string, rawUrl: string) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    let active = true;
    getAvatarUrl(uid, rawUrl).then(u => { if (active) setUrl(u); }).catch(() => {});
    return () => { active = false; };
  }, [uid, rawUrl]);
  return url;
}

// ─── Conversation row ─────────────────────────────────────────────────────────
function ConversationRow({
  convo,
  displayName,
  rawAvatarUrl,
  isActive,
  currentUid,
  isBlocked,
  onClick,
}: {
  convo: Conversation;
  displayName: string;
  rawAvatarUrl: string;
  isActive: boolean;
  currentUid: string;
  isBlocked: boolean;
  onClick: () => void;
}) {
  const avatar = useAvatarUrl(convo.otherUid, rawAvatarUrl);
  const isUnread = convo.lastMessage.toUid === currentUid && !convo.lastMessage.read;
  const initials = (displayName || '?').charAt(0).toUpperCase();

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors
        ${isActive
          ? 'bg-emerald-50 dark:bg-emerald-950/30'
          : 'hover:bg-stone-50 dark:hover:bg-stone-800/60'}
        focus-visible:ring-2 focus-visible:ring-sky-500 outline-none`}
    >
      {avatar ? (
        <img src={avatar} alt={displayName} width={40} height={40}
          className="w-10 h-10 rounded-full object-cover shrink-0 bg-stone-100 dark:bg-stone-800"
          referrerPolicy="no-referrer" />
      ) : (
        <div className="w-10 h-10 rounded-full bg-stone-200 dark:bg-stone-700 flex items-center justify-center shrink-0 text-sm font-bold text-stone-600 dark:text-stone-300">
          {initials}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className={`text-sm truncate ${isUnread ? 'font-bold text-stone-900 dark:text-stone-100' : 'font-medium text-stone-700 dark:text-stone-300'}`}>
            {displayName}
          </p>
          {isUnread && (
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" aria-label="Unread message" />
          )}
        </div>
        <p className="text-xs text-stone-500 dark:text-stone-400 truncate mt-0.5">
          {isBlocked ? <span className="text-rose-500 dark:text-rose-400">User Blocked</span>
            : convo.lastMessage.content}
        </p>
      </div>
    </button>
  );
}

// ─── Message bubble ───────────────────────────────────────────────────────────
function MessageBubble({
  message,
  isMine,
  isBlocked,
  isSelected,
  selectMode,
  onToggleSelect,
  onDelete,
}: {
  message: DmMessage;
  isMine: boolean;
  isBlocked: boolean;
  isSelected: boolean;
  selectMode: boolean;
  onToggleSelect: () => void;
  onDelete: () => void;
}) {
  const ts = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className={`flex items-end gap-2 ${isMine ? 'justify-end' : 'justify-start'}`}>
      {selectMode && (
        <button
          onClick={onToggleSelect}
          aria-label={isSelected ? 'Deselect message' : 'Select message'}
          className="p-1 text-stone-400 hover:text-emerald-500 transition-colors focus-visible:ring-2 focus-visible:ring-sky-500 outline-none shrink-0"
        >
          {isSelected ? <SquareCheck className="w-4 h-4 text-emerald-500" /> : <Square className="w-4 h-4" />}
        </button>
      )}
      <div className={`group max-w-[72%] ${isMine ? 'order-last' : ''}`}>
        <div className={`px-3 py-2 rounded-2xl text-sm leading-relaxed
          ${isMine
            ? 'bg-emerald-500 text-white rounded-br-sm'
            : isBlocked
              ? 'bg-stone-100 dark:bg-stone-800 text-stone-400 dark:text-stone-500 italic rounded-bl-sm'
              : 'bg-stone-100 dark:bg-stone-800 text-stone-900 dark:text-stone-100 rounded-bl-sm'}`}>
          {isBlocked && !isMine ? 'Message from blocked user' : message.content}
        </div>
        <div className={`flex items-center gap-1 mt-0.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
          <span className="text-[10px] text-stone-400 dark:text-stone-500">{ts}</span>
          {!selectMode && (
            <button
              onClick={onDelete}
              aria-label="Delete message"
              className="opacity-0 group-hover:opacity-100 p-0.5 text-stone-300 hover:text-rose-400 transition-all focus-visible:opacity-100 focus-visible:ring-2 focus-visible:ring-sky-500 outline-none"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Thread pane ──────────────────────────────────────────────────────────────
function ThreadPane({
  otherUid,
  displayName,
  rawAvatarUrl,
  isBlocked,
  onBack,
}: {
  otherUid: string;
  displayName: string;
  rawAvatarUrl: string;
  isBlocked: boolean;
  onBack: () => void;
}) {
  const { user } = useAuth();
  const { threadMessages, sendMessage, deleteMessage, markRead } = useMessaging();
  const [text, setText] = useState('');
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const bottomRef = useRef<HTMLDivElement>(null);
  const avatar = useAvatarUrl(otherUid, rawAvatarUrl);

  // Mark unread messages as read on open
  useEffect(() => {
    if (!user) return;
    threadMessages
      .filter(m => m.toUid === user.uid && !m.read)
      .forEach(m => markRead(m.id).catch(() => {}));
  }, [threadMessages, user, markRead]);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [threadMessages.length]);

  const toggleSelect = useCallback((id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const handleBulkDelete = useCallback(async () => {
    await Promise.all(
      Array.from(selected).map(id => {
        const m = threadMessages.find(m => m.id === id);
        if (!m) return Promise.resolve();
        return deleteMessage(id, m.fromUid);
      })
    );
    setSelected(new Set());
    setSelectMode(false);
  }, [selected, threadMessages, deleteMessage]);

  const handleBulkMarkRead = useCallback(async () => {
    await Promise.all(Array.from(selected).map(id => markRead(id)));
    setSelected(new Set());
    setSelectMode(false);
  }, [selected, markRead]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isBlocked) return;
    sendMessage(otherUid, text.trim()).catch(() => {});
    setText('');
  };

  const initials = (displayName || '?').charAt(0).toUpperCase();

  return (
    <div className="flex flex-col h-full">
      {/* Thread header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 shrink-0">
        <button
          onClick={onBack}
          aria-label="Back to conversations"
          className="md:hidden p-2 -ml-1 text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 focus-visible:ring-2 focus-visible:ring-sky-500 outline-none rounded-lg"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        {avatar ? (
          <img src={avatar} alt={displayName} width={36} height={36}
            className="w-9 h-9 rounded-full object-cover shrink-0 bg-stone-100"
            referrerPolicy="no-referrer" />
        ) : (
          <div className="w-9 h-9 rounded-full bg-stone-200 dark:bg-stone-700 flex items-center justify-center shrink-0 text-sm font-bold text-stone-600 dark:text-stone-300">
            {initials}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-stone-900 dark:text-stone-100 truncate">{displayName}</p>
          {isBlocked && (
            <p className="text-xs text-rose-500 dark:text-rose-400 flex items-center gap-1">
              <ShieldOff className="w-3 h-3" /> Blocked
            </p>
          )}
        </div>
        <button
          onClick={() => { setSelectMode(v => !v); setSelected(new Set()); }}
          aria-label={selectMode ? 'Cancel selection' : 'Select messages'}
          className={`p-2 rounded-lg text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-sky-500 outline-none
            ${selectMode
              ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400'
              : 'text-stone-400 hover:text-stone-600 dark:hover:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'}`}
        >
          <SquareCheck className="w-5 h-5" />
        </button>
      </div>

      {/* Bulk action bar */}
      <AnimatePresence>
        {selectMode && selected.size > 0 && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex items-center gap-2 px-4 py-2 bg-stone-50 dark:bg-stone-800 border-b border-stone-200 dark:border-stone-700 overflow-hidden shrink-0"
          >
            <span className="text-xs text-stone-500 dark:text-stone-400 flex-1">{selected.size} selected</span>
            <button
              onClick={handleBulkMarkRead}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-medium hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors focus-visible:ring-2 focus-visible:ring-sky-500 outline-none"
            >
              <CheckCheck className="w-3.5 h-3.5" /> Mark Read
            </button>
            <button
              onClick={handleBulkDelete}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 text-xs font-medium hover:bg-rose-200 dark:hover:bg-rose-900/50 transition-colors focus-visible:ring-2 focus-visible:ring-sky-500 outline-none"
            >
              <Trash2 className="w-3.5 h-3.5" /> Delete
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {threadMessages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-stone-400 dark:text-stone-500 py-12">
            <MessageSquare className="w-10 h-10 mb-3 opacity-30" />
            <p className="text-sm font-medium">No messages yet</p>
            <p className="text-xs mt-1">Say hi to {displayName}!</p>
          </div>
        )}
        {threadMessages.map(m => (
          <MessageBubble
            key={m.id}
            message={m}
            isMine={m.fromUid === user?.uid}
            isBlocked={isBlocked && m.fromUid !== user?.uid}
            isSelected={selected.has(m.id)}
            selectMode={selectMode}
            onToggleSelect={() => toggleSelect(m.id)}
            onDelete={() => deleteMessage(m.id, m.fromUid).catch(() => {})}
          />
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Compose */}
      <form
        onSubmit={handleSend}
        className="flex gap-2 p-3 border-t border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 shrink-0"
      >
        <input
          type="text"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={isBlocked ? 'You have blocked this user' : 'Type a message…'}
          disabled={isBlocked}
          maxLength={2000}
          aria-label="Message text"
          className="flex-1 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-600
            bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100
            placeholder:text-stone-400 text-sm
            focus:outline-none focus:ring-2 focus:ring-emerald-500
            disabled:opacity-50 disabled:cursor-not-allowed"
        />
        <button
          type="submit"
          disabled={!text.trim() || isBlocked}
          aria-label="Send message"
          className="min-h-[44px] min-w-[44px] flex items-center justify-center
            bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40
            text-white rounded-xl transition-colors
            focus-visible:ring-2 focus-visible:ring-sky-500 outline-none"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}

// ─── Profile name/avatar cache (looks up displayName from search) ─────────────
function useProfileCache(uids: string[]) {
  const [cache, setCache] = useState<Record<string, { displayName: string; avatarUrl: string }>>({});

  useEffect(() => {
    if (uids.length === 0) return;
    // Use empty query to get all public profiles, then filter
    searchPublicProfiles('').then(profiles => {
      const map: Record<string, { displayName: string; avatarUrl: string }> = {};
      profiles.forEach(p => {
        if (uids.includes(p.uid)) {
          map[p.uid] = { displayName: p.displayName, avatarUrl: p.avatarUrl };
        }
      });
      setCache(map);
    }).catch(() => {});
  }, [uids.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps

  return cache;
}

// ─── Main Messages page ───────────────────────────────────────────────────────
export function Messages() {
  const { user } = useAuth();
  const { profile } = useAuth() as any;
  const { conversations, setActiveUid, activeUid } = useMessaging();
  const { profile: socialProfile } = useSocial() as any || {};
  const blockedUsers: string[] = profile?.blockedUsers ?? [];

  // Mobile: show thread vs list
  const [mobileView, setMobileView] = useState<'list' | 'thread'>('list');

  const otherUids = useMemo(() => [...new Set(conversations.map(c => c.otherUid))], [conversations]);
  const profileCache = useProfileCache(otherUids);

  const handleSelectConvo = useCallback((otherUid: string) => {
    setActiveUid(otherUid);
    setMobileView('thread');
  }, [setActiveUid]);

  const handleBack = useCallback(() => {
    setActiveUid(null);
    setMobileView('list');
  }, [setActiveUid]);

  if (!user) return null;

  const activeConvo = conversations.find(c => c.otherUid === activeUid);
  const activeDisplayName = activeUid ? (profileCache[activeUid]?.displayName ?? activeUid) : '';
  const activeRawAvatar = activeUid ? (profileCache[activeUid]?.avatarUrl ?? '') : '';
  const activeIsBlocked = activeUid ? blockedUsers.includes(activeUid) : false;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="h-[calc(100vh-8rem)] md:h-[calc(100vh-4rem)] flex rounded-2xl overflow-hidden border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 shadow-sm"
    >
      {/* ── Conversation list (left pane / full-width on mobile) ── */}
      <div className={`
        flex-col border-r border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900
        w-full md:w-72 md:flex shrink-0
        ${mobileView === 'list' ? 'flex' : 'hidden md:flex'}
      `}>
        <div className="px-4 py-4 border-b border-stone-200 dark:border-stone-700">
          <h1 className="text-xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            Messages
          </h1>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-stone-100 dark:divide-stone-800">
          {conversations.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 px-6 text-center text-stone-400 dark:text-stone-500">
              <MessageSquare className="w-10 h-10 mb-3 opacity-30" />
              <p className="text-sm font-medium">No conversations yet</p>
              <p className="text-xs mt-1">Start a chat from the People page.</p>
            </div>
          )}
          {conversations.map(convo => {
            const cached = profileCache[convo.otherUid];
            return (
              <ConversationRow
                key={convo.threadId}
                convo={convo}
                displayName={cached?.displayName ?? convo.otherUid}
                rawAvatarUrl={cached?.avatarUrl ?? ''}
                isActive={activeUid === convo.otherUid}
                currentUid={user.uid}
                isBlocked={blockedUsers.includes(convo.otherUid)}
                onClick={() => handleSelectConvo(convo.otherUid)}
              />
            );
          })}
        </div>
      </div>

      {/* ── Thread pane (right pane / full-width on mobile) ── */}
      <div className={`
        flex-1 flex flex-col
        ${mobileView === 'thread' || activeUid ? 'flex' : 'hidden md:flex'}
      `}>
        {activeUid ? (
          <ThreadPane
            otherUid={activeUid}
            displayName={activeDisplayName}
            rawAvatarUrl={activeRawAvatar}
            isBlocked={activeIsBlocked}
            onBack={handleBack}
          />
        ) : (
          <div className="hidden md:flex flex-col items-center justify-center h-full text-stone-400 dark:text-stone-500">
            <MessageSquare className="w-12 h-12 mb-3 opacity-20" />
            <p className="text-sm font-medium">Select a conversation</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

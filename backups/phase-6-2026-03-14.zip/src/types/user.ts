/**
 * Canonical UserProfile type for PetBase.
 * Used by AuthContext (localStorage) and firestoreService (Firestore non-PII fields).
 * PII fields (address) are encrypted before any Firestore write — see firestoreService.ts.
 */

export type ProfileVisibility = 'Public' | 'Friends Only' | 'Private';
export type AvatarShape = 'circle' | 'square' | 'squircle';
export type PublicStatus = 'None' | 'Open to Playdates' | 'Looking for Walking Buddies';

export interface UserProfile {
  displayName: string;
  username?: string;
  address: string;          // PII — encrypted before Firestore write
  zipCode?: string;
  visibility: ProfileVisibility;
  publicStatus: PublicStatus;
  blockedUsers: string[];
  lostPetOptOut: boolean;
  friends: string[];
  avatarUrl?: string;
  avatarShape?: AvatarShape;
}

export const DEFAULT_PROFILE: UserProfile = {
  displayName: '',
  address: '',
  visibility: 'Public',     // Public by default — limited exposure (Display Name + pet types/count only)
  publicStatus: 'None',
  blockedUsers: [],
  lostPetOptOut: false,
  friends: [],
};

import { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { getPublicCard, type PublicCardDoc } from '../lib/firestoreService';
import type { EmergencyContacts } from '../types/pet';
import { PawPrint, Utensils, ShieldCheck, Clock, ShieldOff, Phone, HeartPulse, Layers, Syringe, Info, Shield, Heart } from 'lucide-react';

const TEMPLATE_LABELS: Record<string, string> = {
  vet: 'Vet Card',
  sitter: 'Sitter Card',
  emergency: 'Custom Card',
  custom: 'Custom Card',
};

const TEMPLATE_COLORS: Record<string, string> = {
  vet: 'bg-emerald-500',
  sitter: 'bg-violet-500',
  emergency: 'bg-rose-500',
  custom: 'bg-rose-500',
};

export function SharedCardPage() {
  const { cardId } = useParams<{ cardId: string }>();
  const [card, setCard] = useState<PublicCardDoc | null | 'loading' | 'not-found'>('loading');

  useEffect(() => {
    if (!cardId) { setCard('not-found'); return; }
    getPublicCard(cardId)
      .then(data => setCard(data ?? 'not-found'))
      .catch(() => setCard('not-found'));
  }, [cardId]);

  if (card === 'loading') {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (card === 'not-found' || card === null || card.status === 'revoked') {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center gap-4 p-6 text-center">
        <ShieldOff className="w-12 h-12 text-stone-400" />
        <h1 className="text-xl font-bold text-stone-700">Card Not Found</h1>
        <p className="text-stone-500 max-w-xs">This card is no longer valid.</p>
      </div>
    );
  }

  const isExpired = card.status !== 'active' || Date.now() > card.expiresAt;
  const isRevoked = false; // revoked cards are caught by the early-return guard above
  const headerColor = TEMPLATE_COLORS[card.template] ?? 'bg-emerald-500';

  const isMulti = card.petId === 'multi-pet' || card.petId === 'all-pets' || (card.multiPetConfig && card.multiPetConfig.length > 0);

  // Renders pet data sections in the order stored on the card (matches CardPreview exactly)
  const renderPetSnapshot = (pet: any, sharing: Record<string, boolean>, fieldOrder?: string[]) => {
    // DEFAULT_ORDER updated to remove separate medications block as it is now inside medicalOverview
    const DEFAULT_ORDER = ['basicInfo', 'personalityPlay', 'diet', 'medicalOverview', 'vaccineRecords', 'microchip', 'emergencyContact', 'vetInfo'];
    const order = fieldOrder ?? DEFAULT_ORDER;

    const sections: Record<string, React.ReactNode> = {
      basicInfo: sharing.basicInfo ? (
        <div key="basicInfo">
          <h3 className="font-bold text-stone-900 mb-2 uppercase tracking-wider text-xs flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5" /> Pet Description
          </h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {pet.breed && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Breed</p><p className="font-semibold text-stone-800">{pet.breed}</p></div>}
            {pet.type && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Type</p><p className="font-semibold text-stone-800">{pet.type}</p></div>}
            {(pet.age || pet.birthday) && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Age</p><p className="font-semibold text-stone-800">{pet.birthday ? `${Math.floor((Date.now() - new Date(pet.birthday).getTime()) / (365.25 * 24 * 60 * 60 * 1000))} yrs` : pet.age}</p></div>}
            {pet.weight && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Weight</p><p className="font-semibold text-stone-800">{pet.weight}</p></div>}
            {pet.spayedNeutered && pet.spayedNeutered !== 'Unknown' && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100 col-span-2"><p className="text-xs text-stone-400 mb-0.5">Spayed / Neutered</p><p className="font-semibold text-stone-800">{pet.spayedNeutered}</p></div>}
          </div>
        </div>
      ) : null,

      personalityPlay: sharing.personalityPlay && (pet.likes?.length || pet.dislikes?.length || pet.favoriteActivities?.length || pet.typeOfPlay || pet.activity) ? (
        <div key="personalityPlay" className="bg-violet-50 rounded-2xl p-3 border border-violet-100">
          <h3 className="text-violet-800 font-bold flex items-center gap-2 mb-2 text-sm"><Heart className="w-4 h-4" /> Personality &amp; Play</h3>
          <div className="space-y-1.5 text-xs text-violet-700">
            {pet.likes?.length > 0 && <p><span className="font-semibold">Likes:</span> {pet.likes.join(', ')}</p>}
            {pet.dislikes?.length > 0 && <p><span className="font-semibold">Dislikes:</span> {pet.dislikes.join(', ')}</p>}
            {pet.favoriteActivities?.length > 0 && <p><span className="font-semibold">Favorite Activities:</span> {pet.favoriteActivities.join(', ')}</p>}
            {pet.typeOfPlay && <p><span className="font-semibold">Type of Play:</span> {pet.typeOfPlay}</p>}
            {pet.activity && <p><span className="font-semibold">Activity Level:</span> {pet.activity}</p>}
          </div>
        </div>
      ) : null,

      diet: sharing.diet && (pet.food || pet.notes) ? (
        <div key="diet" className="text-sm">
          <h3 className="font-bold text-stone-900 mb-1 uppercase tracking-wider text-xs flex items-center gap-1.5">
            <Utensils className="w-3.5 h-3.5" /> Health &amp; Diet
          </h3>
          {pet.food && <p className="text-stone-600 mb-1">{pet.food}</p>}
          {pet.notes && (
            <div className="bg-blue-50 rounded-xl p-2.5 border border-blue-100 mt-1">
              <p className="text-xs text-blue-700">{pet.notes}</p>
            </div>
          )}
        </div>
      ) : null,

      medicalOverview: sharing.medicalOverview && pet.medications?.length > 0 ? (
        <div key="medicalOverview" className="bg-blue-50 rounded-2xl p-3 border border-blue-100">
          <h3 className="text-blue-800 font-bold flex items-center gap-2 mb-1 text-sm">
            <Syringe className="w-4 h-4" /> Medical Notes
          </h3>
          <div className="space-y-2 mt-2">
            {pet.medications.map((m: any, i: number) => {
              if (!m.name) return null;
              const freq = m.customFrequency || (m.frequency === '8 hours' ? 'As Needed' : m.frequency);
              return (
                <div key={i} className="text-xs border-b border-blue-100 last:border-0 pb-2 last:pb-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-900">{m.name}</span>
                    {freq && <span className="text-blue-600 font-medium">{freq}</span>}
                  </div>
                  {(m.dosage) && <p className="text-blue-700 mt-0.5">Dosage: {m.dosage}</p>}
                  {(m.startDate || m.endDate) && (
                    <p className="text-blue-500 text-[10px] mt-0.5 uppercase tracking-tight">
                      {m.startDate && `Start: ${m.startDate}`}
                      {m.startDate && m.endDate && ' • '}
                      {m.endDate && `End: ${m.endDate}`}
                    </p>
                  )}
                  {m.notes && <p className="text-blue-600 mt-1 italic leading-snug">{m.notes}</p>}
                </div>
              );
            })}
          </div>
        </div>
      ) : null,

      vaccineRecords: sharing.vaccineRecords && pet.vaccines?.length > 0 ? (
        <div key="vaccineRecords">
          <h3 className="font-bold text-stone-900 mb-2 uppercase tracking-wider text-xs flex items-center gap-1.5">
            <Syringe className="w-3.5 h-3.5" /> Vaccine Records
          </h3>
          <div className="space-y-1.5">
            {pet.vaccines.map((v: any, i: number) => {
              if (!v.name || (!v.lastDate && !v.nextDueDate)) return null;
              return (
                <div key={i} className="flex flex-col text-xs bg-stone-50 rounded-xl px-3 py-2 border border-stone-100">
                  <span className="font-medium text-stone-800">{v.name}</span>
                  <div className="flex justify-between text-stone-500 mt-0.5">
                    <span>Given: {v.lastDate || '—'}</span>
                    <span>Due: {v.nextDueDate || '—'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : null,

      medications: null, // Unified into Medical Notes above

      microchip: sharing.microchip ? (
        pet.microchipId ? (
          <div key="microchip" className="flex items-center gap-2 text-sm bg-stone-50 rounded-xl p-3 border border-stone-100">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <div>
              <span className="text-stone-700 font-medium">Microchipped</span>
              <p className="text-xs text-stone-500 mt-0.5">ID: {pet.microchipId}</p>
            </div>
          </div>
        ) : (
          <div key="microchip" className="flex items-center gap-2 text-sm bg-stone-50 rounded-xl p-3 border border-stone-100">
            <ShieldOff className="w-4 h-4 text-stone-400 shrink-0" />
            <span className="text-stone-500">Not Microchipped</span>
          </div>
        )
      ) : null,

      emergencyContact: sharing.emergencyContact ? (
        <div key="emergencyContact" className="bg-stone-50 rounded-2xl p-4 border border-stone-100 space-y-2">
          <h3 className="text-stone-900 font-bold flex items-center gap-1.5 mb-1 text-sm"><Phone className="w-4 h-4 text-blue-500" /> Emergency Contacts</h3>
          {pet.emergencyContacts?.ownerPhone && <div><p className="text-xs text-stone-500">Owner</p><p className="font-medium text-stone-800 text-sm">{pet.emergencyContacts.ownerPhone}</p></div>}
          {pet.emergencyContacts?.additionalContacts?.map((c: any, i: number) => (
            <div key={i}><p className="text-xs text-stone-500">{c.name}</p><p className="font-medium text-stone-800 text-sm">{c.phone}</p></div>
          ))}
          {(!pet.emergencyContacts?.ownerPhone && !pet.emergencyContacts?.additionalContacts?.length) && (
            <p className="text-xs text-stone-500 italic">Secondary contact info is not on file.</p>
          )}
        </div>
      ) : null,

      vetInfo: sharing.vetInfo && pet.emergencyContacts?.vetInfo ? (
        <div key="vetInfo" className="bg-stone-50 rounded-2xl p-4 border border-stone-100">
          <h3 className="text-stone-900 font-bold flex items-center gap-1.5 mb-1 text-sm"><HeartPulse className="w-4 h-4 text-emerald-500" /> Vet Info</h3>
          <p className="font-medium text-stone-800 text-sm">{pet.emergencyContacts.vetInfo.name}</p>
          <p className="text-xs text-stone-500">{pet.emergencyContacts.vetInfo.phone}</p>
          {pet.emergencyContacts.vetInfo.address && <p className="text-xs text-stone-500">{pet.emergencyContacts.vetInfo.address}</p>}
        </div>
      ) : null,
    };

    const orderedSections = order.map(k => sections[k] ?? null).filter(Boolean);
    const householdSection = pet.householdInfo ? (
      <div key="householdInfo">
        <h3 className="font-bold text-stone-900 mb-1.5 uppercase tracking-wider text-xs flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5" /> Household Information
        </h3>
        <p className="text-sm text-stone-600 bg-stone-50 rounded-xl p-2.5 border border-stone-100 whitespace-pre-wrap break-words">{pet.householdInfo}</p>
      </div>
    ) : null;

    return (
      <div className="p-5 space-y-4">
        {[...orderedSections, householdSection].filter(Boolean)}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col items-center justify-start py-10 px-4">
      {/* PetBase branding */}
      <div className="mb-6 flex items-center gap-2 text-stone-500 text-sm">
        <PawPrint className="w-4 h-4 text-emerald-500" />
        <span>Shared via <span className="font-semibold text-stone-700">PetBase</span></span>
      </div>

      <div className="bg-white rounded-[2rem] shadow-xl border border-stone-100 overflow-hidden w-full max-w-sm">
        {/* Status banner */}
        {(isRevoked || isExpired) && (
          <div className={`w-full text-center py-2 text-sm font-bold tracking-wide text-white ${isRevoked ? 'bg-rose-600' : 'bg-stone-400'}`}>
            {isRevoked ? '⛔ REVOKED' : '⏱ EXPIRED'}
          </div>
        )}

        {/* Header */}
        <div className={`h-28 ${headerColor} relative overflow-hidden`}>
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_30%_50%,white,transparent)]" />
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div>
              <p className="text-white/80 text-xs font-medium uppercase tracking-widest flex items-center gap-1">
                {isMulti && <Layers className="w-3 h-3" />}
                {isMulti ? 'Multi-pet Card' : (TEMPLATE_LABELS[card.template] ?? 'Pet Card')}
              </p>
              <h2 className="text-white font-extrabold text-2xl leading-tight">
                {isMulti ? `${card.multiPetConfig?.length || 0} Pets` : card.petSnapshot?.name}
              </h2>
            </div>
            {!isMulti && card.petSnapshot?.image && (
              <img
                src={card.petSnapshot.image}
                alt={card.petSnapshot.name}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-white/30 shadow"
                referrerPolicy="no-referrer"
              />
            )}
          </div>
        </div>

        {/* Body */}
        {isMulti && card.multiPetConfig ? (
          <div className="divide-y divide-stone-100">
            {card.multiPetConfig.map(cfg => (
              <div key={cfg.petId} className="flex flex-col">
                <div className="flex items-center gap-3 px-5 pt-5 pb-3">
                  {cfg.petSnapshot.image && (
                    <img
                      src={cfg.petSnapshot.image}
                      alt={cfg.petSnapshot.name}
                      className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                  )}
                  <div>
                    <h3 className="font-bold text-stone-900 text-lg leading-tight">{cfg.petSnapshot.name}</h3>
                    <p className="text-sm text-stone-500">{cfg.petSnapshot.breed}</p>
                  </div>
                </div>
                {renderPetSnapshot(cfg.petSnapshot, cfg.sharing, (card as any).fieldOrder)}
              </div>
            ))}
          </div>
        ) : (
          card.petSnapshot && renderPetSnapshot(card.petSnapshot, card.sharing, (card as any).fieldOrder)
        )}

        {/* Expiry */}
        <div className="px-5 py-4 bg-stone-50 flex items-center gap-2 text-xs text-stone-400 border-t border-stone-100">
          <Clock className="w-3.5 h-3.5 shrink-0" />
          {isExpired || isRevoked
            ? <span className="text-rose-500 font-medium flex items-center gap-1"><ShieldOff className="w-3.5 h-3.5" /> This card is no longer valid.</span>
            : <span>Expires {new Date(card.expiresAt).toLocaleDateString()}</span>
          }
        </div>
      </div>

      <p className="mt-6 text-xs text-stone-400 text-center">
        Powered by PetBase · This card was shared by its owner.
      </p>
    </div>
  );
}

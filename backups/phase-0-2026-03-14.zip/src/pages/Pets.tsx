﻿import { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router';
import { motion } from 'motion/react';
import { Activity, Bone, Heart, Ruler, Syringe, Weight, Plus, Pencil, IdCard, Smile, Zap, AlertTriangle, Image as ImageIcon, Lock, Trash2 } from 'lucide-react';
import { usePets } from '../contexts/PetContext';
import type { Pet } from '../contexts/PetContext';
import { useAuth } from '../contexts/AuthContext';
import { PetFormModal } from '../components/PetFormModal';
import { MedicalRecordsModal, overallVaccineStatus, getVaccineStatus, type Vaccine } from '../components/MedicalRecordsModal';
import { LostPetBanner } from '../components/LostPetBanner';
import type { LostPetAlert } from '../utils/lostPetsApi';

export function Pets() {
  const { pets, addPet, updatePet, deletePet } = usePets();
  const { profile } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPet, setEditingPet] = useState<Pet | undefined>(undefined);
  const [isMedicalModalOpen, setIsMedicalModalOpen] = useState(false);
  const [viewingMedicalPet, setViewingMedicalPet] = useState<Pet | null>(null);
  const [targetVaccineName, setTargetVaccineName] = useState<string | undefined>(undefined);
  const [medicalInitialTab, setMedicalInitialTab] = useState<'vaccines' | 'visits'>('vaccines');
  const [petToDelete, setPetToDelete] = useState<Pet | null>(null);
  const location = useLocation();
  const navigate = useNavigate();

  // Sync lost pet alerts to localStorage so lostPetsApi can surface them in Community/Dashboard
  useEffect(() => {
    const lostAlerts: LostPetAlert[] = pets
      .filter(p => p.lostStatus?.isLost && p.lostStatus.reportedAt > 0)
      .map(p => ({
        id: p.id,
        petName: p.name,
        petType: p.type ?? '',
        breed: p.breed || 'Unknown',
        image: p.image || '',
        ownerName: profile?.displayName || 'PetBase User',
        ownerPhone: 'Contact via PetBase',
        lastSeenLocation: profile?.address || profile?.zipCode || 'Unknown',
        reportedAt: p.lostStatus!.reportedAt,
        zipCode: profile?.zipCode || '',
      }));
    localStorage.setItem('petbase-lost-pets', JSON.stringify(lostAlerts));
  }, [pets, profile]);

  useEffect(() => {
    if (location.state?.openAddModal) {
      openAddModal();
      navigate(location.pathname, { replace: true, state: {} });
    } else if (location.state?.openMedical && pets.length > 0) {
      // Dashboard Quick Actions: "Add Meds" → vaccines tab, "Add Vet Visit" → visits tab
      const tab = location.state.tab === 'vet' ? 'visits' : 'vaccines';
      setViewingMedicalPet(pets[0]);
      setMedicalInitialTab(tab);
      setIsMedicalModalOpen(true);
      navigate(location.pathname, { replace: true, state: {} });
    } else if (location.state?.editPetId) {
      // Dashboard "Your Pets" widget: click a pet card → open its edit modal
      const target = pets.find(p => p.id === location.state.editPetId);
      if (target) {
        setEditingPet(target);
        setIsModalOpen(true);
      }
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, location.pathname, navigate, pets]);

  const openAddModal = () => {
    setEditingPet(undefined);
    setIsModalOpen(true);
  };

  const openEditModal = (pet: Pet) => {
    setEditingPet(pet);
    setIsModalOpen(true);
  };

  const openMedicalModal = (pet: Pet, vaccineName?: string, tab: 'vaccines' | 'visits' = 'vaccines') => {
    setViewingMedicalPet(pet);
    setTargetVaccineName(vaccineName);
    setMedicalInitialTab(tab);
    setIsMedicalModalOpen(true);
  };

  const handleSave = (data: Omit<Pet, 'id'>) => {
    if (editingPet) {
      updatePet({ ...data, id: editingPet.id });
    } else {
      addPet(data);
    }
  };

  const toggleLostStatus = (pet: Pet) => {
    const isCurrentlyLost = pet.lostStatus?.isLost;

    if (isCurrentlyLost) {
      if (window.confirm(`Mark ${pet.name} as found? This will remove the community alert.`)) {
        updatePet({ ...pet, lostStatus: { isLost: false, reportedAt: 0 } });
      }
    } else {
      if (window.confirm(`Are you sure you want to report ${pet.name} as lost? A local alert will be sent to the community in 15 minutes to give you time to cancel if this was a mistake.`)) {
        updatePet({ ...pet, lostStatus: { isLost: true, reportedAt: Date.now() } });
      }
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">
              My Pets
            </h1>
            <p className="text-stone-500 dark:text-stone-400 mt-1">
              Detailed profiles and health tracking.
            </p>
          </div>
          <button
            onClick={openAddModal}
            className="bg-stone-900 dark:bg-stone-100 hover:bg-stone-800 dark:hover:bg-stone-200 text-white dark:text-stone-900 px-5 py-2.5 rounded-xl font-medium transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Pet
          </button>
        </header>

        {/* Lost pet banners — one per currently-lost pet */}
        {pets.filter(p => p.lostStatus?.isLost).map(p => {
          const alert: LostPetAlert = {
            id: p.id,
            petName: p.name,
            petType: p.type ?? '',
            breed: p.breed || 'Unknown',
            image: p.image || '',
            ownerName: profile?.displayName || 'PetBase User',
            ownerPhone: 'Contact via PetBase',
            lastSeenLocation: profile?.address || profile?.zipCode || 'Unknown',
            reportedAt: p.lostStatus!.reportedAt,
            zipCode: profile?.zipCode || '',
          };
          return <LostPetBanner key={p.id} lostPet={alert} />;
        })}

        {pets.length === 0 && (
          <div className="text-center py-16 text-stone-500 dark:text-stone-400">
            <p className="text-lg font-medium">No pets yet.</p>
            <p className="text-sm mt-1">Click "Add Pet" to create your first pet profile.</p>
          </div>
        )}

        <div className="space-y-12">
          {pets.map((pet) => (
            <div
              key={pet.id}
              className="bg-white dark:bg-stone-800 rounded-3xl overflow-hidden shadow-sm border border-stone-100 dark:border-stone-700"
            >
              {pet.pageLayout === 'full-background' ? (
                <div className="h-48 md:h-64 overflow-hidden relative">
                  <img
                    src={pet.image}
                    alt={pet.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-6 left-6 text-white text-left max-w-[calc(100%-5rem)]">
                    <h2 className="text-2xl sm:text-4xl font-bold break-words">{pet.name}</h2>
                    <p className="text-white/80 font-medium mt-1 break-words">
                      {[pet.breed, pet.age].filter(Boolean).join(' • ')}
                    </p>
                  </div>
                  <div className="absolute top-4 right-4 flex gap-1.5 sm:gap-2">
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleLostStatus(pet);
                      }}
                      className={`${pet.lostStatus?.isLost
                        ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-600'
                        : 'bg-white/90 dark:bg-stone-800/90 text-stone-700 dark:text-stone-200 hover:bg-rose-50 dark:hover:bg-stone-700 hover:text-rose-600 dark:hover:text-rose-400'
                        } backdrop-blur-sm px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm cursor-pointer border border-transparent`}
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span className="hidden xs:inline">{pet.lostStatus?.isLost ? 'Mark Found' : 'Mark Lost'}</span>
                      <span className="xs:hidden">{pet.lostStatus?.isLost ? 'Found' : 'Lost'}</span>
                    </button>
                    <Link
                      to="/cards"
                      state={{ petId: pet.id }}
                      className="bg-white/90 dark:bg-stone-800/90 backdrop-blur-sm text-stone-700 dark:text-stone-200 hover:bg-white dark:hover:bg-stone-700 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm border border-transparent"
                    >
                      <IdCard className="w-3.5 h-3.5" />
                      <span>Card</span>
                    </Link>
                    <button
                      onClick={() => openEditModal(pet)}
                      className="bg-white/90 dark:bg-stone-800/90 backdrop-blur-sm text-stone-700 dark:text-stone-200 hover:bg-white dark:hover:bg-stone-700 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm border border-transparent"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => setPetToDelete(pet)}
                      className="bg-white/90 dark:bg-stone-800/90 backdrop-blur-sm text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm border border-transparent"
                      title="Delete pet"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  className={`h-48 md:h-64 relative border-b border-stone-100 dark:border-stone-700 ${!pet.backgroundColor ? 'bg-stone-100 dark:bg-stone-900' : ''}`}
                  style={pet.backgroundColor ? { backgroundColor: pet.backgroundColor } : undefined}
                >
                  <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)', backgroundSize: '16px 16px' }} />
                  <div className="absolute inset-x-6 bottom-6 flex items-end gap-6 text-left">
                    <div className={`w-32 h-32 border-4 border-white dark:border-stone-800 shadow-md shrink-0 flex items-center justify-center overflow-hidden ${pet.avatarShape === 'square' ? 'rounded-2xl' : pet.avatarShape === 'squircle' ? 'rounded-[2.5rem]' : 'rounded-full'}`} style={{ backgroundColor: pet.backgroundColor || '#e7e5e4' }}>
                      {pet.image ? (
                        <img src={pet.image} alt={pet.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-4xl font-bold text-white/70">{pet.name?.[0]?.toUpperCase()}</span>
                      )}
                    </div>
                    <div className="mb-2">
                      <div className="flex items-center gap-3">
                        <h2 className="text-2xl sm:text-4xl font-bold text-stone-900 dark:text-stone-100 break-words">{pet.name}</h2>
                        {pet.isPrivate && (
                          <span className="px-2.5 py-1 bg-white/50 dark:bg-stone-800/50 backdrop-blur-md text-stone-700 dark:text-stone-300 text-xs font-bold uppercase tracking-wider rounded-lg border border-stone-300/50 dark:border-stone-600/50 flex items-center gap-1.5 leading-none">
                            <Lock className="w-3.5 h-3.5" /> Private
                          </span>
                        )}
                      </div>
                      <p className="text-stone-600 dark:text-stone-400 font-medium mt-1">
                        {[pet.breed, pet.age].filter(Boolean).join(' • ')}
                      </p>
                    </div>
                  </div>
                  <div className="absolute top-4 right-4 flex gap-1.5 sm:gap-2">
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleLostStatus(pet);
                      }}
                      className={`${pet.lostStatus?.isLost
                        ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-600'
                        : 'bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 hover:bg-rose-50 dark:hover:bg-stone-700 hover:text-rose-600 dark:hover:text-rose-400 border border-stone-200 dark:border-stone-700'
                        } px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm cursor-pointer`}
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {pet.lostStatus?.isLost ? 'Found' : 'Lost'}
                    </button>
                    <Link
                      to="/cards"
                      state={{ petId: pet.id }}
                      className="bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-700 border border-stone-200 dark:border-stone-700 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm"
                    >
                      <IdCard className="w-3.5 h-3.5" />
                      Card
                    </Link>
                    <button
                      onClick={() => openEditModal(pet)}
                      className="bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-700 border border-stone-200 dark:border-stone-700 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      Edit
                    </button>
                    <button
                      onClick={() => setPetToDelete(pet)}
                      className="bg-white dark:bg-stone-800 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 border border-stone-200 dark:border-stone-700 px-2 sm:px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-colors shadow-sm"
                      title="Delete pet"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Stats Grid */}
                <div className="md:col-span-2 space-y-8">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <div className="bg-stone-50 dark:bg-stone-700/50 p-4 rounded-2xl border border-stone-100 dark:border-stone-700">
                      <Weight className="w-5 h-5 text-stone-400 dark:text-stone-500 mb-2" />
                      <p className="text-sm text-stone-500 dark:text-stone-400 font-medium">Weight</p>
                      <p className="text-lg font-bold text-stone-900 dark:text-stone-100">
                        {pet.weight || '—'}
                      </p>
                    </div>
                    <div className="bg-stone-50 dark:bg-stone-700/50 p-4 rounded-2xl border border-stone-100 dark:border-stone-700">
                      <Activity className="w-5 h-5 text-stone-400 dark:text-stone-500 mb-2" />
                      <p className="text-sm text-stone-500 dark:text-stone-400 font-medium">
                        Activity Level
                      </p>
                      <p className="text-lg font-bold text-stone-900 dark:text-stone-100">
                        {pet.activity || '—'}
                      </p>
                    </div>
                    <div className="bg-stone-50 dark:bg-stone-700/50 p-4 rounded-2xl border border-stone-100 dark:border-stone-700">
                      <Bone className="w-5 h-5 text-stone-400 dark:text-stone-500 mb-2" />
                      <p className="text-sm text-stone-500 dark:text-stone-400 font-medium">Diet</p>
                      <p className="text-lg font-bold text-stone-900 dark:text-stone-100">
                        {pet.food || '—'}
                      </p>
                    </div>
                  </div>

                  {((pet.likes && pet.likes.length > 0) ||
                    (pet.dislikes && pet.dislikes.length > 0) ||
                    (pet.favoriteActivities && pet.favoriteActivities.length > 0) ||
                    pet.typeOfPlay) && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                        {pet.likes && pet.likes.length > 0 && (
                          <div>
                            <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
                              <Heart className="w-5 h-5 text-rose-500" /> Likes
                            </h3>
                            <ul className="space-y-2">
                              {pet.likes.map((like, i) => (
                                <li
                                  key={i}
                                  className="flex items-center gap-2 text-stone-600 dark:text-stone-300 bg-rose-50 dark:bg-rose-950/30 px-3 py-1.5 rounded-lg text-sm font-medium"
                                >
                                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" />
                                  {like}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {pet.dislikes && pet.dislikes.length > 0 && (
                          <div>
                            <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
                              <Heart className="w-5 h-5 text-stone-300 dark:text-stone-600" /> Dislikes
                            </h3>
                            <ul className="space-y-2">
                              {pet.dislikes.map((dislike, i) => (
                                <li
                                  key={i}
                                  className="flex items-center gap-2 text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700/50 px-3 py-1.5 rounded-lg text-sm font-medium"
                                >
                                  <span className="w-1.5 h-1.5 rounded-full bg-stone-400 dark:bg-stone-500 shrink-0" />
                                  {dislike}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {pet.favoriteActivities && pet.favoriteActivities.length > 0 && (
                          <div>
                            <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
                              <Smile className="w-5 h-5 text-amber-500" /> Favorite Activities
                            </h3>
                            <ul className="space-y-2">
                              {pet.favoriteActivities.map((activity, i) => (
                                <li
                                  key={i}
                                  className="flex items-center gap-2 text-stone-600 dark:text-stone-300 bg-amber-50 dark:bg-amber-950/30 px-3 py-1.5 rounded-lg text-sm font-medium"
                                >
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                                  {activity}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {pet.typeOfPlay && (
                          <div>
                            <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
                              <Zap className="w-5 h-5 text-blue-500" /> Type of Play
                            </h3>
                            <div className="flex items-center gap-2 text-stone-600 dark:text-stone-300 bg-blue-50 dark:bg-blue-950/30 px-3 py-1.5 rounded-lg text-sm font-medium w-fit">
                              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                              {pet.typeOfPlay}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                  {/* Notes preview (PII — encrypted in Step 5) */}
                  {pet.notes && (
                    <div className="bg-stone-50 dark:bg-stone-700/50 p-4 rounded-2xl border border-stone-100 dark:border-stone-700">
                      <p className="text-sm font-semibold text-stone-700 dark:text-stone-300 mb-2">
                        Notes
                        <span className="text-xs font-normal bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full ml-2">
                          Encrypted
                        </span>
                      </p>
                      <p className="text-sm text-stone-600 dark:text-stone-400 whitespace-pre-wrap line-clamp-4">
                        {pet.notes}
                      </p>
                    </div>
                  )}
                </div>

                {/* Actions & Medical */}
                <div className="space-y-4">
                  <div className="bg-blue-50 dark:bg-blue-950/30 p-5 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                    <h3 className="font-semibold text-blue-900 dark:text-blue-300 flex items-center gap-2 mb-3">
                      <Syringe className="w-5 h-5 text-blue-500" /> Medical Overview
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-blue-700 dark:text-blue-400">Last Vet Visit</span>
                        <span className="font-medium text-blue-900 dark:text-blue-200">
                          {pet.lastVet || '—'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-blue-700 dark:text-blue-400">Vaccines/Medications</span>
                        {(() => {
                          const petVaccines = (pet as any).vaccines as Vaccine[] | undefined;
                          const petMeds = (pet as any).medications as Array<{ endDate: string }> | undefined;
                          const today = new Date().toISOString().split('T')[0];
                          const activeMeds = (petMeds ?? []).filter(m => !m.endDate || m.endDate >= today).length;
                          const hasVaccines = petVaccines && petVaccines.length > 0;
                          if (!hasVaccines && activeMeds === 0) {
                            return (
                              <button type="button" onClick={() => openMedicalModal(pet)} className="font-medium text-stone-500 bg-stone-100 dark:bg-stone-800 dark:text-stone-400 px-2 py-0.5 rounded hover:underline">
                                Not Set
                              </button>
                            );
                          }
                          const overdue = (petVaccines ?? []).filter(v => getVaccineStatus(v.nextDueDate) === 'overdue').length;
                          const dueSoon = (petVaccines ?? []).filter(v => getVaccineStatus(v.nextDueDate) === 'due-soon').length;
                          const upToDate = (petVaccines ?? []).filter(v => getVaccineStatus(v.nextDueDate) === 'up-to-date').length + activeMeds;
                          if (overdue > 0) {
                            const urgentVaccine = (petVaccines ?? []).find(v => getVaccineStatus(v.nextDueDate) === 'overdue');
                            return (
                              <button type="button" onClick={() => openMedicalModal(pet, urgentVaccine?.name)} className="font-medium text-rose-700 bg-rose-100 dark:bg-rose-900/40 dark:text-rose-400 px-2 py-0.5 rounded hover:underline">
                                {overdue} Overdue{dueSoon > 0 ? `, ${dueSoon} Due Soon` : ''}
                              </button>
                            );
                          }
                          if (dueSoon > 0) {
                            const urgentVaccine = (petVaccines ?? []).find(v => getVaccineStatus(v.nextDueDate) === 'due-soon');
                            return (
                              <button type="button" onClick={() => openMedicalModal(pet, urgentVaccine?.name)} className="font-medium text-amber-700 bg-amber-100 dark:bg-amber-900/40 dark:text-amber-400 px-2 py-0.5 rounded hover:underline">
                                {dueSoon} Due Soon
                              </button>
                            );
                          }
                          return (
                            <button type="button" onClick={() => openMedicalModal(pet)} className="font-medium text-emerald-600 bg-emerald-100 dark:bg-emerald-900/40 dark:text-emerald-400 px-2 py-0.5 rounded hover:underline">
                              {upToDate} Up to Date
                            </button>
                          );
                        })()}
                      </div>
                    </div>
                    <button
                      onClick={() => openMedicalModal(pet)}
                      className="w-full mt-4 bg-white dark:bg-stone-700 text-blue-700 dark:text-blue-300 font-medium py-2 rounded-xl text-sm hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"
                    >
                      View Full Records
                    </button>
                  </div>

                  <div className="bg-stone-50 dark:bg-stone-700/50 p-5 rounded-2xl border border-stone-200 dark:border-stone-600 space-y-3">
                    <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-3">
                      <Ruler className="w-5 h-5 text-stone-500" /> Measurements
                    </h3>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-stone-500 dark:text-stone-400">Height</span>
                      <span className="font-medium text-stone-900 dark:text-stone-100">
                        {pet.height || '—'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-stone-500 dark:text-stone-400">Length</span>
                      <span className="font-medium text-stone-900 dark:text-stone-100">
                        {pet.length || '—'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-stone-500 dark:text-stone-400">Body Score</span>
                      <span className="font-medium text-stone-900 dark:text-stone-100">
                        {pet.bodyConditionScore || '—'}
                      </span>
                    </div>
                  </div>
                </div>


                {/* Photo Gallery Grid */}
                {pet.gallery && pet.gallery.filter(Boolean).length > 0 && (
                  <div className="border-t border-stone-100 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-800/50 p-6 md:p-8">
                    <h3 className="font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
                      <ImageIcon className="w-5 h-5 text-stone-500 shrink-0" /> Photo Gallery
                    </h3>
                    <div className="columns-2 sm:columns-3 lg:columns-4 gap-4 space-y-4">
                      {pet.gallery.filter(Boolean).map((url, i) => (
                        <div key={i} className="break-inside-avoid rounded-xl overflow-hidden shadow-sm border border-stone-200 dark:border-stone-700 bg-stone-100 dark:bg-stone-800">
                          <img
                            src={url}
                            alt={`${pet.name} photo ${i + 1}`}
                            className="w-full object-cover hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <PetFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        pet={editingPet}
      />

      <MedicalRecordsModal
        isOpen={isMedicalModalOpen}
        onClose={() => setIsMedicalModalOpen(false)}
        pet={viewingMedicalPet}
        targetVaccineName={targetVaccineName}
        initialTab={medicalInitialTab}
      />

      {/* Delete confirmation modal */}
      {petToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onMouseDown={e => e.target === e.currentTarget && setPetToDelete(null)}
        >
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div className="relative bg-white dark:bg-stone-900 rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-700 w-full max-w-sm p-6 space-y-4 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-900/40 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <h2 className="font-bold text-stone-900 dark:text-stone-100">Delete {petToDelete.name}?</h2>
                <p className="text-sm text-stone-500 dark:text-stone-400">This cannot be undone.</p>
              </div>
            </div>
            <p className="text-sm text-stone-600 dark:text-stone-300">
              All data for <span className="font-semibold">{petToDelete.name}</span> will be permanently removed — including medical records, shared cards, and lost pet alerts.
            </p>
            <div className="flex gap-3 pt-1">
              <button
                onClick={() => setPetToDelete(null)}
                className="flex-1 px-4 py-2.5 rounded-xl border border-stone-200 dark:border-stone-600 text-stone-700 dark:text-stone-200 font-semibold text-sm hover:bg-stone-50 dark:hover:bg-stone-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => { deletePet(petToDelete.id); setPetToDelete(null); }}
                className="flex-1 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm transition-colors"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

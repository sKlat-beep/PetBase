import React, { useState, useRef, useMemo, useCallback, useEffect, type ReactNode } from 'react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { Link, useLocation, useNavigate } from 'react-router';
import {
  Share2, HeartPulse, Phone,
  Plus, QrCode, Clock, ShieldOff, ChevronDown, ChevronUp,
  CheckCircle2, XCircle, PawPrint, Info, Utensils, Syringe, RotateCcw, Layers, Shield, RefreshCw,
  GripVertical, Heart, Pencil
} from 'lucide-react';
import { QRCodeCanvas as QRCode } from 'qrcode.react';
import { usePets } from '../contexts/PetContext';
import { useAuth } from '../contexts/AuthContext';
import type { Pet, EmergencyContacts } from '../types/pet';
import { canShare } from '../utils/platform';
import { getVaccineStatus, type Vaccine } from '../components/MedicalRecordsModal';
import { markCardCreated } from '../components/GettingStartedGuide';
import { logActivity } from '../utils/activityLog';
import { savePublicCard, updatePublicCardStatus, deletePublicCard, getPublicCardsForOwner, updatePublicCardStatusWithTimestamp, type PublicCardPetSnapshot } from '../lib/firestoreService';

// ─── Types ────────────────────────────────────────────────────────────────────

type CardTemplate = 'vet' | 'sitter' | 'emergency' | 'custom';
type CardStatus = 'active' | 'expired' | 'revoked';

interface SharingToggles {
  basicInfo: boolean;
  medicalOverview: boolean;
  vaccineRecords: boolean;
  medications: boolean;
  microchip: boolean;
  diet: boolean;
  emergencyContact: boolean;
  vetInfo: boolean;
  personalityPlay: boolean;
}

type MultiPetConfig = { petId: string; sharing: SharingToggles; petSnapshot?: PublicCardPetSnapshot }[];

interface PetCard {
  id: string;
  petId: string;           // 'all-pets' | 'multi-pet' | actual pet id
  template: CardTemplate;
  createdAt: number;
  expiresAt: number;
  status: CardStatus;
  sharing: SharingToggles; // used for single/all-pets; per-pet overrides in multiPetConfig
  multiPetConfig?: MultiPetConfig;
  revokedAt?: number;
  includeGeneralInfo?: boolean;
  petSnapshot?: PublicCardPetSnapshot;
  fieldOrder?: string[];
}

const GENERAL_INFO_KEY = 'petbase-cards-general-info';

// ─── Expiration Options ────────────────────────────────────────────────────────

const EXPIRATION_OPTIONS: { label: string; ms: number }[] = [
  { label: '24 hours', ms: 24 * 60 * 60 * 1000 },
  { label: '48 hours', ms: 48 * 60 * 60 * 1000 },
  { label: '1 week', ms: 7 * 24 * 60 * 60 * 1000 },
  { label: '1 month', ms: 30 * 24 * 60 * 60 * 1000 },
  { label: '3 months', ms: 90 * 24 * 60 * 60 * 1000 },
  { label: '6 months', ms: 180 * 24 * 60 * 60 * 1000 },
  { label: '1 year', ms: 365 * 24 * 60 * 60 * 1000 },
];

const TEMPLATE_DEFAULTS: Record<string, SharingToggles> = {
  vet: {
    basicInfo: true, medicalOverview: true, vaccineRecords: true, medications: true,
    microchip: true, diet: true, emergencyContact: false, vetInfo: true, personalityPlay: true,
  },
  sitter: {
    basicInfo: false, medicalOverview: false, vaccineRecords: false, medications: true,
    microchip: true, diet: true, emergencyContact: true, vetInfo: true, personalityPlay: true,
  },
  emergency: {
    basicInfo: false, medicalOverview: false, vaccineRecords: false, medications: false,
    microchip: false, diet: false, emergencyContact: false, vetInfo: false, personalityPlay: false,
  },
  custom: {
    basicInfo: false, medicalOverview: false, vaccineRecords: false, medications: false,
    microchip: false, diet: false, emergencyContact: false, vetInfo: false, personalityPlay: false,
  },
};

const TEMPLATE_LABELS: Record<string, string> = {
  vet: 'Vet Card',
  sitter: 'Sitter Card',
  emergency: 'Custom Card',
  custom: 'Custom Card',
};

const TEMPLATE_COLORS: Record<string, string> = {
  vet: 'bg-blue-600',
  sitter: 'bg-emerald-600',
  emergency: 'bg-rose-600',
  custom: 'bg-rose-600',
};

const CUSTOM_TEMPLATE_KEY = 'petbase-custom-card-template';
const UNDO_WINDOW_MS = 5 * 60 * 1000; // 5 minutes
const MAX_INACTIVE_CARDS = 10;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getCardStatus(card: PetCard): CardStatus {
  if (card.status === 'revoked') return 'revoked';
  if (Date.now() > card.expiresAt) return 'expired';
  return 'active';
}

function formatExpiry(ms: number): string {
  const d = new Date(ms);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function timeUntilExpiry(expiresAt: number): string {
  const diff = expiresAt - Date.now();
  if (diff <= 0) return 'Expired';
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}d ${hours % 24}h remaining`;
  return `${hours}h remaining`;
}

// ─── Staleness check ──────────────────────────────────────────────────────────

/** Returns true if the pet's current data differs from what was snapshotted into the card. */
function isPetDataStale(card: PetCard, pet: Pet): boolean {
  const snap = card.petSnapshot;
  if (!snap) return false; // no snapshot means card predates snapshot feature
  const keys: (keyof Pet)[] = ['name', 'breed', 'type', 'image', 'weight', 'birthday', 'age',
    'food', 'foodBrand', 'foodAmount', 'foodUnit', 'dislikes', 'spayedNeutered',
    'likes', 'favoriteActivities', 'typeOfPlay', 'activity'] as any;
  for (const k of keys) {
    if (JSON.stringify((pet as any)[k]) !== JSON.stringify((snap as any)[k])) return true;
  }
  if (card.sharing.microchip && (pet as any).microchipId !== (snap as any).microchipId) return true;
  return false;
}

// ─── buildPetSnapshot ─────────────────────────────────────────────────────────

function buildPetSnapshot(
  pet: Pet,
  sharing: SharingToggles,
  includeGeneralInfo: boolean,
  generalInfoText: string,
  uid: string | undefined,
): PublicCardPetSnapshot {
  const emergencyContacts: EmergencyContacts | undefined = (() => {
    if (!(sharing.emergencyContact || sharing.vetInfo)) return undefined;
    if (pet.emergencyContacts) return pet.emergencyContacts;
    try {
      const raw = uid ? localStorage.getItem(`petbase-profile-emergency-${uid}`) : null;
      return raw ? JSON.parse(raw) : undefined;
    } catch { return undefined; }
  })();
  return {
    name: pet.name, breed: pet.breed, type: pet.type, image: pet.image,
    weight: pet.weight, birthday: pet.birthday, age: pet.age,
    avatarShape: pet.avatarShape, backgroundColor: pet.backgroundColor,
    food: pet.food, foodBrand: pet.foodBrand, foodAmount: pet.foodAmount,
    foodUnit: pet.foodUnit,
    activity: sharing.personalityPlay ? pet.activity : undefined,
    likes: sharing.personalityPlay ? pet.likes : undefined,
    dislikes: sharing.personalityPlay ? pet.dislikes : undefined,
    favoriteActivities: sharing.personalityPlay ? (pet as any).favoriteActivities : undefined,
    typeOfPlay: sharing.personalityPlay ? (pet as any).typeOfPlay : undefined,
    spayedNeutered: (pet as any).spayedNeutered,
    lastVet: sharing.vetInfo ? pet.lastVet : undefined,
    notes: sharing.medicalOverview ? pet.notes : undefined,
    vaccines: sharing.vaccineRecords ? (pet as any).vaccines : undefined,
    medications: sharing.medications ? (pet as any).medications : undefined,
    emergencyContacts,
    microchipId: sharing.microchip ? (pet as any).microchipId : undefined,
    householdInfo: includeGeneralInfo && generalInfoText ? generalInfoText : undefined,
  };
}

// ─── Card Preview (print-optimized — intentionally kept light) ─────────────────

function CardPreview({ pet, card }: { pet: Pet; card: PetCard }) {
  const status = getCardStatus(card);
  const headerColor = TEMPLATE_COLORS[card.template];

  const data = card.petSnapshot ?? pet;

  return (
    <div id={`card-preview-${card.id}`} className="bg-white rounded-[2rem] shadow-xl border border-stone-100 overflow-hidden relative max-w-md mx-auto w-full print:shadow-none print:border-0">
      {/* Status banner for expired/revoked */}
      {status !== 'active' && (
        <div className={`w-full text-center py-2 text-sm font-bold tracking-wide text-white ${status === 'revoked' ? 'bg-rose-600' : 'bg-stone-400'}`}>
          {status === 'revoked' ? '⛔ REVOKED' : '⏱ EXPIRED'}
        </div>
      )}

      {/* Header bar */}
      <div className={`h-28 ${headerColor} relative overflow-hidden`}>
        <div
          className="absolute inset-0 opacity-20"
          style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '20px 20px' }}
        />
        <div className="absolute top-2 right-3 text-white/80 text-xs font-semibold uppercase tracking-wider">
          {TEMPLATE_LABELS[card.template]}
        </div>
      </div>

      {/* Avatar — uses snapshot data so preview matches the shared URL exactly */}
      <div className="absolute top-8 left-1/2 -translate-x-1/2">
        <div className={`w-28 h-28 border-4 border-white overflow-hidden shadow-lg bg-stone-100 ${(data as any).avatarShape === 'square' ? 'rounded-xl' : (data as any).avatarShape === 'squircle' ? 'rounded-[2rem]' : 'rounded-full'}`} style={!data.image && (data as any).backgroundColor ? { backgroundColor: (data as any).backgroundColor } : undefined}>
          {data.image ? (
            <img src={data.image} alt={data.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-3xl font-bold text-white/80">
              {data.name?.[0]?.toUpperCase()}
            </div>
          )}
        </div>
      </div>

      <div className="pt-18 pb-8 px-8 text-center" style={{ paddingTop: '5.5rem' }}>
        {/* Pet name — navigable to /pets */}
        <Link to="/pets" className="text-3xl font-bold text-stone-900 hover:text-emerald-600 transition-colors no-underline">
          {data.name}
        </Link>

        <div className="mt-6 space-y-4 text-left">
          {/* Sections rendered in user-defined order */}
          {(() => {
            const DEFAULT_ORDER = ['basicInfo', 'personalityPlay', 'diet', 'medicalOverview', 'vaccineRecords', 'medications', 'microchip', 'emergencyContact', 'vetInfo'];
            const order = card.fieldOrder ?? DEFAULT_ORDER;

            const sections: Record<string, React.ReactNode> = {
              basicInfo: card.sharing.basicInfo ? (
                <div key="basicInfo">
                  <h3 className="font-bold text-stone-900 mb-2 uppercase tracking-wider text-xs flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5" /> Pet Description
                  </h3>
                  <div className="grid grid-cols-2 gap-2 text-sm mb-2">
                    {data.breed && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Breed</p><p className="font-semibold text-stone-800 text-xs">{data.breed}</p></div>}
                    {data.type && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Type</p><p className="font-semibold text-stone-800 text-xs">{data.type}</p></div>}
                    {(data.age || data.birthday) && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Age</p><p className="font-semibold text-stone-800 text-xs">{data.birthday ? `${Math.floor((Date.now() - new Date(data.birthday).getTime()) / (365.25 * 24 * 60 * 60 * 1000))} yrs` : data.age}</p></div>}
                    {data.weight && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100"><p className="text-xs text-stone-400 mb-0.5">Weight</p><p className="font-semibold text-stone-800 text-xs">{data.weight}</p></div>}
                    {(data as any).spayedNeutered && (data as any).spayedNeutered !== 'Unknown' && <div className="bg-stone-50 rounded-xl p-2 border border-stone-100 col-span-2"><p className="text-xs text-stone-400 mb-0.5">Spayed/Neutered</p><p className="font-semibold text-stone-800 text-xs">{(data as any).spayedNeutered}</p></div>}
                  </div>
                </div>
              ) : null,

              personalityPlay: card.sharing.personalityPlay && ((data as any).likes?.length || (data as any).dislikes?.length || (data as any).favoriteActivities?.length || (data as any).typeOfPlay || (data as any).activity) ? (
                <div key="personalityPlay" className="bg-violet-50 rounded-2xl p-3 border border-violet-100">
                  <h3 className="text-violet-800 font-bold flex items-center gap-2 mb-2 text-sm"><Heart className="w-4 h-4" /> Personality &amp; Play</h3>
                  <div className="space-y-1.5 text-xs text-violet-700">
                    {(data as any).likes?.length > 0 && <p><span className="font-semibold">Likes:</span> {(data as any).likes.join(', ')}</p>}
                    {(data as any).dislikes?.length > 0 && <p><span className="font-semibold">Dislikes:</span> {(data as any).dislikes.join(', ')}</p>}
                    {(data as any).favoriteActivities?.length > 0 && <p><span className="font-semibold">Favorite Activities:</span> {(data as any).favoriteActivities.join(', ')}</p>}
                    {(data as any).typeOfPlay && <p><span className="font-semibold">Type of Play:</span> {(data as any).typeOfPlay}</p>}
                    {(data as any).activity && <p><span className="font-semibold">Activity Level:</span> {(data as any).activity}</p>}
                  </div>
                </div>
              ) : null,

              diet: card.sharing.diet && (data.food || data.notes) ? (
                <div key="diet" className="text-sm">
                  <h3 className="font-bold text-stone-900 mb-1 uppercase tracking-wider text-xs flex items-center gap-1.5">
                    <Utensils className="w-3.5 h-3.5" /> Health &amp; Diet
                  </h3>
                  {data.food && <p className="text-stone-600 mb-1">{data.food}</p>}
                  {data.notes && (
                    <div className="bg-blue-50 rounded-xl p-2.5 border border-blue-100 mt-1">
                      <p className="text-xs text-blue-700">{data.notes}</p>
                    </div>
                  )}
                </div>
              ) : null,

              medicalOverview: card.sharing.medicalOverview && data.medications?.length > 0 ? (
                <div key="medicalOverview" className="bg-blue-50 rounded-2xl p-3 border border-blue-100">
                  <h3 className="text-blue-800 font-bold flex items-center gap-2 mb-1 text-sm">
                    <Syringe className="w-4 h-4" /> Medical Notes
                  </h3>
                  <div className="space-y-2 mt-1.5">
                    {data.medications.map((m: any, i: number) => {
                      if (!m.name) return null;
                      const freq = m.customFrequency || (m.frequency === '8 hours' ? 'As Needed' : m.frequency);
                      return (
                        <div key={i} className="text-xs border-b border-blue-100 last:border-0 pb-1.5 last:pb-0">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-blue-900">{m.name}</span>
                            {freq && <span className="text-blue-600 font-medium">{freq}</span>}
                          </div>
                          {m.dosage && <p className="text-blue-700 mt-0.5">Dosage: {m.dosage}</p>}
                          {(m.startDate || m.endDate) && (
                            <p className="text-blue-500 text-[9px] mt-0.5 uppercase tracking-tight">
                              {m.startDate && `Start: ${m.startDate}`}
                              {m.startDate && m.endDate && ' • '}
                              {m.endDate && `End: ${m.endDate}`}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : null,

              vaccineRecords: card.sharing.vaccineRecords ? (() => {
                const vaccines: Vaccine[] = (data as any).vaccines ?? [];
                const filled = vaccines.filter(v => v.name && (v.lastDate || v.nextDueDate));
                if (!filled.length) return null;
                return (
                  <div key="vaccineRecords">
                    <h3 className="font-bold text-stone-900 mb-2 uppercase tracking-wider text-xs flex items-center gap-1.5">
                      <Syringe className="w-3.5 h-3.5" /> Vaccine Records
                    </h3>
                    <div className="space-y-1.5">
                      {filled.map((v, i) => {
                        const status = getVaccineStatus(v.nextDueDate);
                        return (
                          <div key={i} className="flex items-center justify-between text-xs bg-stone-50 rounded-xl px-3 py-2 border border-stone-100">
                            <span className="font-medium text-stone-800">{v.name}</span>
                            <span className={`font-semibold ${status === 'overdue' ? 'text-rose-600' : status === 'due-soon' ? 'text-amber-600' : status === 'up-to-date' ? 'text-emerald-600' : 'text-stone-400'}`}>
                              {status === 'overdue' ? '❌ Overdue' : status === 'due-soon' ? '⚠️ Due' : status === 'up-to-date' ? '✅' : '—'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })() : null,

              medications: null, // Shared in Medical Notes

              microchip: card.sharing.microchip ? (
                (data as any).microchipId ? (
                  <div key="microchip">
                    <h3 className="font-bold text-stone-900 mb-1.5 uppercase tracking-wider text-xs flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5" /> Microchip ID
                    </h3>
                    <p className="text-xs bg-stone-50 rounded-xl px-3 py-2 border border-stone-100 font-mono text-stone-700 break-all">
                      {(data as any).microchipId}
                    </p>
                  </div>
                ) : (
                  <div key="microchip" className="flex items-center gap-2 text-sm bg-stone-50 rounded-xl p-3 border border-stone-100">
                    <ShieldOff className="w-4 h-4 text-stone-400 shrink-0" />
                    <span className="text-stone-500">Not Microchipped</span>
                  </div>
                )
              ) : null,

              emergencyContact: card.sharing.emergencyContact ? (
                <div key="emergencyContact" className="bg-stone-50 rounded-2xl p-4 border border-stone-100 space-y-3 text-left">
                  <div>
                    <h3 className="text-stone-900 font-bold flex items-center gap-1.5 mb-1 text-sm"><Phone className="w-4 h-4 text-blue-500" /> Emergency Contacts</h3>
                    {data.emergencyContacts?.ownerPhone && (
                      <div className="mb-2">
                        <p className="text-xs text-stone-500">Owner</p>
                        <p className="font-medium text-stone-800 text-sm">{data.emergencyContacts.ownerPhone}</p>
                      </div>
                    )}
                    {data.emergencyContacts?.additionalContacts?.filter(c => c.name || c.phone).map((c, i) => (
                      <div key={i} className="mb-2 last:mb-0">
                        <p className="text-xs text-stone-500">{c.name}</p>
                        <p className="font-medium text-stone-800 text-sm">{c.phone}</p>
                      </div>
                    ))}
                    {(!data.emergencyContacts?.ownerPhone && !data.emergencyContacts?.additionalContacts?.some(c => c.name || c.phone)) && (
                      <p className="text-xs text-stone-500 italic">Secondary contact info is not on file.</p>
                    )}
                  </div>
                </div>
              ) : null,

              vetInfo: card.sharing.vetInfo && data.emergencyContacts?.vetInfo ? (
                <div key="vetInfo" className="bg-stone-50 rounded-2xl p-4 border border-stone-100">
                  <h3 className="text-stone-900 font-bold flex items-center gap-1.5 mb-1 text-sm"><HeartPulse className="w-4 h-4 text-emerald-500" /> Vet Info</h3>
                  <p className="font-medium text-stone-800 text-sm">{data.emergencyContacts.vetInfo.name}</p>
                  <p className="text-xs text-stone-500">{data.emergencyContacts.vetInfo.phone}</p>
                  {data.emergencyContacts.vetInfo.address && <p className="text-xs text-stone-500">{data.emergencyContacts.vetInfo.address}</p>}
                </div>
              ) : null,
            };

            const orderedSections = order.map(k => sections[k] ?? null).filter(Boolean);
            // Household info is always appended last (not in fieldOrder — it's a separate opt-in)
            const householdSection = card.includeGeneralInfo ? (() => {
              const gi = (data as any).householdInfo ?? localStorage.getItem(GENERAL_INFO_KEY) ?? '';
              if (!gi) return null;
              return (
                <div key="householdInfo">
                  <h3 className="font-bold text-stone-900 mb-1.5 uppercase tracking-wider text-xs flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5" /> Household Information
                  </h3>
                  <p className="text-xs text-stone-600 bg-stone-50 rounded-xl px-3 py-2 border border-stone-100 whitespace-pre-wrap break-words">{gi}</p>
                </div>
              );
            })() : null;

            return [...orderedSections, householdSection].filter(Boolean);
          })()}
        </div>

        {/* Expiry note */}
        {status === 'active' && (
          <p className="mt-6 text-xs text-stone-400 text-center">Expires {formatExpiry(card.expiresAt)}</p>
        )}
      </div>
    </div>
  );
}

// ─── All Pets Composite Preview ────────────────────────────────────────────────

function AllPetsCardPreview({ pets, card }: {
  pets: Pet[];
  card: PetCard;
}) {
  const status = getCardStatus(card);
  const visiblePets = pets.filter(p => !p.isPrivate);

  return (
    <div id={`card-preview-${card.id}`} className="bg-white rounded-[2rem] shadow-xl border border-stone-100 overflow-hidden max-w-md mx-auto w-full print:shadow-none">
      {status !== 'active' && (
        <div className={`w-full text-center py-2 text-sm font-bold tracking-wide text-white ${status === 'revoked' ? 'bg-rose-600' : 'bg-stone-400'}`}>
          {status === 'revoked' ? '⛔ REVOKED' : '⏱ EXPIRED'}
        </div>
      )}
      <div className="h-20 bg-gradient-to-r from-emerald-600 to-teal-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
        <div className="absolute top-2 right-3 text-white/80 text-xs font-semibold uppercase tracking-wider flex items-center gap-1">
          <Layers className="w-3.5 h-3.5" /> All Pets
        </div>
        <div className="absolute bottom-3 left-5 text-white font-bold text-lg">
          {visiblePets.length} Pet{visiblePets.length !== 1 ? 's' : ''}
        </div>
      </div>

      <div className="p-6 space-y-3">
        {visiblePets.length === 0 ? (
          <p className="text-center text-stone-400 text-sm py-4">No public pets to display.</p>
        ) : (
          visiblePets.map(pet => (
            <div key={pet.id} className="flex items-center gap-3 bg-stone-50 rounded-xl p-3 border border-stone-100">
              {pet.image ? (
                <img src={pet.image} alt={pet.name} className={`w-12 h-12 object-cover border-2 border-white shadow-sm ${pet.avatarShape === 'square' ? 'rounded-lg' : 'rounded-full'}`} referrerPolicy="no-referrer" />
              ) : (
                <div className={`w-12 h-12 border-2 border-white shadow-sm flex items-center justify-center text-lg font-bold text-white/80 ${pet.avatarShape === 'square' ? 'rounded-lg' : 'rounded-full'}`} style={{ backgroundColor: pet.backgroundColor || '#a8a29e' }}>{pet.name?.[0]?.toUpperCase()}</div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-bold text-stone-900 truncate">{pet.name}</p>
                <p className="text-xs text-stone-500 truncate">{pet.breed}{pet.age ? ` · ${pet.age}` : ''}{pet.weight ? ` · ${pet.weight}` : ''}</p>
              </div>
            </div>
          ))
        )}

        {status === 'active' && (
          <p className="text-xs text-stone-400 text-center pt-2">Expires {formatExpiry(card.expiresAt)}</p>
        )}
      </div>
    </div>
  );
}

// ─── Multi-Pet Card Preview ────────────────────────────────────────────────────

function MultiPetCardPreview({ pets, card }: {
  pets: Pet[];
  card: PetCard;
}) {
  const status = getCardStatus(card);
  const config = card.multiPetConfig ?? [];
  const includedPets = config.map(cfg => ({ cfg, pet: pets.find(p => p.id === cfg.petId) })).filter(x => x.pet);

  return (
    <div id={`card-preview-${card.id}`} className="bg-white rounded-[2rem] shadow-xl border border-stone-100 overflow-hidden max-w-md mx-auto w-full print:shadow-none">
      {status !== 'active' && (
        <div className={`w-full text-center py-2 text-sm font-bold tracking-wide text-white ${status === 'revoked' ? 'bg-rose-600' : 'bg-stone-400'}`}>
          {status === 'revoked' ? '⛔ REVOKED' : '⏱ EXPIRED'}
        </div>
      )}
      {/* Header */}
      <div className="h-20 bg-gradient-to-r from-violet-600 to-indigo-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '20px 20px' }} />
        <div className="absolute top-2 right-3 text-white/80 text-xs font-semibold uppercase tracking-wider flex items-center gap-1">
          <Layers className="w-3.5 h-3.5" /> Multi-pet Card
        </div>
        <div className="absolute bottom-3 left-5 text-white font-bold text-lg">
          {includedPets.length} Pet{includedPets.length !== 1 ? 's' : ''} — {TEMPLATE_LABELS[card.template]}
        </div>
      </div>

      {/* Scrollable pet sections */}
      <div className="max-h-[60vh] overflow-y-auto">
        {includedPets.length === 0 ? (
          <p className="text-center text-stone-400 text-sm py-8">No pets selected.</p>
        ) : (
          includedPets.map(({ cfg, pet }) => {
            return (
              <div key={cfg.petId} className="border-b border-stone-100 last:border-b-0">
                {/* Pet header strip */}
                <div className="flex items-center gap-3 px-5 pt-5 pb-3">
                  {pet!.image ? (
                    <img src={pet!.image} alt={pet!.name} className={`w-14 h-14 object-cover border-2 border-white shadow-md ${pet!.avatarShape === 'square' ? 'rounded-xl' : 'rounded-full'}`} referrerPolicy="no-referrer" />
                  ) : (
                    <div className={`w-14 h-14 border-2 border-white shadow-md flex items-center justify-center text-xl font-bold text-white/80 ${pet!.avatarShape === 'square' ? 'rounded-xl' : 'rounded-full'}`} style={{ backgroundColor: pet!.backgroundColor || '#a8a29e' }}>{pet!.name?.[0]?.toUpperCase()}</div>
                  )}
                  <div>
                    <p className="font-bold text-stone-900 text-lg leading-tight">{pet!.name}</p>
                  </div>
                </div>

                {/* Data sections — snapshot-aware, fieldOrder-consistent with CardPreview */}
                <div className="px-5 pb-5 space-y-3">
                  {(() => {
                    const data: any = cfg.petSnapshot ?? pet!;
                    const DEFAULT_ORDER = ['basicInfo', 'personalityPlay', 'diet', 'medicalOverview', 'vaccineRecords', 'medications', 'microchip', 'emergencyContact', 'vetInfo'];
                    const order = card.fieldOrder ?? DEFAULT_ORDER;
                    const sections: Record<string, React.ReactNode> = {
                      basicInfo: cfg.sharing.basicInfo ? (
                        <div key="basicInfo" className="grid grid-cols-2 gap-1.5 text-xs">
                          {data.breed && <div className="bg-stone-50 rounded-lg p-2 border border-stone-100"><p className="text-stone-400 mb-0.5">Breed</p><p className="font-semibold text-stone-800">{data.breed}</p></div>}
                          {data.type && <div className="bg-stone-50 rounded-lg p-2 border border-stone-100"><p className="text-stone-400 mb-0.5">Type</p><p className="font-semibold text-stone-800">{data.type}</p></div>}
                          {(data.age || data.birthday) && <div className="bg-stone-50 rounded-lg p-2 border border-stone-100"><p className="text-stone-400 mb-0.5">Age</p><p className="font-semibold text-stone-800">{data.birthday ? `${Math.floor((Date.now() - new Date(data.birthday).getTime()) / (365.25 * 24 * 60 * 60 * 1000))} yrs` : data.age}</p></div>}
                          {data.weight && <div className="bg-stone-50 rounded-lg p-2 border border-stone-100"><p className="text-stone-400 mb-0.5">Weight</p><p className="font-semibold text-stone-800">{data.weight}</p></div>}
                        </div>
                      ) : null,
                      personalityPlay: cfg.sharing.personalityPlay && (data.likes?.length || data.dislikes?.length || data.favoriteActivities?.length || data.typeOfPlay || data.activity) ? (
                        <div key="personalityPlay" className="bg-violet-50 rounded-2xl p-3 border border-violet-100">
                          <h3 className="text-violet-800 font-bold flex items-center gap-2 mb-1.5 text-sm"><Heart className="w-4 h-4" /> Personality &amp; Play</h3>
                          <div className="space-y-1 text-xs text-violet-700">
                            {data.likes?.length > 0 && <p><span className="font-semibold">Likes:</span> {data.likes.join(', ')}</p>}
                            {data.dislikes?.length > 0 && <p><span className="font-semibold">Dislikes:</span> {data.dislikes.join(', ')}</p>}
                            {data.favoriteActivities?.length > 0 && <p><span className="font-semibold">Fav Activities:</span> {data.favoriteActivities.join(', ')}</p>}
                            {data.typeOfPlay && <p><span className="font-semibold">Play Style:</span> {data.typeOfPlay}</p>}
                            {data.activity && <p><span className="font-semibold">Activity:</span> {data.activity}</p>}
                          </div>
                        </div>
                      ) : null,
                      diet: cfg.sharing.diet && (data.food || data.notes) ? (
                        <div key="diet" className="text-sm">
                          <h3 className="font-bold text-stone-900 mb-1 uppercase tracking-wider text-xs flex items-center gap-1.5"><Utensils className="w-3.5 h-3.5" /> Health &amp; Diet</h3>
                          {data.food && <p className="text-stone-600 text-xs mb-1">{data.food}</p>}
                          {data.notes && <div className="bg-blue-50 rounded-lg p-2 border border-blue-100 mt-1"><p className="text-xs text-blue-700">{data.notes}</p></div>}
                        </div>
                      ) : null,
                      medicalOverview: cfg.sharing.medicalOverview && data.medications?.length > 0 ? (
                        <div key="medicalOverview" className="bg-blue-50 rounded-2xl p-3 border border-blue-100">
                          <h3 className="text-blue-800 font-bold flex items-center gap-2 mb-1 text-sm"><Syringe className="w-4 h-4" /> Medical Notes</h3>
                          <div className="space-y-1.5 mt-1">
                            {data.medications.map((m: any, i: number) => {
                              if (!m.name) return null;
                              const freq = m.customFrequency || (m.frequency === '8 hours' ? 'As Needed' : m.frequency);
                              return (
                                <div key={i} className="text-[10px] border-b border-blue-100 last:border-0 pb-1 last:pb-0">
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-blue-900">{m.name}</span>
                                    {freq && <span className="text-blue-600 font-medium">{freq}</span>}
                                  </div>
                                  {(m.dosage || m.startDate || m.endDate) && (
                                    <p className="text-blue-700 mt-0.5 leading-tight">
                                      {m.dosage && `Dosage: ${m.dosage}`}
                                      {m.dosage && (m.startDate || m.endDate) && ' · '}
                                      {m.startDate && `From ${m.startDate}`}
                                      {m.endDate && ` to ${m.endDate}`}
                                    </p>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ) : null,
                      vaccineRecords: cfg.sharing.vaccineRecords ? (() => {
                        const vaccines: Vaccine[] = data.vaccines ?? [];
                        const filled = vaccines.filter((v: Vaccine) => v.name && (v.lastDate || v.nextDueDate));
                        if (!filled.length) return null;
                        return (
                          <div key="vaccineRecords">
                            <h3 className="font-bold text-stone-900 mb-1.5 uppercase tracking-wider text-xs flex items-center gap-1.5"><Syringe className="w-3.5 h-3.5" /> Vaccine Records</h3>
                            <div className="space-y-1">
                              {filled.map((v: Vaccine, i: number) => {
                                const st = getVaccineStatus(v.nextDueDate);
                                return (
                                  <div key={i} className="flex items-center justify-between text-xs bg-stone-50 rounded-lg px-2.5 py-1.5 border border-stone-100">
                                    <span className="font-medium text-stone-800">{v.name}</span>
                                    <span className={`font-semibold ${st === 'overdue' ? 'text-rose-600' : st === 'due-soon' ? 'text-amber-600' : st === 'up-to-date' ? 'text-emerald-600' : 'text-stone-400'}`}>{st === 'overdue' ? '❌' : st === 'due-soon' ? '⚠️' : st === 'up-to-date' ? '✅' : '—'}</span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })() : null,
                      medications: null, // Unified above
                      microchip: cfg.sharing.microchip ? (
                        data.microchipId ? (
                          <div key="microchip">
                            <h3 className="font-bold text-stone-900 mb-1 uppercase tracking-wider text-xs flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Microchip ID</h3>
                            <p className="text-xs bg-stone-50 rounded-lg px-2.5 py-1.5 border border-stone-100 font-mono text-stone-700 break-all">{data.microchipId}</p>
                          </div>
                        ) : (
                          <div key="microchip" className="flex items-center gap-2 text-xs bg-stone-50 rounded-lg p-2.5 border border-stone-100">
                            <ShieldOff className="w-3.5 h-3.5 text-stone-400 shrink-0" /><span className="text-stone-500">Not Microchipped</span>
                          </div>
                        )
                      ) : null,
                      emergencyContact: cfg.sharing.emergencyContact ? (
                        <div key="emergencyContact" className="bg-stone-50 rounded-xl p-3 border border-stone-100">
                          <h3 className="text-stone-900 font-bold flex items-center gap-1 text-xs"><Phone className="w-3.5 h-3.5 text-blue-500" /> Emergency Contacts</h3>
                          {data.emergencyContacts?.ownerPhone && <div className="mb-1"><p className="text-[10px] text-stone-500 leading-none">Owner</p><p className="font-medium text-stone-800 text-xs">{data.emergencyContacts.ownerPhone}</p></div>}
                          {data.emergencyContacts?.additionalContacts?.filter((c: any) => c.name || c.phone).map((c: any, i: number) => (
                            <div key={i} className="mb-1 last:mb-0"><p className="text-[10px] text-stone-500 leading-none">{c.name}</p><p className="font-medium text-stone-800 text-xs">{c.phone}</p></div>
                          ))}
                        </div>
                      ) : null,
                      vetInfo: cfg.sharing.vetInfo && data.emergencyContacts?.vetInfo ? (
                        <div key="vetInfo" className="bg-stone-50 rounded-xl p-3 border border-stone-100">
                          <h3 className="text-stone-900 font-bold flex items-center gap-1 text-xs"><HeartPulse className="w-3.5 h-3.5 text-emerald-500" /> Vet Info</h3>
                          <p className="font-medium text-stone-800 text-xs">{data.emergencyContacts.vetInfo.name}</p>
                          <p className="text-[10px] text-stone-500">{data.emergencyContacts.vetInfo.phone}</p>
                        </div>
                      ) : null,
                    };
                    return order.map(k => sections[k] ? <React.Fragment key={k}>{sections[k]}</React.Fragment> : null);
                  })()}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Expiry note */}
      {status === 'active' && (
        <p className="text-xs text-stone-400 text-center py-3 border-t border-stone-100">Expires {formatExpiry(card.expiresAt)}</p>
      )}
    </div>
  );
}

// ─── Multi-Pet Card Modal ──────────────────────────────────────────────────────

const SHARING_FIELDS: { key: keyof SharingToggles; label: string; icon: ReactNode }[] = [
  { key: 'basicInfo', label: 'Pet Description', icon: <Info className="w-3.5 h-3.5" /> },
  { key: 'diet', label: 'Health & Diet', icon: <Utensils className="w-3.5 h-3.5" /> },
  { key: 'emergencyContact', label: 'Emergency Contact', icon: <Phone className="w-3.5 h-3.5" /> },
  { key: 'medicalOverview', label: 'Medical Notes', icon: <HeartPulse className="w-3.5 h-3.5" /> },
  { key: 'medications', label: 'Medications', icon: <Syringe className="w-3.5 h-3.5" /> },
  { key: 'microchip', label: 'Microchip ID', icon: <Shield className="w-3.5 h-3.5" /> },
  { key: 'personalityPlay', label: 'Personality & Play', icon: <Heart className="w-3.5 h-3.5" /> },
  { key: 'vaccineRecords', label: 'Vaccine Records', icon: <Syringe className="w-3.5 h-3.5" /> },
  { key: 'vetInfo', label: 'Vet Info', icon: <HeartPulse className="w-3.5 h-3.5" /> },
];

function MultiPetCardModal({ pets, onClose, onCreate, editCard }: {
  pets: Pet[];
  onClose: () => void;
  onCreate: (card: PetCard) => void;
  editCard?: PetCard;
}) {
  const publicPets = pets.filter(p => !p.isPrivate);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => {
    if (editCard?.multiPetConfig) return new Set(editCard.multiPetConfig.map(c => c.petId));
    return new Set(publicPets.slice(0, 2).map(p => p.id));
  });
  const [perPetSharing, setPerPetSharing] = useState<Record<string, SharingToggles>>(() => {
    const init: Record<string, SharingToggles> = {};
    if (editCard?.multiPetConfig) {
      editCard.multiPetConfig.forEach(c => { init[c.petId] = { ...c.sharing } as SharingToggles; });
    } else {
      publicPets.forEach(p => { init[p.id] = { ...TEMPLATE_DEFAULTS.sitter }; });
    }
    return init;
  });
  const [expandedPetId, setExpandedPetId] = useState<string | null>(null);
  const [template, setTemplate] = useState<CardTemplate>(editCard?.template || 'sitter');
  const [customDays, setCustomDays] = useState(() => {
    if (editCard) return Math.max(0, Math.floor((editCard.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)));
    return 2;
  });
  const [customHours, setCustomHours] = useState(() => {
    if (editCard) return Math.max(0, Math.floor(((editCard.expiresAt - Date.now()) / (1000 * 60 * 60)) % 24));
    return 0;
  });

  const togglePet = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const updateSharing = (petId: string, key: keyof SharingToggles, val: boolean) => {
    setPerPetSharing(prev => ({ ...prev, [petId]: { ...prev[petId], [key]: val } }));
  };

  const handleCreate = () => {
    const totalHours = Math.max(8, customDays * 24 + customHours);
    const expiresAt = Date.now() + totalHours * 60 * 60 * 1000;
    const multiPetConfig: MultiPetConfig = [...selectedIds].map(petId => ({
      petId,
      sharing: perPetSharing[petId] ?? { ...TEMPLATE_DEFAULTS.sitter },
    }));
    const newCard: PetCard = {
      id: editCard?.id || crypto.randomUUID(),
      petId: 'multi-pet',
      template,
      createdAt: editCard?.createdAt || Date.now(),
      expiresAt,
      status: editCard?.status || 'active',
      sharing: { ...TEMPLATE_DEFAULTS[template] },
      multiPetConfig,
    };
    onCreate(newCard);
    markCardCreated();
    onClose();
  };

  const canCreate = selectedIds.size >= 2;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-stone-800 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="bg-gradient-to-r from-violet-700 to-indigo-700 p-5 shrink-0">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-violet-200" /> {editCard ? 'Edit Multi-pet Card' : 'Multi-pet Card'}
          </h2>
          <p className="text-violet-200 text-sm mt-1">{editCard ? 'Update sharing options and validity.' : 'Select 2+ pets and configure what data each card shows.'}</p>
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-6">
          {/* Pet selection */}
          <div>
            <label className="text-sm font-semibold text-stone-700 dark:text-stone-300 mb-2 block">
              Select Pets <span className="font-normal text-stone-400">(minimum 2)</span>
            </label>
            {publicPets.length < 2 ? (
              <p className="text-sm text-stone-400 dark:text-stone-500">You need at least 2 public pets to create a Multi-pet Card.</p>
            ) : (
              <div className="space-y-2">
                {publicPets.map(pet => {
                  const isSelected = selectedIds.has(pet.id);
                  const isExpanded = expandedPetId === pet.id;
                  return (
                    <div key={pet.id} className={`rounded-xl border-2 transition-all ${isSelected ? 'border-violet-400 dark:border-violet-600' : 'border-stone-200 dark:border-stone-700'}`}>
                      <div className="flex items-center gap-3 p-3">
                        <input type="checkbox" checked={isSelected} disabled={!!editCard} onChange={() => togglePet(pet.id)} className="w-4 h-4 accent-violet-600 disabled:opacity-50" />
                        {pet.image ? (
                          <img src={pet.image} alt={pet.name} className="w-9 h-9 rounded-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white/80" style={{ backgroundColor: pet.backgroundColor || '#a8a29e' }}>{pet.name?.[0]?.toUpperCase()}</div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-stone-800 dark:text-stone-200 truncate">{pet.name}</p>
                          <p className="text-xs text-stone-400 truncate">{pet.breed || pet.type || '—'}</p>
                        </div>
                        {isSelected && (
                          <button type="button" onClick={() => setExpandedPetId(isExpanded ? null : pet.id)} className="text-xs text-violet-600 dark:text-violet-400 flex items-center gap-0.5 font-medium">
                            Data {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>
                        )}
                      </div>
                      {isSelected && isExpanded && (
                        <div className="border-t border-stone-100 dark:border-stone-700 px-4 py-3 space-y-2 bg-stone-50/50 dark:bg-stone-700/30 rounded-b-xl">
                          <p className="text-xs font-medium text-stone-500 dark:text-stone-400 mb-1">Included data for {pet.name}:</p>
                          {SHARING_FIELDS.map(({ key, label, icon }) => (
                            <label key={key} className="flex items-center justify-between py-1">
                              <span className="flex items-center gap-2 text-xs text-stone-600 dark:text-stone-300">{icon} {label}</span>
                              <input type="checkbox" checked={perPetSharing[pet.id]?.[key] ?? true} onChange={e => updateSharing(pet.id, key, e.target.checked)} className="w-3.5 h-3.5 accent-violet-600" />
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Template */}
          <div>
            <label className="text-sm font-semibold text-stone-700 dark:text-stone-300 mb-2 block">Card Type</label>
            <div className="grid grid-cols-3 gap-2">
              {(['vet', 'sitter', 'custom'] as CardTemplate[]).map(t => (
                <button key={t} onClick={() => setTemplate(t)} className={`py-2 rounded-xl text-sm font-semibold border-2 transition-all ${template === t ? 'border-violet-500 bg-violet-50 dark:bg-violet-950/30 text-violet-700 dark:text-violet-300' : 'border-stone-200 dark:border-stone-600 text-stone-600 dark:text-stone-400 hover:border-stone-300'}`}>
                  {TEMPLATE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          {/* Expiration */}
          <div>
            <label className="text-sm font-semibold text-stone-700 dark:text-stone-300 mb-2 flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> Expiration <span className="font-normal text-stone-400">(min 8 hours)</span>
            </label>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-xs text-stone-500 mb-1 block">Days</label>
                <input type="number" min="0" value={customDays} onChange={e => setCustomDays(Math.max(0, parseInt(e.target.value) || 0))} className="w-full border border-stone-200 dark:border-stone-600 rounded-xl px-3 py-2 text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-700 focus:ring-2 focus:ring-violet-500 outline-none" />
              </div>
              <div className="flex-1">
                <label className="text-xs text-stone-500 mb-1 block">Hours</label>
                <input type="number" min="0" max="23" value={customHours} onChange={e => setCustomHours(Math.max(0, parseInt(e.target.value) || 0))} className="w-full border border-stone-200 dark:border-stone-600 rounded-xl px-3 py-2 text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-700 focus:ring-2 focus:ring-violet-500 outline-none" />
              </div>
            </div>
          </div>
        </div>

        <div className="p-5 border-t border-stone-100 dark:border-stone-700 flex gap-3 shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-stone-200 dark:border-stone-600 text-stone-700 dark:text-stone-300 font-medium hover:bg-stone-50 dark:hover:bg-stone-700 transition-colors">
            Cancel
          </button>
          <button onClick={handleCreate} disabled={!canCreate} className="flex-1 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {editCard ? 'Save Changes' : (canCreate ? `Create Card (${selectedIds.size} pets)` : 'Select 2+ pets')}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Create Card Modal ─────────────────────────────────────────────────────────

function CreateCardModal({
  pets,
  onClose,
  onCreate,
  generalInfoText,
  editCard,
}: {
  pets: Pet[];
  onClose: () => void;
  onCreate: (card: PetCard) => void;
  generalInfoText: string;
  editCard?: PetCard;
}) {
  const savedCustomTemplate = useMemo(() => {
    try { return JSON.parse(localStorage.getItem(CUSTOM_TEMPLATE_KEY) || 'null') as { sharing: SharingToggles; includeGeneralInfo: boolean; customDays: number; customHours: number } | null; }
    catch { return null; }
  }, []);

  const [selectedPetId, setSelectedPetId] = useState(editCard?.petId || pets[0]?.id || '');
  const [template, setTemplate] = useState<CardTemplate>(editCard?.template || 'vet');
  const [customDays, setCustomDays] = useState(() => {
    if (editCard) return Math.max(0, Math.floor((editCard.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)));
    return 365;
  });
  const [customHours, setCustomHours] = useState(() => {
    if (editCard) return Math.max(0, Math.floor(((editCard.expiresAt - Date.now()) / (1000 * 60 * 60)) % 24));
    return 0;
  });
  const [sharing, setSharing] = useState<SharingToggles>(() => {
    if (editCard) return { ...editCard.sharing } as SharingToggles;
    return { ...TEMPLATE_DEFAULTS.vet };
  });
  const [includeGeneralInfo, setIncludeGeneralInfo] = useState(() => {
    if (editCard) return editCard.includeGeneralInfo ?? false;
    return false;
  });
  const [customTemplateSaved, setCustomTemplateSaved] = useState(() => {
    const initTemplate = editCard?.template || 'vet';
    return initTemplate !== 'custom' && initTemplate !== 'emergency';
  });
  const [sortableOrder, setSortableOrder] = useState<string[]>(() => {
    if (editCard?.fieldOrder) return editCard.fieldOrder;
    return SHARING_FIELDS.map(f => f.key as string);
  });

  const handleTemplateChange = (t: CardTemplate) => {
    setTemplate(t);
    if (t === 'custom' || t === 'emergency') {
      setSharing(savedCustomTemplate?.sharing ?? { ...TEMPLATE_DEFAULTS.custom });
      setIncludeGeneralInfo(savedCustomTemplate?.includeGeneralInfo ?? false);
      if (!editCard) {
        setCustomDays(savedCustomTemplate?.customDays ?? 0);
        setCustomHours(savedCustomTemplate?.customHours ?? 8);
      }
      setCustomTemplateSaved(false);
    } else {
      setSharing({ ...TEMPLATE_DEFAULTS[t] });
      setIncludeGeneralInfo(t === 'sitter');
      if (!editCard) {
        setCustomDays(t === 'vet' ? 365 : 0);
        setCustomHours(t === 'vet' ? 0 : 8);
      }
      setCustomTemplateSaved(true);
    }
  };

  const handleSaveCustomTemplate = () => {
    const tplData = { sharing: { ...sharing }, includeGeneralInfo, customDays, customHours };
    localStorage.setItem(CUSTOM_TEMPLATE_KEY, JSON.stringify(tplData));
    setCustomTemplateSaved(true);
  };

  const handleCreate = () => {
    const totalHours = Math.max(8, customDays * 24 + customHours);
    const expiresAt = Date.now() + totalHours * 60 * 60 * 1000;

    const newCard: PetCard = {
      id: editCard?.id || crypto.randomUUID(),
      petId: selectedPetId,
      template,
      createdAt: editCard?.createdAt || Date.now(),
      expiresAt,
      status: editCard?.status || 'active',
      sharing,
      includeGeneralInfo: includeGeneralInfo && !!generalInfoText,
      fieldOrder: sortableOrder,
    };
    onCreate(newCard);
    markCardCreated();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-stone-800 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
      >
        <div className="bg-stone-900 dark:bg-stone-950 p-5">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <QrCode className="w-5 h-5 text-emerald-400" /> {editCard ? 'Edit Pet Card' : 'Create Pet Card'}
          </h2>
          <p className="text-stone-400 text-sm mt-1">{editCard ? 'Update sharing options and validity.' : 'Choose your pet, template, and sharing options.'}</p>
        </div>

        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* Pet select */}
          <div>
            <label className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5 block">Pet</label>
            <select
              value={selectedPetId}
              disabled={!!editCard}
              onChange={e => setSelectedPetId(e.target.value)}
              className="w-full border border-stone-200 dark:border-stone-600 rounded-xl px-3 py-2 text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-700 focus:ring-2 focus:ring-emerald-500 outline-none disabled:opacity-50"
            >
              {pets.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Template */}
          <div>
            <label className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5 block">Card Type</label>
            <div className="grid grid-cols-3 gap-2">
              {(['vet', 'sitter', 'custom'] as CardTemplate[]).map(t => (
                <button
                  key={t}
                  onClick={() => handleTemplateChange(t)}
                  className={`py-2 rounded-xl text-sm font-semibold border-2 transition-all ${template === t
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300'
                    : 'border-stone-200 dark:border-stone-600 text-stone-600 dark:text-stone-400 hover:border-stone-300'}`}
                >
                  {TEMPLATE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          {/* Expiration */}
          <div>
            <label className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5 flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> Expiration (Min 8 hours)
            </label>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-xs text-stone-500 mb-1 block">Days</label>
                <input
                  type="number"
                  min="0"
                  value={customDays}
                  onChange={e => setCustomDays(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full border border-stone-200 dark:border-stone-600 rounded-xl px-3 py-2 text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-700 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
              <div className="flex-1">
                <label className="text-xs text-stone-500 mb-1 block">Hours</label>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={customHours}
                  onChange={e => setCustomHours(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full border border-stone-200 dark:border-stone-600 rounded-xl px-3 py-2 text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-700 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
            </div>
            {customDays * 24 + customHours < 8 && (
              <p className="text-xs text-rose-500 mt-2">Duration will automatically default to the 8 hour minimum.</p>
            )}
          </div>

          {/* Contextual Sharing Toggles */}
          <div>
            <label className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-2 block">Shared Fields</label>
            <div className="space-y-2">
              {/* Household Information at top */}
              {generalInfoText && (
                <label className="flex items-center justify-between p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/30 bg-emerald-50/50 dark:bg-emerald-950/20 hover:bg-emerald-50 cursor-pointer">
                  <span className="flex items-center gap-2 text-sm text-stone-700 dark:text-stone-300">
                    <Info className="w-3.5 h-3.5 text-emerald-600" /> Household Information
                  </span>
                  <input type="checkbox" checked={includeGeneralInfo} onChange={e => setIncludeGeneralInfo(e.target.checked)} className="w-4 h-4 accent-emerald-500" />
                </label>
              )}
              {/* All other fields — drag to reorder */}
              <Reorder.Group axis="y" values={sortableOrder} onReorder={setSortableOrder} className="space-y-2">
                {sortableOrder.map(key => {
                  const field = SHARING_FIELDS.find(f => f.key === key);
                  if (!field) return null;
                  return (
                    <Reorder.Item key={key} value={key} className="list-none">
                      <label className="flex items-center justify-between p-3 rounded-xl border border-stone-100 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-700/50 cursor-pointer bg-white dark:bg-stone-800">
                        <span className="flex items-center gap-2 text-sm text-stone-700 dark:text-stone-300">
                          <GripVertical className="w-4 h-4 text-stone-300 dark:text-stone-600 cursor-grab active:cursor-grabbing shrink-0" />
                          {field.icon} {field.label}
                        </span>
                        <input
                          type="checkbox"
                          checked={sharing[key as keyof SharingToggles]}
                          onChange={e => setSharing(s => ({ ...s, [key]: e.target.checked }))}
                          className="w-4 h-4 accent-emerald-500"
                        />
                      </label>
                    </Reorder.Item>
                  );
                })}
              </Reorder.Group>
            </div>
          </div>
        </div>

        <div className="p-5 border-t border-stone-100 dark:border-stone-700 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-stone-200 dark:border-stone-600 text-stone-700 dark:text-stone-300 font-medium hover:bg-stone-50 dark:hover:bg-stone-700 transition-colors">
            Cancel
          </button>
          {(template === 'custom' || template === 'emergency') && !customTemplateSaved ? (
            <button onClick={handleSaveCustomTemplate} className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold transition-colors">
              Save Card Template
            </button>
          ) : (
            <button
              onClick={handleCreate}
              disabled={!selectedPetId}
              className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold transition-colors disabled:opacity-50"
            >
              {editCard ? 'Save Changes' : 'Create Card'}
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}

// ─── Card Actions Panel ────────────────────────────────────────────────────────

function CardLogEntry({ card, pet }: { card: PetCard; pet: Pet }) {
  return (
    <div className="bg-stone-50 dark:bg-stone-800/50 rounded-2xl p-6 border border-stone-200 dark:border-stone-700 space-y-4">
      <div className="flex items-center gap-3 text-stone-500 dark:text-stone-400 mb-2">
        <ShieldOff className="w-5 h-5 text-rose-500" />
        <h3 className="font-semibold text-stone-700 dark:text-stone-300">Access Log Entry</h3>
      </div>
      <div className="space-y-4 text-sm mt-4">
        <div className="flex justify-between border-b border-stone-200 dark:border-stone-700 pb-3">
          <span className="text-stone-500">Pet</span>
          <span className="font-medium text-stone-900 dark:text-stone-100">{pet.name}</span>
        </div>
        <div className="flex justify-between border-b border-stone-200 dark:border-stone-700 pb-3">
          <span className="text-stone-500">Type</span>
          <span className="font-medium text-stone-900 dark:text-stone-100">{TEMPLATE_LABELS[card.template]}</span>
        </div>
        <div className="flex justify-between border-b border-stone-200 dark:border-stone-700 pb-3">
          <span className="text-stone-500">Issued</span>
          <span className="font-medium text-stone-900 dark:text-stone-100">{new Date(card.createdAt).toLocaleString()}</span>
        </div>
        <div className="flex justify-between pb-3">
          <span className="text-stone-500">Revoked</span>
          <span className="font-medium text-rose-600 dark:text-rose-400">{new Date(card.revokedAt || Date.now()).toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}



// ─── Card List Tile ────────────────────────────────────────────────────────────

function CardTile({
  card,
  pet,
  selected,
  onSelect,
  isStale,
  onUpdate,
  onRevoke,
  onUndoRevoke,
  onCopied,
  onEdit,
}: {
  key?: React.Key;
  card: PetCard;
  pet: Pet;
  selected: boolean;
  onSelect: () => void;
  isStale?: boolean;
  onUpdate?: () => void;
  onRevoke?: () => void;
  onUndoRevoke?: () => void;
  onCopied?: () => void;
  onEdit?: () => void;
}) {
  const status = getCardStatus(card);
  const isPermanentlyRevoked = status === 'revoked' && card.revokedAt && Date.now() >= card.revokedAt + UNDO_WINDOW_MS;
  const [showQr, setShowQr] = useState(false);

  // Undo countdown
  const [timeLeft, setTimeLeft] = useState(() => card.revokedAt ? Math.max(0, card.revokedAt + UNDO_WINDOW_MS - Date.now()) : 0);
  useEffect(() => {
    if (status === 'revoked' && card.revokedAt) {
      const iv = setInterval(() => setTimeLeft(Math.max(0, card.revokedAt! + UNDO_WINDOW_MS - Date.now())), 1000);
      return () => clearInterval(iv);
    }
  }, [status, card.revokedAt]);
  const formatTimeLeft = (ms: number) => {
    const s = Math.ceil(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  };

  const handleShare = useCallback(() => {
    const url = `${window.location.origin}/cards/view/${card.id}`;
    if (canShare()) {
      navigator.share({ title: `${pet.name}'s Card`, url });
    } else {
      navigator.clipboard.writeText(url).then(() => onCopied?.());
    }
  }, [card.id, pet.name, onCopied]);

  return (
    <div className="space-y-1">
      <div className="flex items-center gap-2">
        <button
          onClick={onSelect}
          className={`flex-1 flex items-center gap-3 p-3 rounded-xl transition-all border-2 text-left ${selected
            ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20'
            : 'border-transparent hover:border-stone-200 dark:hover:border-stone-600 hover:bg-stone-50 dark:hover:bg-stone-700/40'}`}
        >
          {pet.image ? (
            <img src={pet.image} alt={pet.name} className="w-10 h-10 rounded-full object-cover flex-shrink-0" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold text-white/80" style={{ backgroundColor: pet.backgroundColor || '#a8a29e' }}>{pet.name?.[0]?.toUpperCase()}</div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-stone-900 dark:text-stone-100 truncate">{pet.name} — {isPermanentlyRevoked ? 'Access Log' : TEMPLATE_LABELS[card.template]}</p>
            <p className="text-xs text-stone-500 dark:text-stone-400 truncate">
              {status === 'active'
                ? timeUntilExpiry(card.expiresAt)
                : status === 'expired' ? 'Expired' : isPermanentlyRevoked ? 'Permanently Logged' : '⛔ Revoked'}
            </p>
          </div>
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${status === 'active' ? 'bg-emerald-500' : status === 'expired' ? 'bg-stone-300' : 'bg-rose-500'}`} />
        </button>
        {isStale && onUpdate && (
          <button
            onClick={e => { e.stopPropagation(); onUpdate(); }}
            title="Pet info has changed — click to update this card"
            className="flex-shrink-0 flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-950/50 transition-colors text-xs font-medium border border-amber-200 dark:border-amber-800"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Update
          </button>
        )}
      </div>

      {/* Inline actions row — only for active or recently-revoked cards */}
      {selected && !isPermanentlyRevoked && status !== 'expired' && (
        <div className="flex items-center gap-1.5 pl-3 pt-1 pb-1 flex-wrap">
          {status === 'active' && (
            <>
              <button
                onClick={handleShare}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-950/50 transition-colors text-xs font-medium"
              >
                <Share2 className="w-3.5 h-3.5" /> Share
              </button>
              <button
                onClick={() => setShowQr(q => !q)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors text-xs font-medium"
              >
                <QrCode className="w-3.5 h-3.5" /> QR
              </button>
              {onEdit && (
                <button
                  onClick={onEdit}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-950/50 transition-colors text-xs font-medium"
                >
                  <Pencil className="w-3.5 h-3.5" /> Edit
                </button>
              )}
            </>
          )}
          {status === 'active' && onRevoke && (
            <button
              onClick={onRevoke}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-950/50 transition-colors text-xs font-medium"
            >
              <ShieldOff className="w-3.5 h-3.5" /> Revoke
            </button>
          )}
          {status === 'revoked' && timeLeft > 0 && onUndoRevoke && (
            <button
              onClick={onUndoRevoke}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-950/50 transition-colors text-xs font-medium"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Undo ({formatTimeLeft(timeLeft)})
            </button>
          )}
        </div>
      )}

      {/* QR popover */}
      {showQr && selected && status === 'active' && (
        <div className="ml-3 p-3 bg-white dark:bg-stone-800 rounded-xl border border-stone-200 dark:border-stone-700 shadow-lg inline-flex flex-col items-center gap-2">
          <QRCode value={`${window.location.origin}/cards/view/${card.id}`} size={120} level="M" />
          <p className="text-xs text-stone-400">Scan to view · Expires {formatExpiry(card.expiresAt)}</p>
        </div>
      )}
    </div>
  );
}

// ─── Main Cards Page ───────────────────────────────────────────────────────────

// Purge expired/revoked cards older than 30 days to minimise attack surface
const CARD_PURGE_AGE_MS = 30 * 24 * 60 * 60 * 1000;

export function Cards() {
  const { pets, loading } = usePets();
  const { user, profile } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [cards, setCards] = useState<PetCard[]>([]);
  const [cardsLoading, setCardsLoading] = useState(true);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showMultiPetModal, setShowMultiPetModal] = useState(false);
  const [copyToast, setCopyToast] = useState(false);
  const [cardToEdit, setCardToEdit] = useState<PetCard | null>(null);
  const [revokedSectionOpen, setRevokedSectionOpen] = useState(false);
  const [generalInfo, setGeneralInfo] = useState(() => localStorage.getItem(GENERAL_INFO_KEY) ?? '');
  const [editingGeneralInfo, setEditingGeneralInfo] = useState(false);

  // Seed card list from Firestore — single source of truth
  useEffect(() => {
    if (!user) { setCards([]); setCardsLoading(false); return; }
    let cancelled = false;
    getPublicCardsForOwner(user.uid)
      .then(docs => {
        if (cancelled) return;
        const now = Date.now();
        // Filter out permanently purged cards (revoked/expired > 30 days)
        const kept: PetCard[] = docs
          .filter(d => {
            if (d.status === 'active') return true;
            const ageMs = d.status === 'revoked' && d.revokedAt ? now - d.revokedAt : now - d.expiresAt;
            return ageMs < CARD_PURGE_AGE_MS;
          })
          .map(d => ({
            id: d.id,
            petId: d.petId,
            template: d.template as CardTemplate,
            createdAt: d.createdAt,
            expiresAt: d.expiresAt,
            status: d.status as CardStatus,
            sharing: d.sharing as unknown as SharingToggles,
            includeGeneralInfo: d.includeGeneralInfo,
            fieldOrder: d.fieldOrder,
            petSnapshot: d.petSnapshot as any,
            multiPetConfig: d.multiPetConfig as any,
            revokedAt: d.revokedAt,
          }));
        setCards(kept);
        setCardsLoading(false);

        // Clean up old revoked docs past undo window
        docs.filter(d => d.status === 'revoked' && d.revokedAt && now >= d.revokedAt + UNDO_WINDOW_MS)
          .forEach(d => deletePublicCard(d.id).catch(() => { }));
      })
      .catch(() => { if (!cancelled) setCardsLoading(false); });
    return () => { cancelled = true; };
  }, [user]);

  // Handle router state from Dashboard Quick Actions → "Create Card"
  useEffect(() => {
    if (location.state?.openCreateModal) {
      setShowCreateModal(true);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, location.pathname, navigate]);

  const selectedCard = useMemo(() => cards.find(c => c.id === selectedCardId), [cards, selectedCardId]);
  const selectedPet = useMemo(() => selectedCard ? pets.find(p => p.id === selectedCard.petId) : undefined, [selectedCard, pets]);

  /** Set of card IDs whose pet data has changed since the snapshot was taken. */
  const staleCardIds = useMemo(() => {
    const ids = new Set<string>();
    cards.filter(c => getCardStatus(c) === 'active' && c.petId !== 'multi-pet' && c.petId !== 'all-pets').forEach(c => {
      const pet = pets.find(p => p.id === c.petId);
      if (pet && isPetDataStale(c, pet)) ids.add(c.id);
    });
    return ids;
  }, [cards, pets]);

  const handleCopied = useCallback(() => {
    setCopyToast(true);
    setTimeout(() => setCopyToast(false), 2000);
    if (localStorage.getItem('petbase-step-share-card') !== 'true') {
      localStorage.setItem('petbase-step-share-card', 'true');
      window.dispatchEvent(new Event('petbase-guide-update'));
    }
  }, []);

  const handleCreate = (card: PetCard) => {
    // Enforce one active custom card: revoke any existing active custom/emergency cards
    if (card.template === 'custom' || card.template === 'emergency') {
      const existingCustom = cards.filter(c =>
        (c.template === 'custom' || c.template === 'emergency') &&
        getCardStatus(c) === 'active' &&
        c.id !== card.id
      );
      if (existingCustom.length > 0) {
        existingCustom.forEach(c => {
          updatePublicCardStatus(c.id, 'revoked').catch(() => { });
          setTimeout(() => deletePublicCard(c.id).catch(() => { }), UNDO_WINDOW_MS);
        });
        setCards(prev => prev.map(c =>
          (c.template === 'custom' || c.template === 'emergency') && getCardStatus(c) === 'active' && c.id !== card.id
            ? { ...c, status: 'revoked' as CardStatus, revokedAt: Date.now() }
            : c
        ));
      }
    }

    // Build petSnapshot for consistent preview/shared card rendering
    let localCard = card;
    if (card.petId !== 'multi-pet' && card.petId !== 'all-pets') {
      const pet = pets.find(p => p.id === card.petId);
      if (pet) {
        const snapshot = buildPetSnapshot(pet, card.sharing, card.includeGeneralInfo ?? false, generalInfo, user?.uid);
        localCard = { ...card, petSnapshot: snapshot };
      }
    } else {
      const configList = card.petId === 'multi-pet'
        ? card.multiPetConfig ?? []
        : pets.filter(p => !p.isPrivate).map(p => ({ petId: p.id, sharing: card.sharing }));
      localCard = {
        ...card,
        multiPetConfig: configList.map(cfg => {
          const p = pets.find(x => x.id === cfg.petId);
          if (!p) return cfg;
          return { ...cfg, petSnapshot: buildPetSnapshot(p, cfg.sharing, false, '', user?.uid) };
        }),
      };
    }

    setCards(prev => {
      if (prev.some(c => c.id === localCard.id)) {
        return prev.map(c => c.id === localCard.id ? localCard : c);
      }
      return [...prev, localCard];
    });
    setSelectedCardId(localCard.id);

    // Sync to Firestore so the share link works for recipients without auth
    if (user) {
      if (localCard.petId === 'multi-pet' || localCard.petId === 'all-pets') {
        const petConfigList = localCard.petId === 'multi-pet'
          ? localCard.multiPetConfig
          : pets.filter(p => !p.isPrivate).map(p => ({ petId: p.id, sharing: localCard.sharing }));

        logActivity(user.uid, `Created pet card for: ${localCard.petId}`);
        savePublicCard({
          id: localCard.id,
          ownerId: user.uid,
          petId: localCard.petId,
          template: localCard.template,
          sharing: localCard.sharing as unknown as Record<string, boolean>,
          expiresAt: localCard.expiresAt,
          status: 'active',
          createdAt: localCard.createdAt,
          includeGeneralInfo: localCard.includeGeneralInfo,
          fieldOrder: localCard.fieldOrder,
          multiPetConfig: petConfigList?.map(cfg => {
            const p = pets.find(x => x.id === cfg.petId);
            return {
              petId: cfg.petId,
              sharing: cfg.sharing as unknown as Record<string, boolean>,
              petSnapshot: p
                ? buildPetSnapshot(p, cfg.sharing, localCard.includeGeneralInfo ?? false, generalInfo, user?.uid)
                : undefined,
            };
          })
        } as any).catch(err => console.warn('Failed to sync card to Firestore:', err));
      } else {
        const pet = pets.find(p => p.id === localCard.petId);
        const petName = pet?.name ?? localCard.petId;
        logActivity(user.uid, `Created pet card for: ${petName}`);
        if (pet) {
          savePublicCard({
            id: localCard.id,
            ownerId: user.uid,
            petId: localCard.petId,
            template: localCard.template,
            sharing: localCard.sharing as unknown as Record<string, boolean>,
            expiresAt: localCard.expiresAt,
            status: 'active',
            createdAt: localCard.createdAt,
            includeGeneralInfo: localCard.includeGeneralInfo,
            petSnapshot: localCard.petSnapshot,
            fieldOrder: localCard.fieldOrder,
          } as any).catch(err => console.warn('Failed to sync card to Firestore:', err));
        }
      }
    }
  };

  const handleRevoke = (cardId: string) => {
    const revokedAt = Date.now();
    setCards(prev => prev.map(c => c.id === cardId ? { ...c, status: 'revoked' as CardStatus, revokedAt } : c));
    updatePublicCardStatusWithTimestamp(cardId, 'revoked', revokedAt).catch(() => { });
    // Schedule permanent deletion after undo window
    setTimeout(() => deletePublicCard(cardId).catch(() => { }), UNDO_WINDOW_MS);
    if (user) {
      const card = cards.find(c => c.id === cardId);
      const petName = card ? (pets.find(p => p.id === card.petId)?.name ?? card.petId) : cardId;
      logActivity(user.uid, `Revoked pet card for: ${petName}`);
    }
  };

  const handleUndoRevoke = (cardId: string) => {
    setCards(prev => prev.map(c => c.id === cardId ? { ...c, status: 'active' as CardStatus, revokedAt: undefined } : c));
    updatePublicCardStatusWithTimestamp(cardId, 'active').catch(() => { });
  };

  /** Rebuild the petSnapshot for a single card using current pet data, then re-sync to Firestore. */
  const handleUpdateCard = useCallback((cardId: string) => {
    const card = cards.find(c => c.id === cardId);
    if (!card || card.petId === 'multi-pet' || card.petId === 'all-pets') return;
    const pet = pets.find(p => p.id === card.petId);
    if (!pet || !user) return;
    const snapshot = buildPetSnapshot(pet, card.sharing, card.includeGeneralInfo ?? false, generalInfo, user.uid);
    const updated: PetCard = { ...card, petSnapshot: snapshot };
    setCards(prev => prev.map(c => c.id === cardId ? updated : c));
    savePublicCard({
      id: updated.id, ownerId: user.uid, petId: updated.petId, template: updated.template,
      sharing: updated.sharing as unknown as Record<string, boolean>,
      expiresAt: updated.expiresAt, status: updated.status as 'active',
      createdAt: updated.createdAt, includeGeneralInfo: updated.includeGeneralInfo,
      petSnapshot: snapshot,
      fieldOrder: updated.fieldOrder,
    } as any).catch(err => console.warn('Failed to update card snapshot:', err));
  }, [cards, pets, user, generalInfo]);

  /** Rebuild snapshots for all stale active single-pet cards. */
  const handleUpdateAllCards = useCallback(() => {
    cards
      .filter(c => getCardStatus(c) === 'active' && c.petId !== 'multi-pet' && c.petId !== 'all-pets')
      .forEach(c => {
        const pet = pets.find(p => p.id === c.petId);
        if (pet && isPetDataStale(c, pet)) handleUpdateCard(c.id);
      });
  }, [cards, pets, handleUpdateCard]);

  if (loading || cardsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (pets.length === 0) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
        <header>
          <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">Pet Cards</h1>
          <p className="text-stone-500 dark:text-stone-400 mt-1">Shareable profiles for sitters, walkers, and emergencies.</p>
        </header>
        <div className="text-center py-20">
          <PawPrint className="w-14 h-14 text-stone-200 dark:text-stone-700 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-stone-700 dark:text-stone-300 mb-2">No pets yet</h2>
          <p className="text-stone-400 dark:text-stone-500 mb-6">Add your first pet before creating a card.</p>
          <Link to="/pets" className="inline-block bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium transition-colors">
            Go to My Pets →
          </Link>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      {/* Copy toast — aria-live announces to screen readers when it appears */}
      <div aria-live="polite" aria-atomic="true" className="sr-only">
        {copyToast ? 'Link copied to clipboard' : ''}
      </div>
      <AnimatePresence>
        {copyToast && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            aria-hidden="true"
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 text-sm font-medium px-4 py-2 rounded-xl shadow-lg pointer-events-none"
          >
            Link copied to clipboard
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">Pet Cards</h1>
          <p className="text-stone-500 dark:text-stone-400 mt-1">Shareable profiles for sitters, walkers, and emergencies.</p>
        </div>
        <div className="flex gap-2">
          {pets.filter(p => !p.isPrivate).length >= 2 && (
            <button
              onClick={() => setShowMultiPetModal(true)}
              className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2.5 rounded-xl font-medium transition-colors"
            >
              <Layers className="w-4 h-4" /> Multi-pet Card
            </button>
          )}
          <button
            id="create-card-btn"
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 bg-stone-900 dark:bg-stone-100 hover:bg-stone-800 dark:hover:bg-stone-200 text-white dark:text-stone-900 px-5 py-2.5 rounded-xl font-medium transition-colors"
          >
            <Plus className="w-4 h-4" /> Create New Card
          </button>
        </div>
      </header>

      {/* Household Information Block */}
      <div className="bg-white dark:bg-stone-800 rounded-2xl p-5 border border-stone-100 dark:border-stone-700 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-stone-400" />
            <h2 className="font-semibold text-stone-800 dark:text-stone-200 text-sm">Household Information</h2>
          </div>
          <button
            onClick={() => {
              if (editingGeneralInfo) {
                localStorage.setItem(GENERAL_INFO_KEY, generalInfo);
              }
              setEditingGeneralInfo(v => !v);
            }}
            className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline font-medium"
          >
            {editingGeneralInfo ? 'Save' : 'Edit'}
          </button>
        </div>
        <p className="text-xs text-stone-400 dark:text-stone-500 mb-3">Household-level notes included when you opt in at card creation (gate codes, bowl ownership, etc.)</p>
        {editingGeneralInfo ? (
          <textarea
            value={generalInfo}
            onChange={e => setGeneralInfo(e.target.value)}
            rows={4}
            maxLength={1000}
            placeholder="e.g. Gate code: 1234. Max's bowl is blue, Bella's is pink."
            className="w-full px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-600 bg-stone-50 dark:bg-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
          />
        ) : (
          <p className="text-sm text-stone-600 dark:text-stone-300 whitespace-pre-wrap break-words">
            {generalInfo || <span className="text-stone-400 italic">No household information set.</span>}
          </p>
        )}
      </div>

      {cards.length === 0 ? (
        /* Empty state — no cards created yet */
        <div className="text-center py-16 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl">
          <QrCode className="w-12 h-12 text-stone-300 dark:text-stone-600 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-stone-700 dark:text-stone-300 mb-2">No cards yet</h2>
          <p className="text-stone-400 dark:text-stone-500 mb-5 max-w-sm mx-auto">
            Create a Sitter, Vet, or Custom card for any of your {pets.length} pet{pets.length > 1 ? 's' : ''}.
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium transition-colors"
          >
            <Plus className="w-4 h-4" /> Create Your First Card
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Card Preview */}
          <div className="flex justify-center">
            {selectedCard ? (
              selectedCard.petId === 'multi-pet' ? (
                <div className="w-full max-w-md">
                  <MultiPetCardPreview
                    pets={pets}
                    card={selectedCard}
                  />
                </div>
              ) : selectedCard.petId === 'all-pets' ? (
                <div className="w-full max-w-md">
                  <AllPetsCardPreview
                    pets={pets}
                    card={selectedCard}
                  />
                </div>
              ) : selectedPet ? (
                (selectedCard.status === 'revoked' && selectedCard.revokedAt && Date.now() >= selectedCard.revokedAt + UNDO_WINDOW_MS) ? (
                  <div className="w-full max-w-md">
                    <CardLogEntry card={selectedCard} pet={selectedPet} />
                  </div>
                ) : (
                  <div className="w-full max-w-md">
                    <CardPreview
                      card={selectedCard}
                      pet={selectedPet}
                    />
                  </div>
                )
              ) : null
            ) : (
              <div className="flex w-full max-w-md items-center justify-center h-64 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl">
                <p className="text-stone-400 dark:text-stone-500 text-sm">Select a card to preview</p>
              </div>
            )}
          </div>

          {/* Right panel */}
          <div className="space-y-5">
            {/* Cards list — Active */}
            {(() => {
              const activeCards = cards.filter(c => getCardStatus(c) === 'active');
              const inactiveCards = cards.filter(c => getCardStatus(c) !== 'active').slice(0, MAX_INACTIVE_CARDS);
              return (
                <>
                  <div className="bg-white dark:bg-stone-800 rounded-2xl p-5 shadow-sm border border-stone-100 dark:border-stone-700">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">Active Cards</h3>
                      <div className="flex items-center gap-2">
                        {staleCardIds.size > 0 && (
                          <button
                            onClick={handleUpdateAllCards}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-950/60 transition-colors text-xs font-medium"
                          >
                            <RefreshCw className="w-3 h-3" /> Update All
                          </button>
                        )}
                        <span className="text-xs text-stone-400 dark:text-stone-500">{activeCards.length} card{activeCards.length !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {activeCards.length === 0 && (
                        <p className="text-xs text-stone-400 dark:text-stone-500 text-center py-3">No active cards</p>
                      )}
                      {activeCards.map(c => {
                        const pet = c.petId === 'all-pets'
                          ? { id: 'all-pets', name: 'All Pets', breed: `${pets.filter(p => !p.isPrivate).length} pets`, image: '', age: '', weight: '', notes: '' } as Pet
                          : c.petId === 'multi-pet'
                            ? { id: 'multi-pet', name: 'Multi-pet Card', breed: `${c.multiPetConfig?.length ?? 0} pets selected`, image: '', age: '', weight: '', notes: '' } as Pet
                            : pets.find(p => p.id === c.petId);
                        if (!pet) return null;
                        return (
                          <CardTile
                            key={c.id}
                            card={c}
                            pet={pet}
                            selected={selectedCardId === c.id}
                            onSelect={() => setSelectedCardId(c.id)}
                            isStale={staleCardIds.has(c.id)}
                            onUpdate={() => handleUpdateCard(c.id)}
                            onRevoke={() => handleRevoke(c.id)}
                            onUndoRevoke={() => handleUndoRevoke(c.id)}
                            onCopied={handleCopied}
                            onEdit={() => {
                              setCardToEdit(c);
                              if (c.petId === 'multi-pet') setShowMultiPetModal(true);
                              else setShowCreateModal(true);
                            }}
                          />
                        );
                      })}
                    </div>
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="mt-3 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-stone-200 dark:border-stone-700 text-stone-400 dark:text-stone-500 hover:text-emerald-600 hover:border-emerald-400 dark:hover:border-emerald-600 transition-colors text-sm font-medium"
                    >
                      <Plus className="w-4 h-4" /> Add Another Card
                    </button>
                  </div>

                  {/* Revoked & Expired section — collapsed by default */}
                  {inactiveCards.length > 0 && (
                    <div className="bg-stone-50 dark:bg-stone-800/50 rounded-2xl border border-stone-200 dark:border-stone-700 overflow-hidden">
                      <button
                        onClick={() => setRevokedSectionOpen(o => !o)}
                        className="w-full flex items-center justify-between p-4 hover:bg-stone-100 dark:hover:bg-stone-700/50 transition-colors"
                      >
                        <span className="text-sm font-semibold text-stone-600 dark:text-stone-400">
                          Revoked &amp; Expired ({inactiveCards.length})
                        </span>
                        {revokedSectionOpen
                          ? <ChevronUp className="w-4 h-4 text-stone-400" />
                          : <ChevronDown className="w-4 h-4 text-stone-400" />
                        }
                      </button>
                      {revokedSectionOpen && (
                        <div className="px-4 pb-4 space-y-1">
                          {inactiveCards.map(c => {
                            const pet = c.petId === 'all-pets'
                              ? { id: 'all-pets', name: 'All Pets', breed: `${pets.filter(p => !p.isPrivate).length} pets`, image: '', age: '', weight: '', notes: '' } as Pet
                              : c.petId === 'multi-pet'
                                ? { id: 'multi-pet', name: 'Multi-pet Card', breed: `${c.multiPetConfig?.length ?? 0} pets selected`, image: '', age: '', weight: '', notes: '' } as Pet
                                : pets.find(p => p.id === c.petId);
                            if (!pet) return null;
                            return (
                              <CardTile
                                key={c.id}
                                card={c}
                                pet={pet}
                                selected={selectedCardId === c.id}
                                onSelect={() => setSelectedCardId(c.id)}
                                onUndoRevoke={() => handleUndoRevoke(c.id)}
                              />
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Create Card Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <CreateCardModal
            key={cardToEdit?.id ?? 'new'}
            pets={pets}
            onClose={() => { setShowCreateModal(false); setCardToEdit(null); }}
            onCreate={handleCreate}
            generalInfoText={generalInfo}
            editCard={cardToEdit ?? undefined}
          />
        )}
        {showMultiPetModal && (
          <MultiPetCardModal
            pets={pets}
            onClose={() => { setShowMultiPetModal(false); setCardToEdit(null); }}
            onCreate={handleCreate}
            editCard={cardToEdit ?? undefined}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

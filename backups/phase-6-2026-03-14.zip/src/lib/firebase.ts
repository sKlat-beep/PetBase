import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { initializeFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY ?? '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID ?? '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ?? '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? '',
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID ?? ''
};

// Check if Firebase config is missing
export const isConfigMissing =
  !firebaseConfig.apiKey || !firebaseConfig.authDomain || !firebaseConfig.projectId;

if (isConfigMissing) {
  console.warn('Firebase configuration is missing. Please add your Firebase credentials to the AI Studio Secrets panel or .env file.');
}

export const app = initializeApp(isConfigMissing ? { apiKey: 'dummy', authDomain: 'dummy', projectId: 'dummy' } : firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = initializeFirestore(app, { ignoreUndefinedProperties: true });

import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import { useAuth } from './AuthContext';
import {
  sendDm,
  markDmRead,
  deleteDmForUser,
  subscribeToConversations,
  subscribeToThread,
  type DmMessage,
} from '../lib/firestoreService';

export interface Conversation {
  threadId: string;
  otherUid: string;
  lastMessage: DmMessage;
}

interface MessagingContextValue {
  conversations: Conversation[];
  threadMessages: DmMessage[];
  activeUid: string | null;
  setActiveUid: (uid: string | null) => void;
  sendMessage: (toUid: string, content: string) => Promise<void>;
  deleteMessage: (messageId: string, fromUid: string) => Promise<void>;
  markRead: (messageId: string) => Promise<void>;
  unreadByUser: Record<string, number>;
  totalUnread: number;
}

const MessagingContext = createContext<MessagingContextValue | null>(null);

export function MessagingProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [threadMessages, setThreadMessages] = useState<DmMessage[]>([]);
  const [activeUid, setActiveUidState] = useState<string | null>(null);
  const threadUnsubRef = useRef<(() => void) | null>(null);

  // Subscribe to all conversations
  useEffect(() => {
    if (!user) { setConversations([]); return; }
    const unsub = subscribeToConversations(
      user.uid,
      setConversations,
      () => { /* silent — conversations stay stale */ },
    );
    return unsub;
  }, [user]);

  // Subscribe to active thread when activeUid changes
  const setActiveUid = useCallback((uid: string | null) => {
    threadUnsubRef.current?.();
    threadUnsubRef.current = null;
    setThreadMessages([]);
    setActiveUidState(uid);

    if (!uid || !user) return;
    threadUnsubRef.current = subscribeToThread(
      user.uid,
      uid,
      setThreadMessages,
      () => { /* silent */ },
    );
  }, [user]);

  // Cleanup thread subscription on unmount
  useEffect(() => () => { threadUnsubRef.current?.(); }, []);

  const sendMessage = useCallback(async (toUid: string, content: string) => {
    if (!user) return;
    await sendDm(user.uid, toUid, content);
  }, [user]);

  const deleteMessage = useCallback(async (messageId: string, fromUid: string) => {
    if (!user) return;
    await deleteDmForUser(messageId, user.uid, fromUid);
  }, [user]);

  const markRead = useCallback(async (messageId: string) => {
    await markDmRead(messageId);
  }, []);

  const unreadByUser: Record<string, number> = {};
  if (user) {
    conversations.forEach(c => {
      const unread = c.lastMessage.toUid === user.uid && !c.lastMessage.read ? 1 : 0;
      if (unread > 0) unreadByUser[c.otherUid] = (unreadByUser[c.otherUid] ?? 0) + unread;
    });
  }
  const totalUnread = Object.values(unreadByUser).reduce((a, b) => a + b, 0);

  return (
    <MessagingContext.Provider value={{
      conversations,
      threadMessages,
      activeUid,
      setActiveUid,
      sendMessage,
      deleteMessage,
      markRead,
      unreadByUser,
      totalUnread,
    }}>
      {children}
    </MessagingContext.Provider>
  );
}

export function useMessaging() {
  const ctx = useContext(MessagingContext);
  if (!ctx) throw new Error('useMessaging must be used within MessagingProvider');
  return ctx;
}

/**
 * Client-side telemetry logger — 7-day rolling retention, max 500 entries.
 * Stored in localStorage under `petbase-telemetry`.
 * Never transmitted automatically; only dispatched on user-initiated feedback
 * or uncaught error boundary triggers.
 */

export type LogLevel = 'info' | 'warn' | 'error';

export interface TelemetryEntry {
  id: string;
  level: LogLevel;
  message: string;
  context?: Record<string, unknown>;
  timestamp: number;
}

const STORAGE_KEY = 'petbase-telemetry';
const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const MAX_ENTRIES = 500;

function prune(entries: TelemetryEntry[]): TelemetryEntry[] {
  const cutoff = Date.now() - MAX_AGE_MS;
  return entries.filter(e => e.timestamp >= cutoff).slice(-MAX_ENTRIES);
}

function load(): TelemetryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function save(entries: TelemetryEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch {
    // Non-critical — storage quota exceeded
  }
}

export function logTelemetry(
  level: LogLevel,
  message: string,
  context?: Record<string, unknown>,
): void {
  const entry: TelemetryEntry = {
    id: crypto.randomUUID(),
    level,
    message,
    context,
    timestamp: Date.now(),
  };
  const entries = prune(load());
  entries.push(entry);
  save(entries);
}

function getTelemetryLog(): TelemetryEntry[] {
  return prune(load());
}

/** Serialise the log to a plain string for inclusion in reports. */
export function serialiseTelemetryLog(): string {
  return getTelemetryLog()
    .map(e => {
      const ts = new Date(e.timestamp).toISOString();
      const ctx = e.context ? ` | ${JSON.stringify(e.context)}` : '';
      return `[${ts}] ${e.level.toUpperCase()} — ${e.message}${ctx}`;
    })
    .join('\n');
}

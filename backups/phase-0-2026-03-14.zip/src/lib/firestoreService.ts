/**
 * PetBase Firestore Service
 *
 * All reads and writes for PII fields go through this module.
 * Encryption is applied BEFORE any setDoc/updateDoc call.
 * Decryption is applied IMMEDIATELY AFTER any getDoc/getDocs call,
 * before data enters React state — raw plaintext never reaches the cloud.
 *
 * PII fields encrypted:
 *   - users/{uid}/profile/data  -> address
 *   - users/{uid}/pets/{petId}  -> notes
 *
 * NO-CLOUD PII POLICY: Medical records, expense data, and all other sensitive
 * fields are stored client-side only (localStorage, encrypted). Firestore writes
 * for those fields are prohibited pending compliance review.
 *
 * Firestore Security Rules (configure in Firebase Console):
 *
 *   rules_version = '2';
 *   service cloud.firestore {
 *     match /databases/{database}/documents {
 *
 *       // Helper: requester and ownerUid are in the same household
 *       function inSameHousehold(ownerUid) {
 *         let rHH = get(/databases/$(database)/documents/users/$(request.auth.uid)/profile/data).data.get('householdId', null);
 *         let oHH = get(/databases/$(database)/documents/users/$(ownerUid)/profile/data).data.get('householdId', null);
 *         return rHH != null && rHH == oHH;
 *       }
 *
 *       // Users: full access only to own subtree (covers profile, config, etc.)
 *       match /users/{userId}/{document=**} {
 *         allow read, write: if request.auth != null && request.auth.uid == userId;
 *       }
 *
 *       // Pets: own OR household co-management (read + write)
 *       match /users/{userId}/pets/{petId} {
 *         allow read, write: if request.auth != null && (
 *           request.auth.uid == userId ||
 *           inSameHousehold(userId)
 *         );
 *       }
 *
 *       // Community groups: any authenticated user can read; write rules per subcollection
 *       match /groups/{groupId} {
 *         allow read: if request.auth != null;
 *         allow create: if request.auth != null;
 *         allow update, delete: if request.auth != null &&
 *           get(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid)).data.role == 'Owner';
 *
 *         match /members/{userId} {
 *           allow read: if request.auth != null;
 *           // Users can join (write own membership) or Owner can update any member's role
 *           allow write: if request.auth != null && (
 *             request.auth.uid == userId ||
 *             get(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid)).data.role == 'Owner'
 *           );
 *         }
 *
 *         match /posts/{postId} {
 *           allow read: if request.auth != null;
 *           allow create: if request.auth != null &&
 *             exists(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid));
 *           allow update: if request.auth != null && (
 *             resource.data.authorId == request.auth.uid ||
 *             get(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid)).data.role in ['Owner', 'Moderator']
 *           );
 *           allow delete: if request.auth != null && (
 *             resource.data.authorId == request.auth.uid ||
 *             get(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid)).data.role in ['Owner', 'Moderator']
 *           );
 *         }
 *
 *         match /events/{eventId} {
 *           allow read: if request.auth != null;
 *           allow write: if request.auth != null &&
 *             exists(/databases/$(database)/documents/groups/$(groupId)/members/$(request.auth.uid));
 *         }
 *       }
 *
 *       // Households — Family Sharing
 *       match /households/{householdId} {
 *         allow read: if request.auth != null && (
 *           resource.data.ownerId == request.auth.uid ||
 *           exists(/databases/$(database)/documents/households/$(householdId)/members/$(request.auth.uid))
 *         );
 *         allow create: if request.auth != null && request.resource.data.ownerId == request.auth.uid;
 *         allow update: if request.auth != null && resource.data.ownerId == request.auth.uid;
 *         allow delete: if request.auth != null && resource.data.ownerId == request.auth.uid;
 *
 *         match /members/{uid} {
 *           allow read: if request.auth != null &&
 *             exists(/databases/$(database)/documents/households/$(householdId)/members/$(request.auth.uid));
 *           // Any authenticated user can join (write own membership doc)
 *           allow create: if request.auth != null && request.auth.uid == uid;
 *           // Only owner can kick (delete others); anyone can delete own doc (leave)
 *           allow delete: if request.auth != null && (
 *             request.auth.uid == uid ||
 *             get(/databases/$(database)/documents/households/$(householdId)).data.ownerId == request.auth.uid
 *           );
 *           // Owner can update roles
 *           allow update: if request.auth != null &&
 *             get(/databases/$(database)/documents/households/$(householdId)).data.ownerId == request.auth.uid;
 *         }
 *       }
 *     }
 *   }
 */

import { doc, setDoc, getDoc, collection, getDocs, deleteDoc, collectionGroup, updateDoc, query, where, limit, addDoc } from 'firebase/firestore';
import { db, auth } from './firebase';
import { getOrCreateUserKey, encryptField, decryptField, type VaultKeyDoc } from './crypto';
import type { Pet, EmergencyContacts } from '../types/pet';
import type { UserProfile, PublicStatus } from '../types/user';
import type { Household, HouseholdMember, HouseholdRole, MemberPermissions, ParentalControls, AuditEntry } from '../types/household';
import { DEFAULT_PERMISSIONS, DEFAULT_PARENTAL_CONTROLS } from '../types/household';

export interface PublicProfileInfo {
  uid: string;
  displayName: string;
  username?: string;
  avatarUrl: string; // Exposed for secure resolution via tokenService
  visibility: 'Public' | 'Friends Only' | 'Private';
  publicStatus: PublicStatus;
}

// Legacy alias so existing imports of UserProfileData continue to compile.
// Migrate callers to import UserProfile from ../types/user directly.
export type UserProfileData = UserProfile;

// --- User Profile -----------------------------------------------------------

export async function saveUserProfile(
  uid: string,
  profile: UserProfile & { householdId?: string | null }
): Promise<void> {
  const key = await getOrCreateUserKey(uid);
  const encAddress = await encryptField(profile.address, key);
  const encZipCode = await encryptField(profile.zipCode ?? '', key);
  const payload: Record<string, unknown> = {
    displayName: profile.displayName,
    username: profile.username,
    address: encAddress,
    zipCode: encZipCode,
    visibility: profile.visibility,
    publicStatus: profile.publicStatus ?? 'None',
    avatarUrl: profile.avatarUrl ?? '',
    avatarShape: profile.avatarShape ?? 'circle',
    updatedAt: new Date().toISOString(),
  };
  if (profile.householdId !== undefined) payload.householdId = profile.householdId;
  await setDoc(doc(db, 'users', uid, 'profile', 'data'), payload, { merge: true });
}

export async function loadUserProfile(uid: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(db, 'users', uid, 'profile', 'data'));
  if (!snap.exists()) return null;
  const data = snap.data();
  const key = await getOrCreateUserKey(uid);
  return {
    displayName: data.displayName ?? '',
    username: data.username,
    address: await decryptField(data.address ?? '', key),
    zipCode: await decryptField(data.zipCode ?? '', key),
    visibility: data.visibility ?? 'Public',
    publicStatus: data.publicStatus ?? 'None',
    blockedUsers: data.blockedUsers ?? [],
    lostPetOptOut: data.lostPetOptOut ?? false,
    friends: data.friends ?? [],
    avatarUrl: data.avatarUrl ?? '',
    avatarShape: data.avatarShape ?? 'circle',
    householdId: data.householdId ?? null,
  } as UserProfile & { householdId: string | null };
}

export async function searchPublicProfiles(searchQuery: string): Promise<PublicProfileInfo[]> {
  // Collection group query to bypass needing an index for basic text search.
  // It reads all profiles, which is acceptable for a prototype without specialized search infra.
  const snap = await getDocs(collectionGroup(db, 'profile'));
  const results: PublicProfileInfo[] = [];
  const q = searchQuery.toLowerCase();

  snap.forEach(d => {
    // collectionGroup('profile') returns documents typically named 'data'
    // The user's UID is the parent document of the profile subcollection.
    const uid = d.ref.parent.parent?.id;
    if (!uid) return;

    const data = d.data();
    if (data.visibility === 'Private') return;

    if (
      (data.displayName && data.displayName.toLowerCase().includes(q)) ||
      (data.username && data.username.toLowerCase().includes(q))
    ) {
      results.push({
        uid,
        displayName: data.displayName,
        username: data.username,
        avatarUrl: data.avatarUrl || '',
        visibility: data.visibility || 'Public',
        publicStatus: data.publicStatus || 'None'
      });
    }
  });

  return results;
}

// --- Public Pet Cards -------------------------------------------------------

export interface PublicCardPetSnapshot {
  name: string;
  breed: string;
  type?: string;
  image: string;
  weight?: string;
  birthday?: string;
  age?: string;
  avatarShape?: string;
  backgroundColor?: string;
  food?: string;
  foodBrand?: string;
  foodAmount?: string;
  foodUnit?: string;
  activity?: string;
  likes?: string[];
  dislikes?: string[];
  favoriteActivities?: string[];
  typeOfPlay?: string;
  spayedNeutered?: string;
  lastVet?: string;
  notes?: string;
  vaccines?: any[];
  medications?: any[];
  emergencyContacts?: EmergencyContacts;
  microchipId?: string;
  householdInfo?: string;
}

export interface PublicCardDoc {
  id: string;
  ownerId: string;
  petId: string;
  template: string;
  sharing: Record<string, boolean>;
  expiresAt: number;
  status: 'active' | 'revoked' | 'expired';
  createdAt: number;
  revokedAt?: number;
  petSnapshot?: PublicCardPetSnapshot; // Optional because multi-pets use multiPetConfig
  multiPetConfig?: Array<{ petId: string; sharing: Record<string, boolean>; petSnapshot: PublicCardPetSnapshot }>;
  includeGeneralInfo?: boolean;
  fieldOrder?: string[];
}

export async function savePublicCard(card: PublicCardDoc): Promise<void> {
  await setDoc(doc(db, 'publicCards', card.id), card);
}

export async function updatePublicCardStatus(cardId: string, status: 'active' | 'revoked' | 'expired'): Promise<void> {
  await updateDoc(doc(db, 'publicCards', cardId), { status });
}

export async function deletePublicCard(cardId: string): Promise<void> {
  await deleteDoc(doc(db, 'publicCards', cardId));
}

export async function getPublicCard(cardId: string): Promise<PublicCardDoc | null> {
  const snap = await getDoc(doc(db, 'publicCards', cardId));
  if (!snap.exists()) return null;
  return snap.data() as PublicCardDoc;
}

/** Fetch all public cards owned by this user. Used to seed the Cards page from Firestore. */
export async function getPublicCardsForOwner(uid: string): Promise<PublicCardDoc[]> {
  const q = query(collection(db, 'publicCards'), where('ownerId', '==', uid));
  const snap = await getDocs(q);
  return snap.docs.map(d => d.data() as PublicCardDoc);
}

/** Update status and optionally set revokedAt timestamp. */
export async function updatePublicCardStatusWithTimestamp(
  cardId: string,
  status: 'active' | 'revoked' | 'expired',
  revokedAt?: number,
): Promise<void> {
  const payload: Record<string, unknown> = { status };
  if (revokedAt !== undefined) payload.revokedAt = revokedAt;
  else if (status === 'active') payload.revokedAt = null; // clear on undo
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await updateDoc(doc(db, 'publicCards', cardId), payload as any);
}

// --- Vault (E2EE Cross-Device Sync) -----------------------------------------

/**
 * Saves the user's wrapped AES key to Firestore.
 * The raw key is never transmitted — only the PBKDF2-wrapped ciphertext.
 * Path: users/{uid}/vault/key
 */
export async function saveVaultKey(uid: string, vaultKeyDoc: VaultKeyDoc): Promise<void> {
  await setDoc(doc(db, 'users', uid, 'vault', 'key'), { ...vaultKeyDoc });
}

/**
 * Loads the wrapped vault key document from Firestore.
 * Returns null if no vault key has been set up yet.
 */
export async function loadVaultKey(uid: string): Promise<VaultKeyDoc | null> {
  const snap = await getDoc(doc(db, 'users', uid, 'vault', 'key'));
  if (!snap.exists()) return null;
  return snap.data() as VaultKeyDoc;
}

/**
 * Saves an encrypted expenses blob to Firestore vault.
 * The blob must already be encrypted by the caller — never stored as plaintext.
 * Path: users/{uid}/vault/expenses
 */
export async function saveVaultExpenses(uid: string, encryptedBlob: string): Promise<void> {
  await setDoc(doc(db, 'users', uid, 'vault', 'expenses'), {
    encrypted: encryptedBlob,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Loads the encrypted expenses blob from Firestore vault.
 * Returns null if no vault expenses exist yet.
 */
export async function loadVaultExpenses(uid: string): Promise<string | null> {
  const snap = await getDoc(doc(db, 'users', uid, 'vault', 'expenses'));
  if (!snap.exists()) return null;
  return (snap.data().encrypted as string) ?? null;
}

// --- Pets -------------------------------------------------------------------

const medicalKey = (uid: string, petId: string) => `petbase-medical-${uid}-${petId}`;

/**
 * Saves vaccines and medicalVisits to:
 *   1. Encrypted localStorage (for fast offline reads)
 *   2. Firestore vault doc users/{uid}/vault/medical_{petId} (for cross-device sync)
 * The blob is encrypted before either write — the cloud sees only ciphertext.
 */
async function saveMedicalRecords(uid: string, petId: string, pet: Pet): Promise<void> {
  const vaccines = (pet as any).vaccines;
  const medicalVisits = (pet as any).medicalVisits;
  if (!vaccines && !medicalVisits) return;
  const key = await getOrCreateUserKey(uid);
  const payload = JSON.stringify({ vaccines: vaccines ?? [], medicalVisits: medicalVisits ?? [] });
  const encrypted = await encryptField(payload, key);
  // Write-through: localStorage (offline cache) + Firestore vault (multi-device sync)
  localStorage.setItem(medicalKey(uid, petId), encrypted);
  await setDoc(doc(db, 'users', uid, 'vault', `medical_${petId}`), {
    encrypted,
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Loads medical records and merges them into the pet.
 * Priority: localStorage (fast) → Firestore vault (cross-device fallback).
 */
async function loadMedicalRecords(uid: string, pet: Pet): Promise<Pet> {
  const key = await getOrCreateUserKey(uid);
  let encrypted: string | null = localStorage.getItem(medicalKey(uid, pet.id));

  // Cross-device fallback: if not in localStorage, try Firestore vault
  if (!encrypted) {
    const snap = await getDoc(doc(db, 'users', uid, 'vault', `medical_${pet.id}`));
    if (snap.exists()) {
      encrypted = snap.data().encrypted ?? null;
      // Populate local cache so future reads are fast
      if (encrypted) localStorage.setItem(medicalKey(uid, pet.id), encrypted);
    }
  }

  if (!encrypted) return pet;
  const decrypted = await decryptField(encrypted, key);
  if (!decrypted) return pet;
  try {
    const { vaccines, medicalVisits } = JSON.parse(decrypted);
    return { ...pet, ...(vaccines ? { vaccines } : {}), ...(medicalVisits ? { medicalVisits } : {}) } as Pet;
  } catch {
    return pet;
  }
}

export async function savePet(uid: string, pet: Pet): Promise<void> {
  const key = await getOrCreateUserKey(uid);
  const encNotes = await encryptField(pet.notes, key);

  // Save medical records to encrypted localStorage — not Firestore (NO-CLOUD PII POLICY)
  await saveMedicalRecords(uid, pet.id, pet);

  // Strip PII-adjacent fields before Firestore write
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { vaccines, medicalVisits, ...petForFirestore } = pet as any;
  await setDoc(doc(db, 'users', uid, 'pets', pet.id), {
    ...petForFirestore,
    notes: encNotes,
  });
}

export async function loadPets(uid: string): Promise<Pet[]> {
  const key = await getOrCreateUserKey(uid);
  const snap = await getDocs(collection(db, 'users', uid, 'pets'));
  return Promise.all(
    snap.docs.map(async (d) => {
      const data = d.data() as Pet;
      const withNotes: Pet = {
        ...data,
        notes: await decryptField(data.notes ?? '', key),
      };
      // Merge in encrypted local medical records
      return loadMedicalRecords(uid, withNotes);
    })
  );
}

export async function deletePetDoc(uid: string, petId: string): Promise<void> {
  await deleteDoc(doc(db, 'users', uid, 'pets', petId));
}

/**
 * Deletes all publicCards documents owned by this user for a given pet.
 * Called as part of full pet deletion to remove shared card links.
 */
export async function deletePublicCardsForPet(uid: string, petId: string): Promise<void> {
  const q = query(collection(db, 'publicCards'), where('ownerId', '==', uid), where('petId', '==', petId));
  const snap = await getDocs(q);
  await Promise.all(snap.docs.map(d => deleteDoc(d.ref)));
}

// --- Household / Family Sharing --------------------------------------------

function generateInviteCode(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

export async function createHousehold(
  uid: string,
  displayName: string,
  householdName: string,
): Promise<Household> {
  const key = await getOrCreateUserKey(uid);
  const encHouseholdName = await encryptField(householdName, key);
  const encDisplayName = await encryptField(displayName, key);

  const householdId = crypto.randomUUID();
  const inviteCode = generateInviteCode();
  const now = Date.now();
  const household: Household = { id: householdId, name: householdName, ownerId: uid, inviteCode, createdAt: now };

  const leaderPermissions: MemberPermissions = { editPetInfo: true, addMedicalInfo: true, createRevokePetCards: true };
  await setDoc(doc(db, 'households', householdId), { name: encHouseholdName, ownerId: uid, inviteCode, createdAt: now });
  await setDoc(doc(db, 'households', householdId, 'members', uid), { uid, displayName: encDisplayName, role: 'Family Leader', joinedAt: now, permissions: leaderPermissions });
  await updateDoc(doc(db, 'users', uid, 'profile', 'data'), { householdId });

  return household;
}

export async function joinHouseholdByCode(
  uid: string,
  displayName: string,
  code: string,
): Promise<Household> {
  const q = query(collection(db, 'households'), where('inviteCode', '==', code.toUpperCase().trim()), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) throw new Error('Invalid invite code. Please check the code and try again.');

  const d = snap.docs[0];
  const data = d.data();
  const household: Household = { id: d.id, ...data } as Household;

  // Try to decrypt household name if possible (only if current user is owner, which is unlikely for joining)
  // For now, we'll return as-is; it may remain encrypted in the UI if not the owner.
  // We'll handle broader decryption in getHousehold.

  // Check not already a member
  const memberSnap = await getDoc(doc(db, 'households', household.id, 'members', uid));
  if (memberSnap.exists()) throw new Error('You are already a member of this household.');

  const key = await getOrCreateUserKey(uid);
  const encDisplayName = await encryptField(displayName, key);

  await setDoc(doc(db, 'households', household.id, 'members', uid), { uid, displayName: encDisplayName, role: 'Member', joinedAt: Date.now(), permissions: DEFAULT_PERMISSIONS });
  await updateDoc(doc(db, 'users', uid, 'profile', 'data'), { householdId: household.id });

  return household;
}

export async function getHousehold(householdId: string): Promise<Household | null> {
  const snap = await getDoc(doc(db, 'households', householdId));
  if (!snap.exists()) return null;
  const data = snap.data();

  const household: Household = { id: snap.id, ...data } as Household;

  // Decrypt household name if the current user is the owner
  const currentUser = auth.currentUser;
  if (currentUser && data.ownerId === currentUser.uid && data.name?.startsWith('ENC:')) {
    try {
      const key = await getOrCreateUserKey(currentUser.uid);
      household.name = await decryptField(data.name, key);
    } catch (err) {
      console.error('Failed to decrypt household name:', err);
    }
  }

  return household;
}

export async function getHouseholdMembers(householdId: string): Promise<HouseholdMember[]> {
  const snap = await getDocs(collection(db, 'households', householdId, 'members'));
  const currentUser = auth.currentUser;

  return Promise.all(snap.docs.map(async d => {
    const data = d.data();
    let displayName = data.displayName;

    // Attempt decryption if it's the current user's document
    if (currentUser && data.uid === currentUser.uid && displayName?.startsWith('ENC:')) {
      try {
        const key = await getOrCreateUserKey(currentUser.uid);
        displayName = await decryptField(displayName, key);
      } catch (err) {
        console.error('Failed to decrypt member display name:', err);
      }
    }

    return { ...data, displayName } as HouseholdMember;
  }));
}

export async function leaveHousehold(householdId: string, uid: string, isOwner: boolean, memberCount: number): Promise<void> {
  await deleteDoc(doc(db, 'households', householdId, 'members', uid));
  await updateDoc(doc(db, 'users', uid, 'profile', 'data'), { householdId: null });
  if (isOwner && memberCount <= 1) {
    await deleteDoc(doc(db, 'households', householdId));
  }
}

export async function kickHouseholdMember(householdId: string, memberUid: string): Promise<void> {
  await deleteDoc(doc(db, 'households', householdId, 'members', memberUid));
  await updateDoc(doc(db, 'users', memberUid, 'profile', 'data'), { householdId: null });
}

export async function regenerateInviteCode(householdId: string): Promise<string> {
  const newCode = generateInviteCode();
  await updateDoc(doc(db, 'households', householdId), { inviteCode: newCode });
  return newCode;
}

export async function updateMemberRole(householdId: string, uid: string, role: HouseholdRole): Promise<void> {
  await updateDoc(doc(db, 'households', householdId, 'members', uid), { role });
}

export async function updateMemberPermissions(householdId: string, uid: string, permissions: MemberPermissions): Promise<void> {
  await updateDoc(doc(db, 'households', householdId, 'members', uid), { permissions });
}

export async function updateParentalControls(householdId: string, uid: string, controls: ParentalControls): Promise<void> {
  await updateDoc(doc(db, 'households', householdId, 'members', uid), { parentalControls: controls });
}

export async function addAuditEntry(householdId: string, entry: Omit<AuditEntry, 'id'>): Promise<AuditEntry> {
  const ref = await addDoc(collection(db, 'households', householdId, 'auditLog'), entry);
  return { ...entry, id: ref.id };
}

export async function getAuditLog(householdId: string): Promise<AuditEntry[]> {
  const snap = await getDocs(collection(db, 'households', householdId, 'auditLog'));
  return snap.docs
    .map(d => ({ id: d.id, ...d.data() } as AuditEntry))
    .sort((a, b) => b.timestamp - a.timestamp);
}

/** Ensures the current user has a household (creates one if not), then returns its invite code. */
export async function ensureHouseholdForFamily(
  uid: string,
  displayName: string,
): Promise<Household> {
  const profileSnap = await getDoc(doc(db, 'users', uid, 'profile', 'data'));
  const existingId = profileSnap.exists() ? profileSnap.data().householdId : null;
  if (existingId) {
    const hh = await getHousehold(existingId);
    if (hh) return hh;
  }
  return createHousehold(uid, displayName, `${displayName}'s Family`);
}

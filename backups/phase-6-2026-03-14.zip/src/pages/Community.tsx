﻿import { useState, useMemo, useEffect } from 'react';
import { motion } from 'motion/react';
import { MessageSquare, Users, MapPin, Calendar, Plus, Settings2, ChevronDown, ChevronUp, Star, Pin } from 'lucide-react';
import { useCommunity } from '../contexts/CommunityContext';
import { useAuth } from '../contexts/AuthContext';
import { CreateGroupModal } from '../components/CreateGroupModal';
import { ManageGroupsModal } from '../components/ManageGroupsModal';
import { LostPetBanner } from '../components/LostPetBanner';
import { getActiveLostPets, type LostPetAlert } from '../utils/lostPetsApi';
import { Link } from 'react-router';

export function Community() {
  const { groups, userPreferences, joinGroup, rsvpEvent } = useCommunity();
  const { user, profile } = useAuth();
  const [isManageOpen, setIsManageOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [showAllGroups, setShowAllGroups] = useState(false);
  const [lostPets, setLostPets] = useState<LostPetAlert[]>([]);

  useEffect(() => {
    if (profile?.zipCode) {
      getActiveLostPets(profile.zipCode).then(setLostPets);
    }
  }, [profile?.zipCode]);

  // Filter groups the user is a member of, sort by favorite then joinedAt
  const userGroups = useMemo(() => {
    if (!user) return [];
    return groups
      .filter(g => !!g.members[user.uid])
      .sort((a, b) => {
        const aFav = userPreferences[a.id]?.isFavorite ? 1 : 0;
        const bFav = userPreferences[b.id]?.isFavorite ? 1 : 0;
        if (aFav !== bFav) return bFav - aFav;
        return b.members[user.uid].joinedAt - a.members[user.uid].joinedAt;
      });
  }, [groups, user, userPreferences]);

  const displayedGroups = showAllGroups ? userGroups : userGroups.slice(0, 4);

  // Discoverable groups (not a member of yet)
  const discoverGroups = useMemo(() => {
    if (!user) return groups;
    return groups.filter(g => !g.members[user.uid]);
  }, [groups, user]);

  const meetups = useMemo(() => {
    if (!user) return [];
    const allEvents = userGroups.flatMap(g =>
      (g.events || []).map(e => ({ ...e, groupId: g.id, groupName: g.name }))
    );
    return allEvents.sort((a, b) => a.date.localeCompare(b.date)).slice(0, 5);
  }, [userGroups, user]);

  // Recent posts from all joined groups, sorted newest first
  const recentDiscussions = useMemo(() => {
    const SIXTY_DAYS = 60 * 24 * 60 * 60 * 1000;
    return userGroups
      .flatMap(g => (g.posts || []).map(p => ({ ...p, groupName: g.name, groupId: g.id })))
      .filter(p => Date.now() - p.createdAt < SIXTY_DAYS)
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 5);
  }, [userGroups]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 dark:text-stone-100 tracking-tight">
            Community
          </h1>
          <p className="text-stone-500 dark:text-stone-400 mt-1">
            Connect with other pet parents, join groups, and attend meetups.
          </p>
        </div>
        <button onClick={() => setIsCreateOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-medium transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" /> Create Group
        </button>
      </header>

      {/* Local Lost Pet Alerts */}
      {lostPets.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-rose-600 dark:text-rose-500">
            Active Community Alerts
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {lostPets.map(alert => (
              <LostPetBanner key={alert.id} lostPet={alert} />
            ))}
          </div>
        </section>
      )}

      {/* Recommended/Discover layer if no groups */}
      {userGroups.length === 0 && discoverGroups.length > 0 && (
        <section className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-emerald-900 dark:text-emerald-100 mb-2">Discover Groups</h2>
          <p className="text-emerald-700 dark:text-emerald-300 text-sm mb-4">Join communities to see discussions and events here.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {discoverGroups.slice(0, 3).map(group => (
              <div key={group.id} className="bg-white dark:bg-stone-800 p-4 rounded-xl shadow-sm flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-stone-900 dark:text-stone-100 line-clamp-1">{group.name}</h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 line-clamp-2">{group.description}</p>
                </div>
                <button onClick={() => joinGroup(group.id)} className="mt-3 w-full py-1.5 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:hover:bg-emerald-800/60 rounded-lg text-sm font-medium transition-colors">
                  Join Group
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100">Your Groups</h2>
              <div className="flex gap-3">
                <button onClick={() => setIsManageOpen(true)} className="text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200 font-medium text-sm flex items-center gap-1 transition-colors">
                  <Settings2 className="w-4 h-4" /> Manage
                </button>
              </div>
            </div>

            {userGroups.length === 0 ? (
              <div className="text-center py-10 bg-white dark:bg-stone-800 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl text-stone-500 dark:text-stone-400">
                <Users className="w-8 h-8 mx-auto mb-2 text-stone-300 dark:text-stone-600" />
                <p>You aren't in any groups yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {displayedGroups.map((group) => (
                  <Link
                    to={`/community/${group.id}`}
                    key={group.id}
                    className="bg-white dark:bg-stone-800 rounded-2xl overflow-hidden shadow-sm border border-stone-100 dark:border-stone-700 hover:shadow-md transition-shadow group cursor-pointer block"
                  >
                    <div className="h-24 sm:h-32 overflow-hidden relative">
                      <img
                        src={group.image}
                        alt={group.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      {userPreferences[group.id]?.isFavorite && (
                        <div className="absolute top-2 right-2 bg-amber-500 text-white p-1 rounded-full shadow-sm">
                          <Star className="w-3 h-3 fill-current" />
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-stone-900 dark:text-stone-100 truncate">
                        {group.name}
                      </h3>
                      <div className="flex items-center gap-4 mt-2 text-sm text-stone-500 dark:text-stone-400">
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" /> {Object.keys(group.members).length}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-4 h-4" /> {group.posts?.length || 0} posts
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {userGroups.length > 4 && (
              <button
                onClick={() => setShowAllGroups(!showAllGroups)}
                className="w-full mt-4 py-2 border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-xl text-stone-600 dark:text-stone-400 text-sm font-medium transition-colors flex items-center justify-center gap-2"
              >
                {showAllGroups ? <><ChevronUp className="w-4 h-4" /> Show Less</> : <><ChevronDown className="w-4 h-4" /> View All ({userGroups.length})</>}
              </button>
            )}
          </section>

          {userGroups.length > 0 && (
            <section>
              <h2 className="text-xl font-semibold text-stone-900 dark:text-stone-100 mb-4">
                Recent Discussions
              </h2>
              {recentDiscussions.length === 0 ? (
                <div className="text-center py-10 bg-white dark:bg-stone-800 border-2 border-dashed border-stone-200 dark:border-stone-700 rounded-2xl text-stone-400 dark:text-stone-500">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No recent discussions yet. Start a conversation in one of your groups!</p>
                </div>
              ) : (
                <div className="bg-white dark:bg-stone-800 rounded-2xl shadow-sm border border-stone-100 dark:border-stone-700 divide-y divide-stone-100 dark:divide-stone-700">
                  {recentDiscussions.map((post) => (
                    <Link
                      to={`/community/${post.groupId}`}
                      key={post.id}
                      className="p-4 hover:bg-stone-50 dark:hover:bg-stone-700/50 transition-colors cursor-pointer flex items-start gap-3 block"
                    >
                      <img
                        src={post.authorImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.authorId}`}
                        alt={post.authorName}
                        className="w-10 h-10 rounded-full bg-stone-100 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <div className="flex items-baseline gap-2 flex-wrap">
                          <span className="font-semibold text-stone-900 dark:text-stone-100">{post.authorName}</span>
                          <span className="text-xs text-stone-500 dark:text-stone-400">in {post.groupName}</span>
                          {post.isPinned && <Pin className="w-3 h-3 text-amber-500 fill-current shrink-0" />}
                        </div>
                        <p className="text-stone-700 dark:text-stone-300 mt-1 text-sm line-clamp-2">{post.content}</p>
                        <p className="text-xs text-stone-400 dark:text-stone-500 mt-2">
                          {new Date(post.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </section>
          )}
        </div>

        <div className="space-y-8">
          <section className="bg-white dark:bg-stone-800 rounded-2xl p-6 shadow-sm border border-stone-100 dark:border-stone-700">
            <h2 className="text-lg font-semibold text-stone-900 dark:text-stone-100 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" /> Upcoming Meetups
            </h2>
            <div className="space-y-4">
              {meetups.length === 0 ? (
                <div className="text-center py-6 text-stone-500 dark:text-stone-400 text-sm">
                  <Calendar className="w-6 h-6 mx-auto mb-2 text-stone-300 dark:text-stone-600" />
                  No upcoming events in your groups.
                </div>
              ) : (
                meetups.map((meetup) => (
                  <div
                    key={meetup.id}
                    className="p-4 rounded-xl border border-stone-100 dark:border-stone-700 bg-stone-50 dark:bg-stone-700/50"
                  >
                    <div className="flex items-start justify-between">
                      <h4 className="font-bold text-stone-900 dark:text-stone-100">{meetup.title}</h4>
                      <span className="text-[10px] font-medium bg-stone-200/50 dark:bg-stone-800 text-stone-500 dark:text-stone-400 px-2 py-0.5 rounded-md truncate max-w-[100px]">{meetup.groupName}</span>
                    </div>
                    <p className="text-xs text-stone-500 mt-1 line-clamp-1">{meetup.description}</p>
                    <div className="space-y-2 mt-3 text-sm text-stone-600 dark:text-stone-400">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-500 shrink-0" />
                        <span>{new Date(meetup.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-stone-400 dark:text-stone-500 shrink-0" />
                        <span className="truncate">{meetup.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <Users className="w-3.5 h-3.5 text-stone-400 dark:text-stone-500 shrink-0" />
                        <span>{meetup.attendeeIds.length} attending</span>
                      </div>
                    </div>
                    {user && !meetup.attendeeIds.includes(user.uid) ? (
                      <button
                        onClick={() => rsvpEvent(meetup.groupId, meetup.id, true)}
                        className="w-full mt-4 bg-white dark:bg-stone-700 border border-stone-200 dark:border-stone-600 text-stone-700 dark:text-stone-300 font-medium py-1.5 rounded-lg text-sm hover:bg-stone-50 dark:hover:bg-stone-600 transition-colors"
                      >
                        RSVP
                      </button>
                    ) : user ? (
                      <button
                        onClick={() => rsvpEvent(meetup.groupId, meetup.id, false)}
                        className="w-full mt-4 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 font-medium py-1.5 rounded-lg text-sm text-center border border-emerald-100 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
                      >
                        ✓ Going · Cancel RSVP
                      </button>
                    ) : null}
                  </div>
                ))
              )}
            </div>
          </section>
        </div>
      </div>

      <CreateGroupModal isOpen={isCreateOpen} onClose={() => setIsCreateOpen(false)} />
      <ManageGroupsModal isOpen={isManageOpen} onClose={() => setIsManageOpen(false)} />
    </motion.div>
  );
}

/**
 * PetBase Service Search API Wrapper
 *
 * Calls the `findServices` Firebase Cloud Function which proxies the Google
 * Places Text Search API server-side so the API key never appears in the
 * client bundle.
 *
 * Set the key once via:
 *   firebase functions:secrets:set GOOGLE_PLACES_KEY
 * Then deploy:
 *   firebase deploy --only functions
 */

import { getFunctions, httpsCallable } from 'firebase/functions';
import { app } from '../lib/firebase';

export interface ServiceResult {
  id: string;
  name: string;
  type: string;
  rating: number;
  reviews: number;
  distance: string;
  address: string;
  image: string;
  /** True = business is Google/Yelp verified */
  isVerified: boolean;
  /** True = business metadata explicitly matches the user's pet types/breeds/sizes */
  petVerified: boolean;
  tags: string[];
  communityTips?: {
    text: string;
    author: string;
    date: string;
  }[];
}

export interface SearchFilters {
  query: string;
  location: string;  // ZIP code or 'GPS'
  type: 'Vets' | 'Groomers' | 'Sitters' | 'Walkers' | 'Trainers' | 'Stores';
  petTypesQuery: string[];   // e.g., ['Dog', 'Cat']
  petBreedsQuery?: string[]; // e.g., ['Golden Retriever']
  petSizesQuery?: string[];  // e.g., ['Large']
  serviceFilters?: string[];
}

let _functions: ReturnType<typeof getFunctions> | null = null;
function getFns() {
  if (!_functions) _functions = getFunctions(app, 'us-central1');
  return _functions;
}

/**
 * Search for local pet services via the findServices Cloud Function.
 * Falls back to an empty array if the function is not deployed or the API key
 * has not been set yet.
 */
export async function searchServices(filters: SearchFilters): Promise<ServiceResult[]> {
  if (!filters.location) return [];

  const cacheKey = `petbase_services_${JSON.stringify(filters)}`;
  const cached = sessionStorage.getItem(cacheKey);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) return parsed;
    } catch { }
  }

  try {
    const call = httpsCallable<
      { type: string; location: string; query: string },
      { results: ServiceResult[] }
    >(getFns(), 'findServices');

    const res = await call({
      type: filters.type,
      location: filters.location,
      query: filters.query,
    });

    const results = res.data.results ?? [];
    if (results.length > 0) {
      sessionStorage.setItem(cacheKey, JSON.stringify(results));
    }
    return results;
  } catch {
    // Cloud Function not yet deployed or key not set — return empty gracefully
    return [];
  }
}

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Users } from 'lucide-react';
import { useCommunity } from '../contexts/CommunityContext';

interface CreateGroupModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export function CreateGroupModal({ isOpen, onClose }: CreateGroupModalProps) {
    const { createGroup, groups } = useCommunity();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [image, setImage] = useState('');
    const [tags, setTags] = useState<string[]>([]);
    const [tagInput, setTagInput] = useState('');
    const [nameError, setNameError] = useState('');
    const [submitting, setSubmitting] = useState(false);

    const ownedGroups = groups.filter(g => Object.values(g.members).some((m: any) => m.role === 'Owner'));

    const addTag = () => {
        const t = tagInput.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
        if (!t || tags.includes(t) || tags.length >= 10) return;
        setTags(prev => [...prev, t]);
        setTagInput('');
    };

    const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTag(); }
        if (e.key === 'Backspace' && !tagInput && tags.length > 0) {
            setTags(prev => prev.slice(0, -1));
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !description || submitting) return;
        setNameError('');
        setSubmitting(true);
        const err = await createGroup(name, description, image || `https://picsum.photos/seed/${name.replace(/\s+/g, '')}/400/300`, tags);
        setSubmitting(false);
        if (err) { setNameError(err); return; }
        setName('');
        setDescription('');
        setImage('');
        setTags([]);
        setTagInput('');
        setNameError('');
        onClose();
    };

    if (!isOpen) return null;

    return (
        <AnimatePresence>
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
                <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="relative bg-white dark:bg-stone-800 rounded-2xl shadow-2xl border border-stone-100 dark:border-stone-700 w-full max-w-md z-10 flex flex-col"
                >
                    <div className="flex items-center justify-between p-6 border-b border-stone-100 dark:border-stone-700">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                                <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                            </div>
                            <div>
                                <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100">Create Group</h2>
                                <p className="text-sm text-stone-500 dark:text-stone-400">{ownedGroups.length}/3 groups owned</p>
                            </div>
                        </div>
                        <button onClick={onClose} className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors p-1 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Group Name</label>
                            <input
                                type="text"
                                required
                                value={name}
                                onChange={(e) => { setName(e.target.value); setNameError(''); }}
                                placeholder="e.g. Local Husky Walkers"
                                className={`w-full px-4 py-2 rounded-xl border bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 transition-colors ${nameError ? 'border-rose-400 focus:ring-rose-400' : 'border-stone-200 dark:border-stone-600 focus:ring-emerald-500'}`}
                            />
                            {nameError && <p className="text-xs text-rose-500 mt-1">{nameError}</p>}
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Description</label>
                            <textarea
                                required
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                placeholder="What is this group about?"
                                rows={3}
                                className="w-full px-4 py-2 rounded-xl border border-stone-200 dark:border-stone-600 bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors resize-none"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Cover Image URL (Optional)</label>
                            <input
                                type="url"
                                value={image}
                                onChange={(e) => setImage(e.target.value)}
                                placeholder="https://..."
                                className="w-full px-4 py-2 rounded-xl border border-stone-200 dark:border-stone-600 bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-colors"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">
                                Search Tags <span className="text-stone-400 font-normal">({tags.length}/10)</span>
                            </label>
                            <div className="flex flex-wrap gap-1.5 p-2 rounded-xl border border-stone-200 dark:border-stone-600 bg-white dark:bg-stone-700 min-h-[2.75rem] focus-within:ring-2 focus-within:ring-emerald-500">
                                {tags.map(tag => (
                                    <span key={tag} className="inline-flex items-center gap-1 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-medium px-2 py-0.5 rounded-full">
                                        #{tag}
                                        <button type="button" onClick={() => setTags(prev => prev.filter(t => t !== tag))} className="hover:text-rose-600 transition-colors leading-none">&times;</button>
                                    </span>
                                ))}
                                {tags.length < 10 && (
                                    <input
                                        type="text"
                                        value={tagInput}
                                        onChange={e => setTagInput(e.target.value)}
                                        onKeyDown={handleTagKeyDown}
                                        onBlur={addTag}
                                        placeholder={tags.length === 0 ? 'e.g. dogs, local, hiking...' : ''}
                                        className="flex-1 min-w-[120px] text-sm text-stone-900 dark:text-stone-100 bg-transparent outline-none placeholder:text-stone-400"
                                    />
                                )}
                            </div>
                            <p className="text-xs text-stone-400 mt-1">Press Enter or comma to add a tag</p>
                        </div>

                        <button
                            type="submit"
                            disabled={ownedGroups.length >= 3 || !name || !description || submitting}
                            className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 dark:disabled:bg-stone-600 disabled:cursor-not-allowed text-white px-5 py-2.5 rounded-xl font-medium transition-colors"
                        >
                            {submitting ? 'Checking...' : 'Create Group'}
                        </button>
                        {ownedGroups.length >= 3 && (
                            <p className="text-center text-xs text-rose-500 mt-2">You have reached the maximum number of owned groups (3).</p>
                        )}
                    </form>
                </motion.div>
            </div>
        </AnimatePresence>
    );
}
